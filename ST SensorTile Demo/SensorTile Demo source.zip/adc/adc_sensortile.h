#ifndef __ATMO_ADC_SENSORTILE_H
#define __ATMO_ADC_SENSORTILE_H


/* Includes ------------------------------------------------------------------*/

#include "../app_src/atmosphere_platform.h"
#include "adc.h"

#ifdef __cplusplus
	extern "C"{
#endif


/* Exported Function Prototypes -----------------------------------------------*/

ATMO_Status_t ATMO_SENSORTILE_ADC_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber );

ATMO_ADC_Status_t ATMO_SENSORTILE_ADC_Init(ATMO_DriverInstanceData_t *instance);

ATMO_ADC_Status_t ATMO_SENSORTILE_ADC_DeInit(ATMO_DriverInstanceData_t *instance);

ATMO_ADC_Status_t ATMO_SENSORTILE_ADC_ReadRaw(ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, int32_t *value, uint32_t numSamplesToAverage);

ATMO_ADC_Status_t ATMO_SENSORTILE_ADC_Read(ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, ATMO_ADC_VoltageUnits_t units, int32_t *voltage, uint32_t numSamplesToAverage);

#ifdef __cplusplus
}
#endif

#endif /* __ATMO_ADC__H */
