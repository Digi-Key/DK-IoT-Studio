
/**
 ******************************************************************************
 * @file    interval_sensortile.c
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - SENSORTILE Interval API Implementation
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

#include "interval_sensortile.h"
#include "../app_src/atmosphere_platform.h"
#include "cmsis_os.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

const ATMO_INTERVAL_DriverInstance_t SENSORTILEIntervalDriverInstance = {
	ATMO_SENSORTILE_INTERVAL_Init,
	ATMO_SENSORTILE_INTERVAL_RemoveAbilityInterval,
	ATMO_SENSORTILE_INTERVAL_AddAbilityInterval,
	ATMO_SENSORTILE_INTERVAL_AddCallbackInterval
};

typedef struct {
	ATMO_Callback_t cb;
	unsigned int abilityHandle;
	bool isAbilityHandle;
	unsigned int delayTimeMs;
	osThreadId id;
} ATMO_SENSORTILE_IntervalArg_t;

#define ATMO_SENSORTILE_MAX_INTERVALS (50)
static ATMO_SENSORTILE_IntervalArg_t intervalArgs[50];
static unsigned int currentNumIntervals = 0;

static void ATMO_SENSORTILE_INTERVAL_Thread(void const *argument)
{
	ATMO_SENSORTILE_IntervalArg_t *intervalArg = (ATMO_SENSORTILE_IntervalArg_t *)argument;
	while(1)
	{
		if(intervalArg->isAbilityHandle)
		{
			ATMO_Lock();
			ATMO_AddAbilityExecute(intervalArg->abilityHandle, NULL);
			ATMO_Unlock();
		}
		else
		{
			ATMO_Lock();
			ATMO_AddCallbackExecute(intervalArg->cb, NULL);
			ATMO_Unlock();
		}
		ATMO_PLATFORM_DelayMilliseconds(intervalArg->delayTimeMs);
	}

}

ATMO_Status_t ATMO_SENSORTILE_INTERVAL_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber )
{
	ATMO_DriverInstanceData_t* intelCurieIntervalDriverInstance = (ATMO_DriverInstanceData_t *)malloc( sizeof( ATMO_DriverInstanceData_t ) );

	intelCurieIntervalDriverInstance->name = "SENSORTILE Interval";
	intelCurieIntervalDriverInstance->initialized = false;
	intelCurieIntervalDriverInstance->instanceNumber = 0;
	
	return ATMO_INTERVAL_AddDriverInstance( &SENSORTILEIntervalDriverInstance, intelCurieIntervalDriverInstance, instanceNumber );
}

ATMO_INTERVAL_Status_t ATMO_SENSORTILE_INTERVAL_Init(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_INTERVAL_Status_Success;
}

ATMO_INTERVAL_Status_t ATMO_SENSORTILE_INTERVAL_AddAbilityInterval(ATMO_DriverInstanceData_t *instance, unsigned int abilityHandle, unsigned int interval, ATMO_INTERVAL_Handle_t *intervalHandle)
{
	if(currentNumIntervals >= ATMO_SENSORTILE_MAX_INTERVALS)
	{
		return ATMO_INTERVAL_Status_Fail;
	}

	intervalArgs[currentNumIntervals].abilityHandle = abilityHandle;
	intervalArgs[currentNumIntervals].isAbilityHandle = true;
	intervalArgs[currentNumIntervals].delayTimeMs = interval;


	TaskHandle_t xHandle = NULL;
    BaseType_t xReturned = xTaskCreate( ATMO_SENSORTILE_INTERVAL_Thread, "User Interval", configMINIMAL_STACK_SIZE, (void *)&intervalArgs[currentNumIntervals], osPriorityAboveNormal, &xHandle );

    if( xReturned != pdPASS )
    {
    	return ATMO_INTERVAL_Status_Fail;
    }

	currentNumIntervals++;

	return ATMO_INTERVAL_Status_Success;
}

ATMO_INTERVAL_Status_t ATMO_SENSORTILE_INTERVAL_AddCallbackInterval(ATMO_DriverInstanceData_t *instance, ATMO_Callback_t cb, unsigned int interval, ATMO_INTERVAL_Handle_t *intervalHandle)
{
	if(currentNumIntervals >= ATMO_SENSORTILE_MAX_INTERVALS)
	{
		return ATMO_INTERVAL_Status_Fail;
	}

	intervalArgs[currentNumIntervals].cb = cb;
	intervalArgs[currentNumIntervals].isAbilityHandle = false;
	intervalArgs[currentNumIntervals].delayTimeMs = interval;


	TaskHandle_t xHandle = NULL;
    BaseType_t xReturned = xTaskCreate( ATMO_SENSORTILE_INTERVAL_Thread, "User Interval", configMINIMAL_STACK_SIZE, (void *)&intervalArgs[currentNumIntervals], osPriorityAboveNormal, &xHandle );

    if( xReturned != pdPASS )
    {
    	return ATMO_INTERVAL_Status_Fail;
    }
	currentNumIntervals++;

	return ATMO_INTERVAL_Status_Success;
}

ATMO_INTERVAL_Status_t ATMO_SENSORTILE_INTERVAL_RemoveAbilityInterval(ATMO_DriverInstanceData_t *instance, ATMO_INTERVAL_Handle_t intervalHandle)
{
	return ATMO_INTERVAL_Status_NotSupported;
}
