#include "ble_sensortile.h"
#include "bluenrg_utils.h"
#include "bluenrg_gap.h"
#include "bluenrg_gatt_aci.h"
#include "bluenrg_gap_aci.h"
#include "hci_const.h"
#include "bluenrg_aci_const.h"
#include "sm.h"
#include "main.h"
#include "TargetFeatures.h"
#include "stm32l4xx_hal_rng.h"

const ATMO_BLE_DriverInstance_t sensortileBleDriverInstance =
{
	ATMO_SENSORTILE_BLE_PeripheralInit,
	ATMO_SENSORTILE_BLE_PeripheralDeInit,
	ATMO_SENSORTILE_BLE_SetEnabled,
	ATMO_SENSORTILE_BLE_GetEnabled,
	ATMO_SENSORTILE_BLE_GetMacAddress,
	ATMO_SENSORTILE_BLE_GAPSetDeviceName,
	ATMO_SENSORTILE_BLE_GAPAdvertisingStart,
	ATMO_SENSORTILE_BLE_GAPAdvertisingStop,
	ATMO_SENSORTILE_BLE_GAPSetAdvertisedServiceUUID,
	ATMO_SENSORTILE_BLE_GAPAdverertisingSetManufacturerData,
	ATMO_SENSORTILE_BLE_GAPPairingCfg,
	ATMO_SENSORTILE_BLE_GAPDisconnect,
	ATMO_SENSORTILE_BLE_GATTSAddService,
	ATMO_SENSORTILE_BLE_GATTSAddCharacteristic,
	ATMO_SENSORTILE_BLE_GATTSGetCharacteristicValue,
	ATMO_SENSORTILE_BLE_GATTSRegisterCharacteristicCallback,
	ATMO_SENSORTILE_BLE_GATTSRegisterCharacteristicAbilityHandle,
	ATMO_SENSORTILE_BLE_GATTSSetCharacteristic,
	ATMO_SENSORTILE_BLE_GATTSWriteDescriptor,
	ATMO_SENSORTILE_BLE_GATTSSendIndicate,
	ATMO_SENSORTILE_BLE_GATTSSendNotify,
	ATMO_SENSORTILE_BLE_RegisterEventCallback,
	ATMO_SENSORTILE_BLE_RegisterEventAbilityHandle
};

typedef struct
{
	char shortLocalName[8];
	uint8_t primaryServiceUuid[16];
	uint8_t appearance;
	ATMO_BLE_AdvertisingParams_t params;
} _ATMO_SENSORTILE_BLE_AdvConfig_t;

typedef struct
{
	_ATMO_SENSORTILE_BLE_AdvConfig_t advConfig;
	ATMO_Callback_t eventCb[ATMO_BLE_EVENT_NumEvents];
	unsigned int abilityHandle[ATMO_BLE_EVENT_NumEvents];
	bool abilityHandleRegistered[ATMO_BLE_EVENT_NumEvents];
	ATMO_BLE_PairingCfg_t pairingCfg;
	RNG_HandleTypeDef RngHandle;
} _ATMO_SENSORTILE_BLE_Config_t;

static uint8_t bdaddr[6] = {0};

static TargetFeatures_t TargetBoardFeatures;

typedef struct {
	uint16_t sensorTileHandle;
	ATMO_UUID_t uuid;
} ATMO_SENSORTILE_ServiceRecord_t;

#define ATMO_SENSORTILE_MaxServices (128)
#define ATMO_SENSORTILE_MaxCharacteristics (128)
static ATMO_SENSORTILE_ServiceRecord_t _ATMO_SENSORTILE_ServiceHandle[ATMO_SENSORTILE_MaxServices];
static unsigned int _ATMO_SENSORTILE_NumServices = 0;

typedef struct
{
	ATMO_BLE_Handle_t atmoHandle;
	uint16_t sensorTileHandle;
	uint16_t sensorTileServiceHandle;
	ATMO_Callback_t eventCb[ATMO_BLE_Characteristic_NumEvents];
	unsigned int abilityHandle[ATMO_BLE_Characteristic_NumEvents];
	bool abilityHandleRegistered[ATMO_BLE_Characteristic_NumEvents];
} _ATMO_SENSORTILE_Characteristic_t;

static _ATMO_SENSORTILE_Characteristic_t _ATMO_SENSORTILE_Characteristic[ATMO_SENSORTILE_MaxCharacteristics];
static unsigned int _ATMO_SENSORTILE_NumCharacteristics = 0;

static _ATMO_SENSORTILE_BLE_Config_t _ATMO_SENSORTILE_BleConfig;

static _ATMO_SENSORTILE_Characteristic_t *_ATMO_SENSORTILE_BLE_ToAtmoHandle( uint16_t handle )
{
	for ( unsigned int i = 0; i < _ATMO_SENSORTILE_NumCharacteristics; i++ )
	{
		if ( _ATMO_SENSORTILE_Characteristic[i].sensorTileHandle == handle )
		{
			return &_ATMO_SENSORTILE_Characteristic[i];
		}
	}

	return NULL;
}


/** @brief Initialize the BlueNRG Stack
 * @param None
 * @retval None
 */
static void Init_BlueNRG_Stack( void )
{
	const char BoardName[8] = "ATMO";
	uint16_t service_handle, dev_name_char_handle, appearance_char_handle;
	int ret;
	uint8_t  hwVersion;
	uint16_t fwVersion;

#ifdef STATIC_BLE_MAC
	{
		uint8_t tmp_bdaddr[6] = {STATIC_BLE_MAC};
		int32_t i;

		for ( i = 0; i < 6; i++ )
		{
			bdaddr[i] = tmp_bdaddr[i];
		}
	}
#endif /* STATIC_BLE_MAC */

	/* Initialize the BlueNRG SPI driver */
	BNRG_SPI_Init();

	/* Initialize the BlueNRG HCI */
	HCI_Init();

	/* Reset BlueNRG hardware */
	BlueNRG_RST();

	/* get the BlueNRG HW and FW versions */
	getBlueNRGVersion( &hwVersion, &fwVersion );

	if ( hwVersion > 0x30 )
	{
		/* X-NUCLEO-IDB05A1 expansion board is used */
		TargetBoardFeatures.bnrg_expansion_board = IDB05A1;
	}
	else
	{
		/* X-NUCLEO-IDB0041 expansion board is used */
		TargetBoardFeatures.bnrg_expansion_board = IDB04A1;
	}

	/*
	 * Reset BlueNRG again otherwise it will fail.
	 */
	BlueNRG_RST();

	ret = aci_gatt_init();

	if ( ret )
	{
		STLBLE_PRINTF( "\r\nGATT_Init failed\r\n" );
		goto fail;
	}

	if ( TargetBoardFeatures.bnrg_expansion_board == IDB05A1 )
	{
		ret = aci_gap_init_IDB05A1( GAP_PERIPHERAL_ROLE_IDB05A1, 0, 0x07, &service_handle, &dev_name_char_handle, &appearance_char_handle );
	}
	else
	{
		ret = aci_gap_init_IDB04A1( GAP_PERIPHERAL_ROLE_IDB04A1, &service_handle, &dev_name_char_handle, &appearance_char_handle );
	}

	if ( ret != BLE_STATUS_SUCCESS )
	{
		STLBLE_PRINTF( "\r\nGAP_Init failed\r\n" );
		goto fail;
	}

	ret = aci_gatt_update_char_value( service_handle, dev_name_char_handle, 0,
	                                  7/*strlen(BoardName)*/, ( uint8_t * )BoardName );

	if ( ret )
	{
		STLBLE_PRINTF( "\r\naci_gatt_update_char_value failed\r\n" );

		while ( 1 );
	}

	// Get MAC address
	uint8_t macAddrLenOut = 0;
	ret = aci_hal_read_config_data(0x80, 6, &macAddrLenOut, bdaddr);

	if(ret)
	{
		ATMO_PLATFORM_DebugPrint("Error Getting MAC Address\r\n");
	}

	STLBLE_PRINTF( "SERVER: BLE Stack Initialized \r\n"
	               "\t\tBoard type=%s HWver=%d, FWver=%d.%d.%c\r\n"
	               "\t\tBoardName= %s\r\n"
	               "\t\tBoardMAC = %x:%x:%x:%x:%x:%x\r\n\n",
	               "SensorTile",
	               hwVersion,
	               fwVersion >> 8,
	               ( fwVersion >> 4 ) & 0xF,
	               ( hwVersion > 0x30 ) ? ( 'a' + ( fwVersion & 0xF ) - 1 ) : 'a',
	               BoardName,
	               bdaddr[5], bdaddr[4], bdaddr[3], bdaddr[2], bdaddr[1], bdaddr[0] );

	/* Set output power level */
	aci_hal_set_tx_power_level( 1, 4 );

	return;

fail:
	return;
}


static void _ATMO_SENSORTILE_BLE_DispatchBleEvent( ATMO_BLE_Event_t event, ATMO_Value_t *value )
{
	if ( _ATMO_SENSORTILE_BleConfig.abilityHandleRegistered[event] )
	{
		ATMO_AddAbilityExecute( _ATMO_SENSORTILE_BleConfig.abilityHandle[event], value );
	}

	if ( _ATMO_SENSORTILE_BleConfig.eventCb[event] != NULL )
	{
		ATMO_AddCallbackExecute( _ATMO_SENSORTILE_BleConfig.eventCb[event], value );
	}
}

static void _ATMO_SENSORTILE_BLE_DispatchBleCharEvent( ATMO_BLE_Characteristic_Event_t event, ATMO_BLE_Handle_t handle, ATMO_Value_t *value )
{
	if ( _ATMO_SENSORTILE_Characteristic[handle].abilityHandleRegistered[event] )
	{
		ATMO_AddAbilityExecute( _ATMO_SENSORTILE_Characteristic[handle].abilityHandle[event], value );
	}

	if ( _ATMO_SENSORTILE_Characteristic[handle].eventCb[event] != NULL )
	{
		ATMO_AddCallbackExecute( _ATMO_SENSORTILE_Characteristic[handle].eventCb[event], value );
	}
}



/**
 * @brief  This function is called whenever there is an ACI event to be processed.
 * @note   Inside this function each event must be identified and correctly
 *         parsed.
 * @param  void *pckt Pointer to the ACI packet
 * @retval None
 */

void HCI_Event_CB( void *pckt )
{
	hci_uart_pckt *hci_pckt = pckt;
	hci_event_pckt *event_pckt = ( hci_event_pckt * )hci_pckt->data;

	if ( hci_pckt->type != HCI_EVENT_PKT )
	{
		return;
	}


	switch ( event_pckt->evt )
	{

		case EVT_DISCONN_COMPLETE:
		{
			//GAP_DisconnectionComplete_CB();
			_ATMO_SENSORTILE_BLE_DispatchBleEvent( ATMO_BLE_EVENT_Disconnected, NULL );
		}
		break;

		case EVT_LE_META_EVENT:
		{
			evt_le_meta_event *evt = ( void * )event_pckt->data;

			switch ( evt->subevent )
			{
				case EVT_LE_CONN_COMPLETE:
				{
					evt_le_connection_complete *cc = ( void * )evt->data;
					_ATMO_SENSORTILE_BLE_DispatchBleEvent( ATMO_BLE_EVENT_Connected, NULL );
					//GAP_ConnectionComplete_CB(cc->peer_bdaddr, cc->handle);
				}
				break;
			}
		}
		break;

		case EVT_VENDOR:
		{
			evt_blue_aci *blue_evt = ( void * )event_pckt->data;

			switch ( blue_evt->ecode )
			{
				case EVT_BLUE_GAP_PASS_KEY_REQUEST:
				{
					evt_gap_pass_key_req *evt = ( evt_gap_pass_key_req * )blue_evt->data;
					// Gen random number
					uint32_t randomKey = 0;
					HAL_RNG_GenerateRandomNumber( &_ATMO_SENSORTILE_BleConfig.RngHandle, &randomKey );

					ATMO_Value_t keyVal;
					ATMO_InitValue( &keyVal );
					ATMO_CreateValueUnsignedInt( &keyVal, randomKey );
					_ATMO_SENSORTILE_BLE_DispatchBleEvent( ATMO_BLE_EVENT_PairingRequested, &keyVal );
					ATMO_Free( &keyVal );
					aci_gap_pass_key_response( evt->conn_handle, randomKey );
					break;
				}

				case EVT_BLUE_GAP_PAIRING_CMPLT:
				{
					evt_gap_pairing_cmplt *evt = ( evt_gap_pairing_cmplt * ) blue_evt->data;

					if ( evt->status == 0x00 )
					{
						_ATMO_SENSORTILE_BLE_DispatchBleEvent( ATMO_BLE_EVENT_PairingSuccess, NULL );
					}
					else
					{
						_ATMO_SENSORTILE_BLE_DispatchBleEvent( ATMO_BLE_EVENT_PairingFailed, NULL );
					}
				}

				case EVT_BLUE_GATT_READ_PERMIT_REQ:
				{
					evt_gatt_read_permit_req *pr = ( void * )blue_evt->data;
					//Attribute_Read_CB(pr->attr_handle);
				}
				break;

				case EVT_BLUE_GATT_ATTRIBUTE_MODIFIED:
				{
					evt_gatt_attr_modified_IDB05A1 *evt = ( evt_gatt_attr_modified_IDB05A1 * )blue_evt->data;

					// Not sure why
					// The handle we are given is one more than the handle we were given when we added the char to the gatt db
					_ATMO_SENSORTILE_Characteristic_t *characteristic = NULL;

					characteristic = _ATMO_SENSORTILE_BLE_ToAtmoHandle( evt->attr_handle - 1 );

					// Value was written
					if ( characteristic != NULL )
					{
						ATMO_Value_t val;
						ATMO_InitValue( &val );
						ATMO_CreateValueBinary( &val, evt->att_data, evt->data_length );
						_ATMO_SENSORTILE_BLE_DispatchBleCharEvent( ATMO_BLE_Characteristic_Written, characteristic->atmoHandle, &val );
						ATMO_FreeValue( &val );
						break;
					}

					characteristic = _ATMO_SENSORTILE_BLE_ToAtmoHandle( evt->attr_handle - 2 );

					// This means that the descriptor was written
					if ( characteristic != NULL )
					{
						if ( evt->att_data[0] == 0x0 )
						{
							_ATMO_SENSORTILE_BLE_DispatchBleCharEvent( ATMO_BLE_Characteristic_Unsubscribed, characteristic->atmoHandle, NULL );
						}
						else
						{
							_ATMO_SENSORTILE_BLE_DispatchBleCharEvent( ATMO_BLE_Characteristic_Subscribed, characteristic->atmoHandle, NULL );
						}
					}
				}
				break;
			}
		}
		break;
	}
}

ATMO_Status_t ATMO_SENSORTILE_BLE_AddDriverInstance( ATMO_DriverInstanceHandle_t *instanceNumber )
{
	ATMO_DriverInstanceData_t *driverInstanceData = ( ATMO_DriverInstanceData_t * )malloc( sizeof( ATMO_DriverInstanceData_t ) );

	driverInstanceData->name = "SENSORTILE BLE";
	driverInstanceData->initialized = false;
	driverInstanceData->instanceNumber = 0;
	driverInstanceData->argument = NULL;

	return ATMO_BLE_AddDriverInstance( &sensortileBleDriverInstance, driverInstanceData, instanceNumber );
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_PeripheralInit( ATMO_DriverInstanceData_t *instance )
{
	static bool _ATMO_SENSORTILE_BLE_Initialized = false;

	if ( !_ATMO_SENSORTILE_BLE_Initialized )
	{
		memset( &_ATMO_SENSORTILE_BleConfig, 0, sizeof( _ATMO_SENSORTILE_BleConfig ) );
		memset( &_ATMO_SENSORTILE_Characteristic, 0, sizeof( _ATMO_SENSORTILE_Characteristic ) );
		memset( &TargetBoardFeatures, 0, sizeof( TargetBoardFeatures ) );

		/* Initialize the BlueNRG */
		Init_BlueNRG_Stack();

		_ATMO_SENSORTILE_BleConfig.pairingCfg.type = ATMO_BLE_PairingType_JustWorks;

		ATMO_SENSORTILE_BLE_GAPPairingCfg( NULL, &_ATMO_SENSORTILE_BleConfig.pairingCfg );

		HAL_RNG_Init( &_ATMO_SENSORTILE_BleConfig.RngHandle );
	}

	_ATMO_SENSORTILE_BLE_Initialized = true;
	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_SetEnabled( ATMO_DriverInstanceData_t *instance, bool enabled )
{
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GetEnabled( ATMO_DriverInstanceData_t *instance, bool *enabled )
{
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_PeripheralDeInit( ATMO_DriverInstanceData_t *instance )
{
	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GetMacAddress( ATMO_DriverInstanceData_t *instance, ATMO_BLE_MacAddress_t *address )
{
	uint8_t bdAddrBigEndian[6] = {bdaddr[5], bdaddr[4], bdaddr[3], bdaddr[2], bdaddr[1], bdaddr[0]};

	memcpy( address->data, bdAddrBigEndian, 6 );

	return ATMO_BLE_Status_Success;
}


ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPSetDeviceName( ATMO_DriverInstanceData_t *instance, const char *name )
{
	_ATMO_SENSORTILE_BLE_Config_t *config = &_ATMO_SENSORTILE_BleConfig;
	strncpy( config->advConfig.shortLocalName, name, 7 );
	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPAdvertisingStart( ATMO_DriverInstanceData_t *instance, ATMO_BLE_AdvertisingParams_t *params )
{
	_ATMO_SENSORTILE_BLE_Config_t *config = &_ATMO_SENSORTILE_BleConfig;
	/* disable scan response */
	hci_le_set_scan_resp_data( 0, NULL );

	uint8_t servUuid[17];
	servUuid[0] = AD_TYPE_128_BIT_SERV_UUID;

	uint8_t localName[8] = {0};
	localName[0] = AD_TYPE_COMPLETE_LOCAL_NAME;
	strncpy( &localName[1], config->advConfig.shortLocalName, 7 );
	memcpy( &servUuid[1], config->advConfig.primaryServiceUuid, 16 );

	tBleStatus ret = aci_gap_set_discoverable( ADV_IND, 0, 255, STATIC_RANDOM_ADDR, NO_WHITE_LIST_USE, strlen( config->advConfig.shortLocalName ) + 1, localName, 17, servUuid, 0, 0 );
	return ( ret == 0 ) ? ATMO_BLE_Status_Success : ATMO_BLE_Status_Fail;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPAdvertisingStop( ATMO_DriverInstanceData_t *instance )
{
	aci_gap_set_non_discoverable();
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPSetAdvertisedServiceUUID( ATMO_DriverInstanceData_t *instance, const char *uuid )
{
	ATMO_UUID_t uuidBin;

	ATMO_StringToUuid( uuid, &uuidBin, ATMO_ENDIAN_Type_Little );

	_ATMO_SENSORTILE_BLE_Config_t *config = &_ATMO_SENSORTILE_BleConfig;

	memcpy( config->advConfig.primaryServiceUuid, uuidBin.data, 16 );

	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPAdverertisingSetManufacturerData( ATMO_DriverInstanceData_t *instance, ATMO_BLE_AdvertisingData_t *data )
{
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPPairingCfg( ATMO_DriverInstanceData_t *instance, ATMO_BLE_PairingCfg_t *config )
{
	switch ( config->type )
	{
		case ATMO_BLE_PairingType_JustWorks:
		{
			aci_gap_set_io_capability( IO_CAP_NO_INPUT_NO_OUTPUT );
			aci_gap_set_auth_requirement( MITM_PROTECTION_NOT_REQUIRED,
			                              OOB_AUTH_DATA_ABSENT,
			                              NULL, 7, 16,
			                              USE_FIXED_PIN_FOR_PAIRING, 123456,
			                              BONDING );
			break;
		}

		case ATMO_BLE_PairingType_RandomKey:
		{
			aci_gap_set_io_capability( IO_CAP_DISPLAY_ONLY );
			aci_gap_set_auth_requirement( MITM_PROTECTION_REQUIRED,
			                              OOB_AUTH_DATA_ABSENT,
			                              NULL, 7, 16,
			                              DONOT_USE_FIXED_PIN_FOR_PAIRING, 0,
			                              BONDING );
			break;
		}

		case ATMO_BLE_PairingType_UserKey:
		{
			aci_gap_set_io_capability( IO_CAP_DISPLAY_ONLY );
			aci_gap_set_auth_requirement( MITM_PROTECTION_REQUIRED,
			                              OOB_AUTH_DATA_ABSENT,
			                              NULL, 7, 16,
			                              USE_FIXED_PIN_FOR_PAIRING, config->pairingKey,
			                              BONDING );
			break;
		}

		default:
		{
			break;
		}
	}

	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GAPDisconnect( ATMO_DriverInstanceData_t *instance )
{
	return ATMO_BLE_Status_NotSupported;
}


ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSAddService( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t *handle, const char *serviceUUID )
{

	if ( _ATMO_SENSORTILE_NumServices >= ATMO_SENSORTILE_MaxServices )
	{
		return ATMO_BLE_Status_Fail;
	}

	ATMO_UUID_t uuidBin;
	ATMO_StringToUuid( serviceUUID, &uuidBin, ATMO_ENDIAN_Type_Little );

	bool serviceExists = false;

	// Check to see if service is already added
	for(unsigned int i = 0; i <_ATMO_SENSORTILE_NumServices; i++)
	{
		if(memcmp(&_ATMO_SENSORTILE_ServiceHandle[i].uuid, &uuidBin, sizeof(uuidBin)) == 0)
		{
			serviceExists = true;
			*handle = i;
			return ATMO_BLE_Status_Success;
		}
	}


	tBleStatus ret = aci_gatt_add_serv( UUID_TYPE_128,  uuidBin.data, PRIMARY_SERVICE,
	                                    10,
	                                    &_ATMO_SENSORTILE_ServiceHandle[_ATMO_SENSORTILE_NumServices].sensorTileHandle );

	if ( ret == 0 )
	{
		memcpy(&_ATMO_SENSORTILE_ServiceHandle[_ATMO_SENSORTILE_NumServices].uuid, &uuidBin, sizeof(uuidBin));
		*handle = _ATMO_SENSORTILE_NumServices++;

		return ATMO_BLE_Status_Success;
	}

	*handle = 0;
	return ATMO_BLE_Status_Fail;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSAddCharacteristic( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t *handle, ATMO_BLE_Handle_t serviceHandle, const char *characteristicUUID, uint8_t properties, uint8_t permissions, uint32_t maxLen )
{
	if ( _ATMO_SENSORTILE_NumCharacteristics >= ATMO_SENSORTILE_MaxCharacteristics )
	{
		return ATMO_BLE_Status_Fail;
	}

	ATMO_UUID_t uuidBin;
	ATMO_StringToUuid( characteristicUUID, &uuidBin, ATMO_ENDIAN_Type_Little );


	tBleStatus ret =  aci_gatt_add_char( _ATMO_SENSORTILE_ServiceHandle[serviceHandle].sensorTileHandle, UUID_TYPE_128, uuidBin.data, maxLen,
	                                     properties,
	                                     0,
	                                     ( properties & ATMO_BLE_Property_Write ) ? GATT_NOTIFY_ATTRIBUTE_WRITE : 0,
	                                     16, 0, &_ATMO_SENSORTILE_Characteristic[_ATMO_SENSORTILE_NumCharacteristics].sensorTileHandle );

	if ( ret == 0 )
	{
		_ATMO_SENSORTILE_Characteristic[_ATMO_SENSORTILE_NumCharacteristics].atmoHandle = _ATMO_SENSORTILE_NumCharacteristics;
		_ATMO_SENSORTILE_Characteristic[_ATMO_SENSORTILE_NumCharacteristics].sensorTileServiceHandle = _ATMO_SENSORTILE_ServiceHandle[serviceHandle].sensorTileHandle;
		*handle = _ATMO_SENSORTILE_NumCharacteristics++;
		return ATMO_BLE_Status_Success;
	}

	*handle = 0;
	return ATMO_BLE_Status_Fail;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSGetCharacteristicValue( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t handle, uint8_t *valueBuf, uint32_t valueBufLen, uint32_t *valueLen )
{
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSRegisterCharacteristicCallback( ATMO_DriverInstanceData_t *instance,  ATMO_BLE_Handle_t handle, ATMO_BLE_Characteristic_Event_t event, ATMO_Callback_t cbFunc )
{
	_ATMO_SENSORTILE_Characteristic[handle].eventCb[event] = cbFunc;
	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSRegisterCharacteristicAbilityHandle( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t handle, ATMO_BLE_Characteristic_Event_t event, unsigned int abilityHandler )
{
	_ATMO_SENSORTILE_Characteristic[handle].abilityHandle[event] = abilityHandler;
	_ATMO_SENSORTILE_Characteristic[handle].abilityHandleRegistered[event] = true;
	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSSetCharacteristic( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t handle, uint16_t length, uint8_t *value, ATMO_BLE_CharProperties_t *properties )
{
	tBleStatus ret = aci_gatt_update_char_value( _ATMO_SENSORTILE_Characteristic[handle].sensorTileServiceHandle, _ATMO_SENSORTILE_Characteristic[handle].sensorTileHandle,
	                 0, length, value );

	return ( ret == 0 ) ? ATMO_BLE_Status_Success : ATMO_BLE_Status_Fail;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSWriteDescriptor( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t handle, uint16_t length, uint8_t *value, ATMO_BLE_CharProperties_t *properties )
{
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSSendIndicate( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t handle, uint16_t size, uint8_t *value )
{
	return ATMO_BLE_Status_NotSupported;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_GATTSSendNotify( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Handle_t handle, uint16_t size, uint8_t *value )
{
	return ATMO_SENSORTILE_BLE_GATTSSetCharacteristic( instance, handle, size, value, NULL );
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_RegisterEventCallback( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Event_t event, ATMO_Callback_t cb )
{
	_ATMO_SENSORTILE_BLE_Config_t *config = &_ATMO_SENSORTILE_BleConfig;
	config->eventCb[event] = cb;
	return ATMO_BLE_Status_Success;
}

ATMO_BLE_Status_t ATMO_SENSORTILE_BLE_RegisterEventAbilityHandle( ATMO_DriverInstanceData_t *instance, ATMO_BLE_Event_t event, unsigned int abilityHandle )
{
	_ATMO_SENSORTILE_BLE_Config_t *config = &_ATMO_SENSORTILE_BleConfig;
	config->abilityHandle[event] = abilityHandle;
	config->abilityHandleRegistered[event] = true;
	return ATMO_BLE_Status_Success;
}
