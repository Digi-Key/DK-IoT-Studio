/**
 ******************************************************************************
 * @file    spi_sensortile.c
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - SENSORTILE SPI API Implementation
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

#include "spi_sensortile.h"
#include "stm32l4xx_hal.h"

#define ATMO_SENSORTILE_NUM_SPI (3)

#define ATMO_SENSORTILE_SPI1 (0)
#define ATMO_SENSORTILE_SPI2 (1)
#define ATMO_SENSORTILE_SPI3 (2)

static SPI_TypeDef* ATMO_SENSORTILE_SPI_SpiHandles[ATMO_SENSORTILE_NUM_SPI] = {SPI1, SPI2, SPI3};
static ATMO_SPI_Peripheral_t ATMO_SENSORTILE_SPI_PeriphConfig[ATMO_SENSORTILE_NUM_SPI];
static SPI_HandleTypeDef ATMO_SENSORTILE_SPI_DriverHandles[ATMO_SENSORTILE_NUM_SPI];
static ATMO_DriverInstanceHandle_t ATMO_SENSORTILE_SPI_GpioDriverInstance = 0;

const ATMO_SPI_DriverInstance_t sensortileSPIDriverInstance = {
	ATMO_SENSORTILE_SPI_Init,
	ATMO_SENSORTILE_SPI_DeInit,
	ATMO_SENSORTILE_SPI_SetConfiguration,
	ATMO_SENSORTILE_SPI_GetConfiguration,
	ATMO_SENSORTILE_SPI_MasterSetDeviceConfiguration,
	ATMO_SENSORTILE_SPI_MasterGetDeviceConfiguration,
	ATMO_SENSORTILE_SPI_MasterAssertSlaveSelect,
	ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect,
	ATMO_SENSORTILE_SPI_MasterWrite,
	ATMO_SENSORTILE_SPI_MasterRead,
};


/**
 * @brief  This function reads a single byte on SPI 3-wire.
 * @param  xSpiHandle : SPI Handler.
 * @param  val : value.
 * @retval None
 */
static void SPI_3WireRead(SPI_HandleTypeDef* xSpiHandle, uint8_t *val)
{
  /* In master RX mode the clock is automaticaly generated on the SPI enable.
  So to guarantee the clock generation for only one data, the clock must be
  disabled after the first bit and before the latest bit */
  /* Interrupts should be disabled during this operation */

  __disable_irq();

  __HAL_SPI_ENABLE(xSpiHandle);
  __asm("dsb\n");
  __asm("dsb\n");
  __HAL_SPI_DISABLE(xSpiHandle);

  __enable_irq();

  while ((xSpiHandle->Instance->SR & SPI_FLAG_RXNE) != SPI_FLAG_RXNE);
  /* read the received data */
  *val = *(__IO uint8_t *) &xSpiHandle->Instance->DR;
  while ((xSpiHandle->Instance->SR & SPI_FLAG_BSY) == SPI_FLAG_BSY);
}

/**
 * @brief  This function reads multiple bytes on SPI 3-wire.
 * @param  xSpiHandle: SPI Handler.
 * @param  val: value.
 * @param  nBytesToRead: number of bytes to read.
 * @retval None
 */
static void SPI_3WireRead_nBytes(SPI_HandleTypeDef* xSpiHandle, uint8_t *val, uint16_t nBytesToRead)
{
  /* Interrupts should be disabled during this operation */
  __disable_irq();
  __HAL_SPI_ENABLE(xSpiHandle);

  /* Transfer loop */
  while (nBytesToRead > 1U)
  {
    /* Check the RXNE flag */
    if (xSpiHandle->Instance->SR & SPI_FLAG_RXNE)
    {
      /* read the received data */
      *val = *(__IO uint8_t *) &xSpiHandle->Instance->DR;
      val += sizeof(uint8_t);
      nBytesToRead--;
    }
  }
  /* In master RX mode the clock is automaticaly generated on the SPI enable.
  So to guarantee the clock generation for only one data, the clock must be
  disabled after the first bit and before the latest bit of the last Byte received */
  /* __DSB instruction are inserted to garantee that clock is Disabled in the right timeframe */

  __DSB();
  __DSB();
  __HAL_SPI_DISABLE(xSpiHandle);

  __enable_irq();

  while ((xSpiHandle->Instance->SR & SPI_FLAG_RXNE) != SPI_FLAG_RXNE);
  /* read the received data */
  *val = *(__IO uint8_t *) &xSpiHandle->Instance->DR;
  while ((xSpiHandle->Instance->SR & SPI_FLAG_BSY) == SPI_FLAG_BSY);
}

/**
 * @brief  This function writes a single byte on SPI 3-wire.
 * @param  xSpiHandle: SPI Handler.
 * @param  val: value.
 * @retval None
 */
void SPI_3WireWrite(SPI_HandleTypeDef* xSpiHandle, uint8_t val)
{
  /* check TXE flag */
  while ((xSpiHandle->Instance->SR & SPI_FLAG_TXE) != SPI_FLAG_TXE);

  /* Write the data */
  *((__IO uint8_t*) &xSpiHandle->Instance->DR) = val;

  /* Wait BSY flag */
  while ((xSpiHandle->Instance->SR & SPI_FLAG_FTLVL) != SPI_FTLVL_EMPTY);
  while ((xSpiHandle->Instance->SR & SPI_FLAG_BSY) == SPI_FLAG_BSY);
}

ATMO_Status_t ATMO_SENSORTILE_SPI_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber, ATMO_DriverInstanceHandle_t gpioInstance)
{
	ATMO_SENSORTILE_SPI_GpioDriverInstance = gpioInstance;
	for(unsigned int i = 0; i < ATMO_SENSORTILE_NUM_SPI; i++)
	{
		ATMO_DriverInstanceData_t *driverInstanceData = (ATMO_DriverInstanceData_t *)ATMO_Malloc(sizeof(ATMO_DriverInstanceData_t));

		driverInstanceData->name = "SENSORTILE SPI";
		driverInstanceData->initialized = false;
		driverInstanceData->instanceNumber = 0;
		driverInstanceData->argument = ATMO_Malloc(sizeof(uint32_t));
		*((uint32_t *)driverInstanceData->argument) = i;

		ATMO_SPI_AddDriverInstance( &sensortileSPIDriverInstance, driverInstanceData, instanceNumber );
	}

	return ATMO_Status_Success;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_Init( ATMO_DriverInstanceData_t* instance )
{
	uint32_t handle = *((uint32_t *)instance->argument);

	switch(handle)
	{
		case ATMO_SENSORTILE_SPI2:
		{
			__SPI2_CLK_ENABLE();
			break;
		}
		case ATMO_SENSORTILE_SPI3:
		{
			__SPI3_CLK_ENABLE();
			break;
		}
		default:
		{
			break;
		}
	}

	ATMO_SENSORTILE_SPI_DriverHandles[1].Instance = SPI2;
	ATMO_SENSORTILE_SPI_DriverHandles[2].Instance = SPI3;

	memset(ATMO_SENSORTILE_SPI_PeriphConfig, 0, sizeof(ATMO_SENSORTILE_SPI_PeriphConfig));
	return ATMO_SPI_Status_Success;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_DeInit( ATMO_DriverInstanceData_t* instance )
{
	return ATMO_SPI_Status_NotSupported;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_SetConfiguration( ATMO_DriverInstanceData_t* instance, const ATMO_SPI_Peripheral_t* config )
{
	uint32_t handle = *((uint32_t *)instance->argument);

	if(handle >= ATMO_SENSORTILE_NUM_SPI || handle == ATMO_SENSORTILE_SPI1)
	{
		return ATMO_SPI_Status_Fail;
	}

	switch(handle)
	{
		case ATMO_SENSORTILE_SPI1:
		{
			// Can't really get to SPI1 anyway
			break;
		}
		case ATMO_SENSORTILE_SPI2:
		{
			GPIO_InitTypeDef GPIO_InitStruct;
		    GPIO_InitStruct.Pin = GPIO_PIN_15;
		    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
		    GPIO_InitStruct.Pull = GPIO_PULLUP;
		    GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
		    GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
		    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

		    GPIO_InitStruct.Pin = GPIO_PIN_13;
		    GPIO_InitStruct.Pull = GPIO_PULLUP;
		    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

		    SPI_1LINE_TX(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
		    __HAL_SPI_ENABLE(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
		    break;
		}
		case ATMO_SENSORTILE_SPI3:
		{
			GPIO_InitTypeDef GPIO_InitStructure;
			 /* configure SPI SCK */
			  GPIO_InitStructure.Pin = GPIO_PIN_9;
			  GPIO_InitStructure.Mode = GPIO_MODE_AF_PP;
			  GPIO_InitStructure.Pull  = GPIO_NOPULL;
			  GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
			  GPIO_InitStructure.Alternate = GPIO_AF6_SPI3;
			  HAL_GPIO_Init(GPIOG, &GPIO_InitStructure);

			  /* configure SPI MISO and MOSI */
			  GPIO_InitStructure.Pin = (GPIO_PIN_10);
			  GPIO_InitStructure.Mode = GPIO_MODE_AF_PP;
			  GPIO_InitStructure.Pull  = GPIO_NOPULL;
			  GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
			  GPIO_InitStructure.Alternate = GPIO_AF6_SPI3;
			  HAL_GPIO_Init(GPIOG, &GPIO_InitStructure);

			  GPIO_InitStructure.Pin = (GPIO_PIN_11 );
			  GPIO_InitStructure.Mode = GPIO_MODE_AF_PP;
			  GPIO_InitStructure.Pull  = GPIO_PULLUP;
			  GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
			  GPIO_InitStructure.Alternate = GPIO_AF6_SPI3;
			  HAL_GPIO_Init(GPIOG, &GPIO_InitStructure);
			break;
		}
	}

	// Set default configuration
	return ATMO_SENSORTILE_SPI_MasterSetDeviceConfiguration(instance, -1, &config->deviceConfig);
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_GetConfiguration( ATMO_DriverInstanceData_t* instance, ATMO_SPI_Peripheral_t* config )
{
	return ATMO_SPI_Status_NotSupported;
}

static uint32_t ATMO_SENSORTILE_SPI_GetPrescale(uint32_t handle, uint32_t desiredBaud)
{
	uint32_t clockRate = (handle == ATMO_SENSORTILE_SPI2 || handle == ATMO_SENSORTILE_SPI3) ? HAL_RCC_GetPCLK1Freq() : HAL_RCC_GetPCLK2Freq();
	uint32_t spiBaudRates[8] =
	{
			SPI_BAUDRATEPRESCALER_2,
			SPI_BAUDRATEPRESCALER_4,
			SPI_BAUDRATEPRESCALER_8,
			SPI_BAUDRATEPRESCALER_16,
			SPI_BAUDRATEPRESCALER_32,
			SPI_BAUDRATEPRESCALER_64,
			SPI_BAUDRATEPRESCALER_128,
			SPI_BAUDRATEPRESCALER_256,
	};

	for(unsigned int i = 0; i < 8; i++)
	{
		uint32_t div = (1 << (i + 1));
		if((clockRate / div) <= desiredBaud)
		{
			return spiBaudRates[i];
		}
	}

	return spiBaudRates[7];
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_MasterSetDeviceConfiguration( ATMO_DriverInstanceData_t* instance, ATMO_SPI_CS_t csPin, const ATMO_SPI_Device_t* config )
{
	uint32_t handle = *((uint32_t *)instance->argument);

	if(handle >= ATMO_SENSORTILE_NUM_SPI || handle == ATMO_SENSORTILE_SPI1)
	{
		return ATMO_SPI_Status_Fail;
	}

	SPI_HandleTypeDef *spiHandle = &ATMO_SENSORTILE_SPI_DriverHandles[handle];
	spiHandle->Instance = ATMO_SENSORTILE_SPI_SpiHandles[handle];
	spiHandle->Init.Mode = SPI_MODE_MASTER;

	// SPI2 is 3 wire
	if(handle == ATMO_SENSORTILE_SPI2)
	{
		spiHandle->Init.Direction = SPI_DIRECTION_1LINE;
	}
	else
	{
		spiHandle->Init.Direction = SPI_DIRECTION_2LINES;
	}

	switch(config->clockMode)
	{
		case ATMO_SPI_ClockMode_0:
		{
			spiHandle->Init.CLKPolarity = SPI_POLARITY_LOW;
			spiHandle->Init.CLKPhase = SPI_PHASE_1EDGE;
			break;
		}
		case ATMO_SPI_ClockMode_1:
		{
			spiHandle->Init.CLKPolarity = SPI_POLARITY_LOW;
			spiHandle->Init.CLKPhase = SPI_PHASE_2EDGE;
			break;
		}
		case ATMO_SPI_ClockMode_2:
		{
			spiHandle->Init.CLKPolarity = SPI_POLARITY_HIGH;
			spiHandle->Init.CLKPhase = SPI_PHASE_1EDGE;
			break;
		}
		case ATMO_SPI_ClockMode_3:
		{
			spiHandle->Init.CLKPolarity = SPI_POLARITY_HIGH;
			spiHandle->Init.CLKPhase = SPI_PHASE_2EDGE;
			break;
		}
		default:
		{
			spiHandle->Init.CLKPolarity = SPI_POLARITY_HIGH;
			spiHandle->Init.CLKPhase = SPI_PHASE_2EDGE;
			break;
		}
	}

	spiHandle->Init.DataSize = SPI_DATASIZE_8BIT;
	spiHandle->Init.NSS = SPI_NSS_SOFT;
	spiHandle->Init.BaudRatePrescaler = ATMO_SENSORTILE_SPI_GetPrescale(handle, config->baudRate);
	spiHandle->Init.FirstBit = (config->msbFirst) ? SPI_FIRSTBIT_MSB : SPI_FIRSTBIT_LSB;
	spiHandle->Init.TIMode = SPI_TIMODE_DISABLED;
	spiHandle->Init.CRCCalculation = SPI_CRCCALCULATION_DISABLED;
	spiHandle->Init.CRCPolynomial = 7;
	spiHandle->Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
	spiHandle->Init.NSSPMode = SPI_NSS_PULSE_DISABLED;

	if( HAL_SPI_Init(spiHandle) != HAL_OK)
	{
		return ATMO_SPI_Status_Fail;
	}

	if(handle == ATMO_SENSORTILE_SPI2)
	{
		/* Change the data line to output and enable the SPI */
		SPI_1LINE_TX(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
		__HAL_SPI_ENABLE(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
	}

	memcpy(&ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig, config, sizeof(ATMO_SPI_Device_t));

	return ATMO_SPI_Status_Success;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_MasterGetDeviceConfiguration( ATMO_DriverInstanceData_t* instance, ATMO_SPI_CS_t csPin, ATMO_SPI_Device_t* config )
{
	return ATMO_SPI_Status_NotSupported;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_MasterAssertSlaveSelect( ATMO_DriverInstanceData_t* instance, ATMO_SPI_CS_t csPin, bool ssActiveLow )
{
	if(csPin < 0)
	{
		return ATMO_SPI_Status_Success;
	}

	ATMO_GPIO_SetPinState(ATMO_SENSORTILE_SPI_GpioDriverInstance, csPin, ssActiveLow ? ATMO_GPIO_PinState_Low : ATMO_GPIO_PinState_High);
	return ATMO_SPI_Status_Success;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect( ATMO_DriverInstanceData_t* instance, ATMO_SPI_CS_t csPin, bool ssActiveLow )
{
	if(csPin < 0)
	{
		return ATMO_SPI_Status_Success;
	}

	ATMO_GPIO_SetPinState(ATMO_SENSORTILE_SPI_GpioDriverInstance, csPin, ssActiveLow ? ATMO_GPIO_PinState_High : ATMO_GPIO_PinState_Low);
	return ATMO_SPI_Status_Success;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_MasterWrite( ATMO_DriverInstanceData_t* instance, ATMO_SPI_CS_t csPin, const uint8_t* cmdBytes, uint16_t numCmdBytes, const uint8_t* writeBytes, uint16_t numWriteBytes, uint16_t timeout_ms )
{
	uint32_t handle = *((uint32_t *)instance->argument);

	if(handle >= ATMO_SENSORTILE_NUM_SPI || handle == ATMO_SENSORTILE_SPI1)
	{
		return ATMO_SPI_Status_Fail;
	}

	if(handle == ATMO_SENSORTILE_SPI2)
	{
		/* Change the data line to output and enable the SPI */
		SPI_1LINE_TX(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
		__HAL_SPI_ENABLE(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
	}

	HAL_StatusTypeDef halStatus = HAL_OK;

	ATMO_SENSORTILE_SPI_MasterAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);

	if(cmdBytes != NULL && numCmdBytes > 0)
	{
		if(handle == ATMO_SENSORTILE_SPI2)
		{
			for(unsigned int i = 0; i < numCmdBytes; i++)
			{
				SPI_3WireWrite(&ATMO_SENSORTILE_SPI_DriverHandles[handle], cmdBytes[i]);
			}
		}
		else
		{
			halStatus = HAL_SPI_Transmit(ATMO_SENSORTILE_SPI_SpiHandles[handle], cmdBytes, numCmdBytes, timeout_ms);
		}

		if(!ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssContinuous)
		{
			ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
		}
	}

	if(halStatus != HAL_OK)
	{
		ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
		return ATMO_SPI_Status_Fail;
	}

	if(!ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssContinuous)
	{
		ATMO_SENSORTILE_SPI_MasterAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
	}

	if(handle == ATMO_SENSORTILE_SPI2)
	{
		for(unsigned int i = 0; i < numWriteBytes; i++)
		{
			SPI_3WireWrite(&ATMO_SENSORTILE_SPI_DriverHandles[handle], writeBytes[i]);
		}
	}
	else
	{
		halStatus = HAL_SPI_Transmit(ATMO_SENSORTILE_SPI_SpiHandles[handle], writeBytes, numWriteBytes, timeout_ms);
	}

	if(halStatus != HAL_OK)
	{
		ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
		return ATMO_SPI_Status_Fail;
	}


	return ATMO_SPI_Status_Success;
}

ATMO_SPI_Status_t ATMO_SENSORTILE_SPI_MasterRead( ATMO_DriverInstanceData_t* instance, ATMO_SPI_CS_t csPin, const uint8_t* cmdBytes, uint16_t numCmdBytes, uint8_t* readBytes, uint16_t numReadBytes, uint16_t timeout_ms )
{
	uint32_t handle = *((uint32_t *)instance->argument);

	if(handle >= ATMO_SENSORTILE_NUM_SPI || handle == ATMO_SENSORTILE_SPI1)
	{
		return ATMO_SPI_Status_Fail;
	}

	HAL_StatusTypeDef halStatus = HAL_OK;

	ATMO_SENSORTILE_SPI_MasterAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);

	if(cmdBytes != NULL && numCmdBytes > 0)
	{
		if(handle == ATMO_SENSORTILE_SPI2)
		{

			/* Change the data line to output and enable the SPI */
			SPI_1LINE_TX(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
			__HAL_SPI_ENABLE(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);

			for(unsigned int i = 0; i < numCmdBytes; i++)
			{
				SPI_3WireWrite(&ATMO_SENSORTILE_SPI_DriverHandles[handle], cmdBytes[i]);
			}
		}
		else
		{
			halStatus = HAL_SPI_Transmit(ATMO_SENSORTILE_SPI_SpiHandles[handle], cmdBytes, numCmdBytes, timeout_ms);
		}

		if(!ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssContinuous)
		{
			ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
		}
	}

	if(halStatus != HAL_OK)
	{
		ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
		return ATMO_SPI_Status_Fail;
	}

	if(!ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssContinuous)
	{
		ATMO_SENSORTILE_SPI_MasterAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
	}

	if(handle == ATMO_SENSORTILE_SPI2)
	{
		  /* Disable the SPI and change the data line to input */
		  __HAL_SPI_DISABLE(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
		  SPI_1LINE_RX(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);

		  /* Check if we need to read one byte or more */
		  if(numReadBytes > 1U)
		  {
		    SPI_Read_nBytes(&ATMO_SENSORTILE_SPI_DriverHandles[handle], readBytes, numReadBytes);
		  }
		  else
		  {
		    SPI_Read(&ATMO_SENSORTILE_SPI_DriverHandles[handle], &readBytes[0]);
		  }
	}
	else
	{
		halStatus = HAL_SPI_Receive(ATMO_SENSORTILE_SPI_SpiHandles[handle], readBytes, numReadBytes, timeout_ms);

	}

	if(halStatus != HAL_OK)
	{
		ATMO_SENSORTILE_SPI_MasterDeAssertSlaveSelect(instance, csPin, ATMO_SENSORTILE_SPI_PeriphConfig[handle].deviceConfig.ssActiveLow);
		return ATMO_SPI_Status_Fail;
	}

	if(handle == ATMO_SENSORTILE_SPI2)
	{
		  /* Change the data line to output and enable the SPI */
		  SPI_1LINE_TX(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
		  __HAL_SPI_ENABLE(&ATMO_SENSORTILE_SPI_DriverHandles[handle]);
	}
	return ATMO_SPI_Status_Success;
}