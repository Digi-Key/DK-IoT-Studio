#include "lsm6dsm.h"
#include "lsm6dsm_reg.h"

static ATMO_LSM6DSM_Config_t _LSM6DSM_PrivConfig;
static lsm6dsm_ctx_t _LSM6DSM_Ctx;

static int32_t _ATMO_LSM6DSM_PlatformWrite(void *handle, uint8_t Reg, uint8_t *Bufp,
                              uint16_t len)
{
	if(_LSM6DSM_PrivConfig.driverType.type == ATMO_DRIVERTYPE_I2C )
	{
		uint8_t i2cAddress = *((uint8_t*)handle);
		ATMO_I2C_Status_t status = ATMO_I2C_MasterWrite(_LSM6DSM_PrivConfig.i2cInstance, i2cAddress,
		&Reg, 1, Bufp, len, 1000);
		return (status == ATMO_I2C_Status_Success) ? 0 : 1;
	}
	else
	{
		ATMO_GPIO_Device_Pin_t csPin = *((ATMO_GPIO_Device_Pin_t *)handle);
		ATMO_GPIO_SetPinState(_LSM6DSM_PrivConfig.gpioInstance, csPin, ATMO_GPIO_PinState_Low);
		ATMO_SPI_Status_t status = ATMO_SPI_MasterWrite(_LSM6DSM_PrivConfig.spiInstance, ATMO_SPI_CS_NONE, &Reg, 1, Bufp, len, 1000);
		ATMO_GPIO_SetPinState(_LSM6DSM_PrivConfig.gpioInstance, csPin, ATMO_GPIO_PinState_High);
		return (status == ATMO_SPI_Status_Success) ? 0 : 1;
	}
  

}

static int32_t _ATMO_LSM6DSM_PlatformRead(void *handle, uint8_t Reg, uint8_t *Bufp,
                             uint16_t len)
{
	if(_LSM6DSM_PrivConfig.driverType.type == ATMO_DRIVERTYPE_I2C )
	{
		uint8_t i2cAddress = *((uint8_t*)handle);
		ATMO_I2C_Status_t status = ATMO_I2C_Status_Success;
		uint8_t currentReg = Reg;

		// Need to do discrete reads or block update doesn't work
		for(unsigned int i = 0; (i < len) && (status == ATMO_I2C_Status_Success); i++)
		{
			status = ATMO_I2C_MasterRead(_LSM6DSM_PrivConfig.i2cInstance, i2cAddress,
				&currentReg, 1, &Bufp[i], 1, 1000);
			currentReg++;
		}

		return (status == ATMO_I2C_Status_Success) ? 0 : 1;
	}
	else
	{
		ATMO_GPIO_Device_Pin_t csPin = *((ATMO_GPIO_Device_Pin_t *)handle);

		ATMO_SPI_Status_t status = ATMO_SPI_Status_Success;

		for(unsigned int i = 0; (i < len) && (status == ATMO_SPI_Status_Success); i++)
		{
			ATMO_GPIO_SetPinState(_LSM6DSM_PrivConfig.gpioInstance, csPin, ATMO_GPIO_PinState_Low);
			uint8_t readReg = (Reg + i) | 0x80;
			status = ATMO_SPI_MasterRead(_LSM6DSM_PrivConfig.spiInstance, ATMO_SPI_CS_NONE, &readReg, 1, &Bufp[i], 1, 1000);
			ATMO_GPIO_SetPinState(_LSM6DSM_PrivConfig.gpioInstance, csPin, ATMO_GPIO_PinState_High);
		}


		return (status == ATMO_SPI_Status_Success) ? 0 : 1;
	}
}

ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_Init(ATMO_LSM6DSM_Config_t *config)
{
    if(config == NULL)
    {
        return ATMO_LSM6DSM_Status_Fail;
    }

    memcpy(&_LSM6DSM_PrivConfig, config, sizeof(_LSM6DSM_PrivConfig));

    _LSM6DSM_Ctx.write_reg = _ATMO_LSM6DSM_PlatformWrite;
    _LSM6DSM_Ctx.read_reg = _ATMO_LSM6DSM_PlatformRead;

    if(config->driverType.type == ATMO_DRIVERTYPE_SPI)
    {
		// Initialize SPI
		ATMO_SPI_Peripheral_t spiConf;
		spiConf.operatingMode = ATMO_SPI_OperatingMode_Master;
		spiConf.deviceConfig.baudRate = 2500000;
		spiConf.deviceConfig.clockContinuous = false;
		spiConf.deviceConfig.clockMode = ATMO_SPI_ClockMode_3;
		spiConf.deviceConfig.msbFirst = true;
		spiConf.deviceConfig.ssActiveLow = true;
		ATMO_SPI_SetConfiguration(config->spiInstance, &spiConf);
        
    	_LSM6DSM_Ctx.handle = (void*)&_LSM6DSM_PrivConfig.csPin;

    	ATMO_GPIO_Config_t gpioConfig;
    	gpioConfig.initialState = ATMO_GPIO_PinState_High;
    	gpioConfig.pinMode = ATMO_GPIO_PinMode_Output_PushPull;
    	ATMO_GPIO_SetPinConfiguration(config->gpioInstance, config->csPin, &gpioConfig);

    	uint8_t spiByte = 0x0C;
    	if(!config->spi3Wire)
    	{
    		spiByte = 0x04;
    	}

    	lsm6dsm_write_reg(&_LSM6DSM_Ctx, LSM6DSM_CTRL3_C, &spiByte, 1);
    }
    else
    {
    	ATMO_I2C_Peripheral_t i2cConfig;
		i2cConfig.operatingMode = ATMO_I2C_OperatingMode_Master;
		i2cConfig.baudRate = ATMO_I2C_BaudRate_Standard_Mode;
		ATMO_I2C_SetConfiguration(config->i2cInstance, &i2cConfig);

    	_LSM6DSM_Ctx.handle = (void*)&_LSM6DSM_PrivConfig.i2cAddress;
    }

    uint8_t whoamI = 0;
    lsm6dsm_device_id_get(&_LSM6DSM_Ctx, &whoamI);
    if ( whoamI != LSM6DSM_ID )
    {
        ATMO_PLATFORM_DebugPrint("Invalid LSM6DSM Accel WhoAmI (Rcv %02X Expect %02X\r\n", whoamI, LSM6DSM_ID);
        return ATMO_LSM6DSM_Status_Fail;
    }


    // Reset device settings
    uint8_t rst = 0;
    lsm6dsm_reset_set(&_LSM6DSM_Ctx, 1);
    do {
    	ATMO_PLATFORM_DelayMilliseconds(10);

    	// After the reset, try to set to SPI mode if needed
    	if(config->driverType.type == ATMO_DRIVERTYPE_SPI)
    	{
        	uint8_t spiByte = 0x0C;
        	if(!config->spi3Wire)
        	{
        		spiByte = 0x04;
        	}

        	lsm6dsm_write_reg(&_LSM6DSM_Ctx, LSM6DSM_CTRL3_C, &spiByte, 1);
    	}
        lsm6dsm_reset_get(&_LSM6DSM_Ctx, &rst);
    } while (rst);

    // Enable block update
    lsm6dsm_block_data_update_set(&_LSM6DSM_Ctx, 1);

    // Set ODR
    lsm6dsm_xl_data_rate_set(&_LSM6DSM_Ctx, config->accelOdr);
    lsm6dsm_gy_data_rate_set(&_LSM6DSM_Ctx, config->gyroOdr);

    // Set Full Scale
    lsm6dsm_xl_full_scale_set(&_LSM6DSM_Ctx, config->accelFullScale);
    lsm6dsm_gy_full_scale_set(&_LSM6DSM_Ctx, config->gyroFullScale);

    /*
    * Configure filtering chain(No aux interface).
    */  
    /*
    * Accelerometer - analog filter.
    */  
    lsm6dsm_xl_filter_analog_set(&_LSM6DSM_Ctx, LSM6DSM_XL_ANA_BW_400Hz);

    /*
    * Accelerometer - LPF1 path ( LPF2 not used ).
    */
    //lsm6dsm_xl_lp1_bandwidth_set(&dev_ctx, LSM6DSM_XL_LP1_ODR_DIV_4);

    /*
    * Accelerometer - LPF1 + LPF2 path.
    */
    lsm6dsm_xl_lp2_bandwidth_set(&_LSM6DSM_Ctx, LSM6DSM_XL_LOW_NOISE_LP_ODR_DIV_100);

    /*
    * Accelerometer - High Pass / Slope path.
    */
    //lsm6dsm_xl_reference_mode_set(&dev_ctx, PROPERTY_DISABLE);
    //lsm6dsm_xl_hp_bandwidth_set(&dev_ctx, LSM6DSM_XL_HP_ODR_DIV_100);

    /*
    * Gyroscope - filtering chain.
    */
    lsm6dsm_gy_band_pass_set(&_LSM6DSM_Ctx, LSM6DSM_HP_260mHz_LP1_STRONG);
    
 
    return ATMO_LSM6DSM_Status_Success;
}

/**
 * @brief Get acceleration data. Each axis is in mg
 * 
 * @param data 
 * @return ATMO_LSM6DSM_Status_t 
 */
ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_GetAccelData(ATMO_LSM6DSM_AccelData_t *data)
{
    uint8_t rawData[6] = {0};
    lsm6dsm_acceleration_raw_get(&_LSM6DSM_Ctx, rawData);

    int16_t rawDataInt[3] = {0};
    rawDataInt[0] = (rawData[1] << 8) | rawData[0];
    rawDataInt[1] = (rawData[3] << 8) | rawData[2];
    rawDataInt[2] = (rawData[5] << 8) | rawData[4];

    switch(_LSM6DSM_PrivConfig.accelFullScale)
    {
        case LSM6DSM_2g:
        {
            data->x = LSM6DSM_FROM_FS_2g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSM_FROM_FS_2g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSM_FROM_FS_2g_TO_mg( rawDataInt[2] );
            break;
        }
        case LSM6DSM_4g:
        {
            data->x = LSM6DSM_FROM_FS_4g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSM_FROM_FS_4g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSM_FROM_FS_4g_TO_mg( rawDataInt[2] );
            break;
        }
        case LSM6DSM_8g:
        {
            data->x = LSM6DSM_FROM_FS_8g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSM_FROM_FS_8g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSM_FROM_FS_8g_TO_mg( rawDataInt[2] );
            break;
        }
        case LSM6DSM_16g:
        {
            data->x = LSM6DSM_FROM_FS_16g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSM_FROM_FS_16g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSM_FROM_FS_16g_TO_mg( rawDataInt[2] );
            break;
        }
        default:
        {
            memset(data, 0, sizeof(ATMO_LSM6DSM_AccelData_t));
            return ATMO_LSM6DSM_Status_Fail;
            break;
        }

    }

    return ATMO_LSM6DSM_Status_Success;
}

/**
 * @brief Get gyroscope data. Each axis is in mdps
 * 
 * @param data 
 * @return ATMO_LSM6DSM_Status_t 
 */
ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_GetGyroData(ATMO_LSM6DSM_GyroData_t *data)
{
    uint8_t rawData[6] = {0};
    lsm6dsm_angular_rate_raw_get(&_LSM6DSM_Ctx, rawData);

    int16_t rawDataInt[3] = {0};
    rawDataInt[0] = (rawData[1] << 8) | rawData[0];
    rawDataInt[1] = (rawData[3] << 8) | rawData[2];
    rawDataInt[2] = (rawData[5] << 8) | rawData[4];

    switch(_LSM6DSM_PrivConfig.gyroFullScale)
    {
        case LSM6DSM_125dps:
        {
            data->x = LSM6DSM_FROM_FS_125dps_TO_mdps(rawDataInt[0]);
            data->y = LSM6DSM_FROM_FS_125dps_TO_mdps(rawDataInt[1]);
            data->z = LSM6DSM_FROM_FS_125dps_TO_mdps(rawDataInt[2]);
            break;
        }
        case LSM6DSM_250dps:
        {
            data->x = LSM6DSM_FROM_FS_250dps_TO_mdps(rawDataInt[0]);
            data->y = LSM6DSM_FROM_FS_250dps_TO_mdps(rawDataInt[1]);
            data->z = LSM6DSM_FROM_FS_250dps_TO_mdps(rawDataInt[2]);
            break;
        }
        case LSM6DSM_500dps:
        {
            data->x = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[0]);
            data->y = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[1]);
            data->z = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[2]);
            break;
        }
        case LSM6DSM_1000dps:
        {
            data->x = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[0]);
            data->y = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[1]);
            data->z = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[2]);
            break;
        }
        case LSM6DSM_2000dps:
        {
            data->x = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[0]);
            data->y = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[1]);
            data->z = LSM6DSM_FROM_FS_500dps_TO_mdps(rawDataInt[2]);
            break;
        }
        default:
        {
            data->x = 0;
            data->y = 0;
            data->z = 0;
        }
    }


    return ATMO_LSM6DSM_Status_Success;
}

/**
 * @brief Get temperature data in degrees C
 * 
 * @param data 
 * @return ATMO_LSM6DSM_Status_t 
 */
ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_GetTempData(float *tempC)
{
    uint8_t rawData[2] = {0};
    lsm6dsm_temperature_raw_get(&_LSM6DSM_Ctx, rawData);

    int16_t tempDataInt = (rawData[1] << 8) | rawData[0];
    *tempC = LSM6DSM_FROM_LSB_TO_degC( tempDataInt );
    return ATMO_LSM6DSM_Status_Success;
}
