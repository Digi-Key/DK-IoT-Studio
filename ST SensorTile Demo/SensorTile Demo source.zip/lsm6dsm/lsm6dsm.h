/**
 ******************************************************************************
 * @file    lsm6dsm.h
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - lsm6dsm header file
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *   3. Neither the name of Atmosphere IoT Corp. nor the names of its contributors
 *      may be used to endorse or promote products derived from this software
 *      without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */
#ifndef _ATMO_LSM6DSM_H_
#define _ATMO_LSM6DSM_H_

#include "../app_src/atmosphere_platform.h"

typedef struct {
    ATMO_DriverInstanceHandle_t i2cInstance;
    ATMO_DriverInstanceHandle_t spiInstance;
    ATMO_DriverInstanceHandle_t gpioInstance;
    uint8_t i2cAddress;
    uint8_t accelOdr;
    uint8_t gyroOdr;
    uint8_t accelFullScale;
    uint8_t gyroFullScale;
    bool spi3Wire;
    ATMO_GPIO_Device_Pin_t csPin; // Only used for SPI
    ATMO_CORE_DeviceHandle_t driverType;
}ATMO_LSM6DSM_Config_t;

typedef enum {
    ATMO_LSM6DSM_Status_Success = 0 ,
    ATMO_LSM6DSM_Status_Fail
} ATMO_LSM6DSM_Status_t;

typedef struct {
    float x;
    float y;
    float z;
} ATMO_LSM6DSM_AccelData_t;

typedef ATMO_LSM6DSM_AccelData_t ATMO_LSM6DSM_GyroData_t;

ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_Init(ATMO_LSM6DSM_Config_t *config);

/**
 * @brief Get acceleration data. Each axis is in mg
 * 
 * @param data 
 * @return ATMO_LSM6DSM_Status_t 
 */
ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_GetAccelData(ATMO_LSM6DSM_AccelData_t *data);

/**
 * @brief Get gyroscope data. Each axis is in mdps
 * 
 * @param data 
 * @return ATMO_LSM6DSM_Status_t 
 */
ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_GetGyroData(ATMO_LSM6DSM_GyroData_t *data);

/**
 * @brief Get temperature data in degrees C
 * 
 * @param tempC 
 * @return ATMO_LSM6DSM_Status_t 
 */
ATMO_LSM6DSM_Status_t ATMO_LSM6DSM_GetTempData(float *tempC);

#endif
