#include "atmosphere_interruptsHandler.h"
#include "atmosphere_abilityHandler.h"


#ifdef __cplusplus
extern "C"{
#endif
void ATMO_AccelX_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_xAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, xAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_yAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, yAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_zAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, zAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_acceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, acceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_rotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, rotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_xRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, xRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_yRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, yRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_zRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, zRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelX_INTERRUPT_temperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelX, temperature), (ATMO_Value_t *)data);
}
void ATMO_LPS22HBPressure_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(LPS22HBPressure, trigger), (ATMO_Value_t *)data);
}
void ATMO_LPS22HBPressure_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(LPS22HBPressure, setup), (ATMO_Value_t *)data);
}
void ATMO_LPS22HBPressure_INTERRUPT_readPressure(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(LPS22HBPressure, readPressure), (ATMO_Value_t *)data);
}
void ATMO_LPS22HBPressure_INTERRUPT_readTemperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(LPS22HBPressure, readTemperature), (ATMO_Value_t *)data);
}
void ATMO_Interval_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Interval, trigger), (ATMO_Value_t *)data);
}
void ATMO_Interval_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Interval, setup), (ATMO_Value_t *)data);
}
void ATMO_Interval_INTERRUPT_interval(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Interval, interval), (ATMO_Value_t *)data);
}
void ATMO_PressureChar_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(PressureChar, trigger), (ATMO_Value_t *)data);
}
void ATMO_PressureChar_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(PressureChar, setup), (ATMO_Value_t *)data);
}
void ATMO_PressureChar_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(PressureChar, setValue), (ATMO_Value_t *)data);
}
void ATMO_PressureChar_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(PressureChar, written), (ATMO_Value_t *)data);
}
void ATMO_PressureChar_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(PressureChar, subscibed), (ATMO_Value_t *)data);
}
void ATMO_PressureChar_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(PressureChar, unsubscribed), (ATMO_Value_t *)data);
}
void ATMO_TmpChar_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(TmpChar, trigger), (ATMO_Value_t *)data);
}
void ATMO_TmpChar_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(TmpChar, setup), (ATMO_Value_t *)data);
}
void ATMO_TmpChar_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(TmpChar, setValue), (ATMO_Value_t *)data);
}
void ATMO_TmpChar_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(TmpChar, written), (ATMO_Value_t *)data);
}
void ATMO_TmpChar_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(TmpChar, subscibed), (ATMO_Value_t *)data);
}
void ATMO_TmpChar_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(TmpChar, unsubscribed), (ATMO_Value_t *)data);
}
void ATMO_Calibrat_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Calibrat, trigger), (ATMO_Value_t *)data);
}
void ATMO_Calibrat_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Calibrat, setup), (ATMO_Value_t *)data);
}
void ATMO_Calibrat_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Calibrat, setValue), (ATMO_Value_t *)data);
}
void ATMO_Calibrat_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Calibrat, written), (ATMO_Value_t *)data);
}
void ATMO_Calibrat_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Calibrat, subscibed), (ATMO_Value_t *)data);
}
void ATMO_Calibrat_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(Calibrat, unsubscribed), (ATMO_Value_t *)data);
}
void ATMO_AccelXDeltaVar_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDeltaVar, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelXDeltaVar_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDeltaVar, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelXDeltaVar_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDeltaVar, setValue), (ATMO_Value_t *)data);
}
void ATMO_AccelXDeltaVar_INTERRUPT_getValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDeltaVar, getValue), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_xAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, xAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_yAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, yAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_zAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, zAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_acceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, acceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_rotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, rotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_xRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, xRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_yRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, yRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_zRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, zRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelXDelta_INTERRUPT_temperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelXDelta, temperature), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_xAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, xAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_yAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, yAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_zAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, zAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_acceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, acceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_rotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, rotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_xRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, xRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_yRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, yRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_zRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, zRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelYDelta_INTERRUPT_temperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDelta, temperature), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_xAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, xAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_yAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, yAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_zAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, zAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_acceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, acceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_rotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, rotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_xRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, xRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_yRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, yRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_zRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, zRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZDelta_INTERRUPT_temperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDelta, temperature), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_xAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, xAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_yAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, yAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_zAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, zAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_acceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, acceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_rotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, rotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_xRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, xRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_yRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, yRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_zRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, zRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelY_INTERRUPT_temperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelY, temperature), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_xAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, xAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_yAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, yAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_zAcceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, zAcceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_acceleration(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, acceleration), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_rotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, rotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_xRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, xRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_yRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, yRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_zRotSpeed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, zRotSpeed), (ATMO_Value_t *)data);
}
void ATMO_AccelZ_INTERRUPT_temperature(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZ, temperature), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelX_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelX, trigger), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelX_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelX, setup), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelX_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelX, setValue), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelX_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelX, written), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelX_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelX, subscibed), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelX_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelX, unsubscribed), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelY_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelY, trigger), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelY_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelY, setup), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelY_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelY, setValue), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelY_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelY, written), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelY_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelY, subscibed), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelY_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelY, unsubscribed), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelZ_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelZ, trigger), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelZ_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelZ, setup), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelZ_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelZ, setValue), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelZ_INTERRUPT_written(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelZ, written), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelZ_INTERRUPT_subscibed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelZ, subscibed), (ATMO_Value_t *)data);
}
void ATMO_BLEAccelZ_INTERRUPT_unsubscribed(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(BLEAccelZ, unsubscribed), (ATMO_Value_t *)data);
}
void ATMO_AccelYDeltaVar_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDeltaVar, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelYDeltaVar_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDeltaVar, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelYDeltaVar_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDeltaVar, setValue), (ATMO_Value_t *)data);
}
void ATMO_AccelYDeltaVar_INTERRUPT_getValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelYDeltaVar, getValue), (ATMO_Value_t *)data);
}
void ATMO_AccelZDeltaVar_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDeltaVar, trigger), (ATMO_Value_t *)data);
}
void ATMO_AccelZDeltaVar_INTERRUPT_setup(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDeltaVar, setup), (ATMO_Value_t *)data);
}
void ATMO_AccelZDeltaVar_INTERRUPT_setValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDeltaVar, setValue), (ATMO_Value_t *)data);
}
void ATMO_AccelZDeltaVar_INTERRUPT_getValue(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(AccelZDeltaVar, getValue), (ATMO_Value_t *)data);
}
void ATMO_SubDeltaX_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(SubDeltaX, trigger), (ATMO_Value_t *)data);
}
void ATMO_SubDeltaY_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(SubDeltaY, trigger), (ATMO_Value_t *)data);
}
void ATMO_SubDeltaZ_INTERRUPT_trigger(void *data) {
	ATMO_AddAbilityExecute(ATMO_ABILITY(SubDeltaZ, trigger), (ATMO_Value_t *)data);
}

#ifdef __cplusplus
}
#endif
	