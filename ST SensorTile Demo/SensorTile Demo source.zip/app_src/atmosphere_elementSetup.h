
#ifndef ATMO_ELEMENT_SETUP_H
#define ATMO_ELEMENT_SETUP_H

#include "atmosphere_platform.h"
#include "atmosphere_callbacks.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_ElementSetup();
#ifdef __cplusplus
}
#endif
#endif
