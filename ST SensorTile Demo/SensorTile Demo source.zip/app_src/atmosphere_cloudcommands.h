
#ifndef ATMO_CLOUDCOMMANDS_H_
#define ATMO_CLOUDCOMMANDS_H_

#ifdef __cplusplus
	extern "C"{
#endif

static char* cloudCommandsList[] = {};

#define TOTAL_NUM_CLOUD_COMMANDS (0)

#define ATMO_CLOUD_COMMAND(ELEMENT) ATMO_CLOUD_COMMAND_ ## ELEMENT

#ifdef __cplusplus
}
#endif

#endif
