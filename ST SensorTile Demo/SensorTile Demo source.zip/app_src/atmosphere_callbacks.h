
#ifndef ATMO_CALLBACKS_H
#define ATMO_CALLBACKS_H

#include "atmosphere_platform.h"
#include "atmosphere_properties.h"
#include "atmosphere_variables.h"
#include "atmosphere_triggerHandler.h"
#include "atmosphere_interruptsHandler.h"
#include "atmosphere_embedded_libraries.h"
#include "atmosphere_abilityHandler.h"

#include "atmosphere_driverinstance.h"

#include "atmosphere_cloudcommands.h"

#include "atmosphere_elementnames.h"

#define ATMO_CALLBACK(ELEMENT, NAME) ELEMENT ## _ ## NAME

void ATMO_Setup();

ATMO_Status_t AccelX_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_acceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelX_temperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t LPS22HBPressure_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t LPS22HBPressure_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t LPS22HBPressure_readPressure(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t LPS22HBPressure_readTemperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Interval_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Interval_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Interval_interval(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t PressureChar_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t PressureChar_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t PressureChar_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t PressureChar_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t PressureChar_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t PressureChar_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t TmpChar_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t TmpChar_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t TmpChar_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t TmpChar_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t TmpChar_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t TmpChar_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Calibrat_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Calibrat_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Calibrat_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Calibrat_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Calibrat_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t Calibrat_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDeltaVar_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDeltaVar_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDeltaVar_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDeltaVar_getValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_acceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelXDelta_temperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_acceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDelta_temperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_acceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDelta_temperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_acceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelY_temperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_acceleration(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZ_temperature(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelX_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelX_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelX_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelX_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelX_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelX_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelY_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelY_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelY_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelY_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelY_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelY_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelZ_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelZ_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelZ_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelZ_written(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelZ_subscibed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t BLEAccelZ_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDeltaVar_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDeltaVar_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDeltaVar_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelYDeltaVar_getValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDeltaVar_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDeltaVar_setup(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDeltaVar_setValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t AccelZDeltaVar_getValue(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t SubDeltaX_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t SubDeltaY_trigger(ATMO_Value_t *in, ATMO_Value_t *out);

ATMO_Status_t SubDeltaZ_trigger(ATMO_Value_t *in, ATMO_Value_t *out);
#endif
