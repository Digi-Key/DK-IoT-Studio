#include "atmosphere_abilityHandler.h"
#include "atmosphere_triggerHandler.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_AbilityHandler(unsigned int abilityHandleId, ATMO_Value_t *value) {
	switch(abilityHandleId) {
		case ATMO_ABILITY(AccelX, trigger):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_trigger(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, triggered), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, setup):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_setup(value, &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, xAcceleration):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_xAcceleration(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, xAccelerationRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, yAcceleration):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_yAcceleration(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, yAccelerationRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, zAcceleration):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_zAcceleration(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, zAccelerationRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, acceleration):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_acceleration(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, accelerationRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, rotSpeed):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_rotSpeed(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, rotSpeedRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, xRotSpeed):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_xRotSpeed(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, xRotSpeedRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, yRotSpeed):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_yRotSpeed(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, yRotSpeedRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, zRotSpeed):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_zRotSpeed(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, zRotSpeedRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(AccelX, temperature):
		{
			ATMO_Value_t AccelX_Value;
			ATMO_InitValue(&AccelX_Value);
			AccelX_temperature(value, &AccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelX, temperatureRead), &AccelX_Value);
			ATMO_FreeValue(&AccelX_Value);
			break;
		}
		case ATMO_ABILITY(LPS22HBPressure, trigger):
		{
			ATMO_Value_t LPS22HBPressure_Value;
			ATMO_InitValue(&LPS22HBPressure_Value);
			LPS22HBPressure_trigger(value, &LPS22HBPressure_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(LPS22HBPressure, triggered), &LPS22HBPressure_Value);
			ATMO_FreeValue(&LPS22HBPressure_Value);
			break;
		}
		case ATMO_ABILITY(LPS22HBPressure, setup):
		{
			ATMO_Value_t LPS22HBPressure_Value;
			ATMO_InitValue(&LPS22HBPressure_Value);
			LPS22HBPressure_setup(value, &LPS22HBPressure_Value);
			ATMO_FreeValue(&LPS22HBPressure_Value);
			break;
		}
		case ATMO_ABILITY(LPS22HBPressure, readPressure):
		{
			ATMO_Value_t LPS22HBPressure_Value;
			ATMO_InitValue(&LPS22HBPressure_Value);
			LPS22HBPressure_readPressure(value, &LPS22HBPressure_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(LPS22HBPressure, pressureRead), &LPS22HBPressure_Value);
			ATMO_FreeValue(&LPS22HBPressure_Value);
			break;
		}
		case ATMO_ABILITY(LPS22HBPressure, readTemperature):
		{
			ATMO_Value_t LPS22HBPressure_Value;
			ATMO_InitValue(&LPS22HBPressure_Value);
			LPS22HBPressure_readTemperature(value, &LPS22HBPressure_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(LPS22HBPressure, temperatureRead), &LPS22HBPressure_Value);
			ATMO_FreeValue(&LPS22HBPressure_Value);
			break;
		}
		case ATMO_ABILITY(Interval, trigger):
		{
			ATMO_Value_t Interval_Value;
			ATMO_InitValue(&Interval_Value);
			Interval_trigger(value, &Interval_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Interval, triggered), &Interval_Value);
			ATMO_FreeValue(&Interval_Value);
			break;
		}
		case ATMO_ABILITY(Interval, setup):
		{
			ATMO_Value_t Interval_Value;
			ATMO_InitValue(&Interval_Value);
			Interval_setup(value, &Interval_Value);
			ATMO_FreeValue(&Interval_Value);
			break;
		}
		case ATMO_ABILITY(Interval, interval):
		{
			ATMO_Value_t Interval_Value;
			ATMO_InitValue(&Interval_Value);
			Interval_interval(value, &Interval_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Interval, interval), &Interval_Value);
			ATMO_FreeValue(&Interval_Value);
			break;
		}
		case ATMO_ABILITY(PressureChar, trigger):
		{
			ATMO_Value_t PressureChar_Value;
			ATMO_InitValue(&PressureChar_Value);
			PressureChar_trigger(value, &PressureChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(PressureChar, triggered), &PressureChar_Value);
			ATMO_FreeValue(&PressureChar_Value);
			break;
		}
		case ATMO_ABILITY(PressureChar, setup):
		{
			ATMO_Value_t PressureChar_Value;
			ATMO_InitValue(&PressureChar_Value);
			PressureChar_setup(value, &PressureChar_Value);
			ATMO_FreeValue(&PressureChar_Value);
			break;
		}
		case ATMO_ABILITY(PressureChar, setValue):
		{
			ATMO_Value_t PressureChar_Value;
			ATMO_InitValue(&PressureChar_Value);
			PressureChar_setValue(value, &PressureChar_Value);
			ATMO_FreeValue(&PressureChar_Value);
			break;
		}
		case ATMO_ABILITY(PressureChar, written):
		{
			ATMO_Value_t PressureChar_Value;
			ATMO_InitValue(&PressureChar_Value);
			PressureChar_written(value, &PressureChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(PressureChar, written), &PressureChar_Value);
			ATMO_FreeValue(&PressureChar_Value);
			break;
		}
		case ATMO_ABILITY(PressureChar, subscibed):
		{
			ATMO_Value_t PressureChar_Value;
			ATMO_InitValue(&PressureChar_Value);
			PressureChar_subscibed(value, &PressureChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(PressureChar, subscibed), &PressureChar_Value);
			ATMO_FreeValue(&PressureChar_Value);
			break;
		}
		case ATMO_ABILITY(PressureChar, unsubscribed):
		{
			ATMO_Value_t PressureChar_Value;
			ATMO_InitValue(&PressureChar_Value);
			PressureChar_unsubscribed(value, &PressureChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(PressureChar, unsubscribed), &PressureChar_Value);
			ATMO_FreeValue(&PressureChar_Value);
			break;
		}
		case ATMO_ABILITY(TmpChar, trigger):
		{
			ATMO_Value_t TmpChar_Value;
			ATMO_InitValue(&TmpChar_Value);
			TmpChar_trigger(value, &TmpChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(TmpChar, triggered), &TmpChar_Value);
			ATMO_FreeValue(&TmpChar_Value);
			break;
		}
		case ATMO_ABILITY(TmpChar, setup):
		{
			ATMO_Value_t TmpChar_Value;
			ATMO_InitValue(&TmpChar_Value);
			TmpChar_setup(value, &TmpChar_Value);
			ATMO_FreeValue(&TmpChar_Value);
			break;
		}
		case ATMO_ABILITY(TmpChar, setValue):
		{
			ATMO_Value_t TmpChar_Value;
			ATMO_InitValue(&TmpChar_Value);
			TmpChar_setValue(value, &TmpChar_Value);
			ATMO_FreeValue(&TmpChar_Value);
			break;
		}
		case ATMO_ABILITY(TmpChar, written):
		{
			ATMO_Value_t TmpChar_Value;
			ATMO_InitValue(&TmpChar_Value);
			TmpChar_written(value, &TmpChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(TmpChar, written), &TmpChar_Value);
			ATMO_FreeValue(&TmpChar_Value);
			break;
		}
		case ATMO_ABILITY(TmpChar, subscibed):
		{
			ATMO_Value_t TmpChar_Value;
			ATMO_InitValue(&TmpChar_Value);
			TmpChar_subscibed(value, &TmpChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(TmpChar, subscibed), &TmpChar_Value);
			ATMO_FreeValue(&TmpChar_Value);
			break;
		}
		case ATMO_ABILITY(TmpChar, unsubscribed):
		{
			ATMO_Value_t TmpChar_Value;
			ATMO_InitValue(&TmpChar_Value);
			TmpChar_unsubscribed(value, &TmpChar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(TmpChar, unsubscribed), &TmpChar_Value);
			ATMO_FreeValue(&TmpChar_Value);
			break;
		}
		case ATMO_ABILITY(Calibrat, trigger):
		{
			ATMO_Value_t Calibrat_Value;
			ATMO_InitValue(&Calibrat_Value);
			Calibrat_trigger(value, &Calibrat_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Calibrat, triggered), &Calibrat_Value);
			ATMO_FreeValue(&Calibrat_Value);
			break;
		}
		case ATMO_ABILITY(Calibrat, setup):
		{
			ATMO_Value_t Calibrat_Value;
			ATMO_InitValue(&Calibrat_Value);
			Calibrat_setup(value, &Calibrat_Value);
			ATMO_FreeValue(&Calibrat_Value);
			break;
		}
		case ATMO_ABILITY(Calibrat, setValue):
		{
			ATMO_Value_t Calibrat_Value;
			ATMO_InitValue(&Calibrat_Value);
			Calibrat_setValue(value, &Calibrat_Value);
			ATMO_FreeValue(&Calibrat_Value);
			break;
		}
		case ATMO_ABILITY(Calibrat, written):
		{
			ATMO_Value_t Calibrat_Value;
			ATMO_InitValue(&Calibrat_Value);
			Calibrat_written(value, &Calibrat_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Calibrat, written), &Calibrat_Value);
			ATMO_FreeValue(&Calibrat_Value);
			break;
		}
		case ATMO_ABILITY(Calibrat, subscibed):
		{
			ATMO_Value_t Calibrat_Value;
			ATMO_InitValue(&Calibrat_Value);
			Calibrat_subscibed(value, &Calibrat_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Calibrat, subscibed), &Calibrat_Value);
			ATMO_FreeValue(&Calibrat_Value);
			break;
		}
		case ATMO_ABILITY(Calibrat, unsubscribed):
		{
			ATMO_Value_t Calibrat_Value;
			ATMO_InitValue(&Calibrat_Value);
			Calibrat_unsubscribed(value, &Calibrat_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(Calibrat, unsubscribed), &Calibrat_Value);
			ATMO_FreeValue(&Calibrat_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDeltaVar, trigger):
		{
			ATMO_Value_t AccelXDeltaVar_Value;
			ATMO_InitValue(&AccelXDeltaVar_Value);
			AccelXDeltaVar_trigger(value, &AccelXDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDeltaVar, triggered), &AccelXDeltaVar_Value);
			ATMO_FreeValue(&AccelXDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDeltaVar, setup):
		{
			ATMO_Value_t AccelXDeltaVar_Value;
			ATMO_InitValue(&AccelXDeltaVar_Value);
			AccelXDeltaVar_setup(value, &AccelXDeltaVar_Value);
			ATMO_FreeValue(&AccelXDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDeltaVar, setValue):
		{
			ATMO_Value_t AccelXDeltaVar_Value;
			ATMO_InitValue(&AccelXDeltaVar_Value);
			AccelXDeltaVar_setValue(value, &AccelXDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDeltaVar, valueSet), &AccelXDeltaVar_Value);
			ATMO_FreeValue(&AccelXDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDeltaVar, getValue):
		{
			ATMO_Value_t AccelXDeltaVar_Value;
			ATMO_InitValue(&AccelXDeltaVar_Value);
			AccelXDeltaVar_getValue(value, &AccelXDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDeltaVar, valueRetrieved), &AccelXDeltaVar_Value);
			ATMO_FreeValue(&AccelXDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, trigger):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_trigger(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, triggered), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, setup):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_setup(value, &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, xAcceleration):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_xAcceleration(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, xAccelerationRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, yAcceleration):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_yAcceleration(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, yAccelerationRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, zAcceleration):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_zAcceleration(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, zAccelerationRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, acceleration):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_acceleration(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, accelerationRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, rotSpeed):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_rotSpeed(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, rotSpeedRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, xRotSpeed):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_xRotSpeed(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, xRotSpeedRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, yRotSpeed):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_yRotSpeed(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, yRotSpeedRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, zRotSpeed):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_zRotSpeed(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, zRotSpeedRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelXDelta, temperature):
		{
			ATMO_Value_t AccelXDelta_Value;
			ATMO_InitValue(&AccelXDelta_Value);
			AccelXDelta_temperature(value, &AccelXDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelXDelta, temperatureRead), &AccelXDelta_Value);
			ATMO_FreeValue(&AccelXDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, trigger):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_trigger(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, triggered), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, setup):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_setup(value, &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, xAcceleration):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_xAcceleration(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, xAccelerationRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, yAcceleration):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_yAcceleration(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, yAccelerationRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, zAcceleration):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_zAcceleration(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, zAccelerationRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, acceleration):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_acceleration(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, accelerationRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, rotSpeed):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_rotSpeed(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, rotSpeedRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, xRotSpeed):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_xRotSpeed(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, xRotSpeedRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, yRotSpeed):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_yRotSpeed(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, yRotSpeedRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, zRotSpeed):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_zRotSpeed(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, zRotSpeedRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDelta, temperature):
		{
			ATMO_Value_t AccelYDelta_Value;
			ATMO_InitValue(&AccelYDelta_Value);
			AccelYDelta_temperature(value, &AccelYDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDelta, temperatureRead), &AccelYDelta_Value);
			ATMO_FreeValue(&AccelYDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, trigger):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_trigger(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, triggered), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, setup):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_setup(value, &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, xAcceleration):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_xAcceleration(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, xAccelerationRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, yAcceleration):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_yAcceleration(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, yAccelerationRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, zAcceleration):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_zAcceleration(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, zAccelerationRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, acceleration):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_acceleration(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, accelerationRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, rotSpeed):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_rotSpeed(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, rotSpeedRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, xRotSpeed):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_xRotSpeed(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, xRotSpeedRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, yRotSpeed):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_yRotSpeed(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, yRotSpeedRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, zRotSpeed):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_zRotSpeed(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, zRotSpeedRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDelta, temperature):
		{
			ATMO_Value_t AccelZDelta_Value;
			ATMO_InitValue(&AccelZDelta_Value);
			AccelZDelta_temperature(value, &AccelZDelta_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDelta, temperatureRead), &AccelZDelta_Value);
			ATMO_FreeValue(&AccelZDelta_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, trigger):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_trigger(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, triggered), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, setup):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_setup(value, &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, xAcceleration):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_xAcceleration(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, xAccelerationRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, yAcceleration):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_yAcceleration(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, yAccelerationRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, zAcceleration):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_zAcceleration(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, zAccelerationRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, acceleration):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_acceleration(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, accelerationRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, rotSpeed):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_rotSpeed(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, rotSpeedRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, xRotSpeed):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_xRotSpeed(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, xRotSpeedRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, yRotSpeed):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_yRotSpeed(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, yRotSpeedRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, zRotSpeed):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_zRotSpeed(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, zRotSpeedRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelY, temperature):
		{
			ATMO_Value_t AccelY_Value;
			ATMO_InitValue(&AccelY_Value);
			AccelY_temperature(value, &AccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelY, temperatureRead), &AccelY_Value);
			ATMO_FreeValue(&AccelY_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, trigger):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_trigger(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, triggered), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, setup):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_setup(value, &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, xAcceleration):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_xAcceleration(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, xAccelerationRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, yAcceleration):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_yAcceleration(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, yAccelerationRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, zAcceleration):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_zAcceleration(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, zAccelerationRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, acceleration):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_acceleration(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, accelerationRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, rotSpeed):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_rotSpeed(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, rotSpeedRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, xRotSpeed):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_xRotSpeed(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, xRotSpeedRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, yRotSpeed):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_yRotSpeed(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, yRotSpeedRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, zRotSpeed):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_zRotSpeed(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, zRotSpeedRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelZ, temperature):
		{
			ATMO_Value_t AccelZ_Value;
			ATMO_InitValue(&AccelZ_Value);
			AccelZ_temperature(value, &AccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZ, temperatureRead), &AccelZ_Value);
			ATMO_FreeValue(&AccelZ_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelX, trigger):
		{
			ATMO_Value_t BLEAccelX_Value;
			ATMO_InitValue(&BLEAccelX_Value);
			BLEAccelX_trigger(value, &BLEAccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelX, triggered), &BLEAccelX_Value);
			ATMO_FreeValue(&BLEAccelX_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelX, setup):
		{
			ATMO_Value_t BLEAccelX_Value;
			ATMO_InitValue(&BLEAccelX_Value);
			BLEAccelX_setup(value, &BLEAccelX_Value);
			ATMO_FreeValue(&BLEAccelX_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelX, setValue):
		{
			ATMO_Value_t BLEAccelX_Value;
			ATMO_InitValue(&BLEAccelX_Value);
			BLEAccelX_setValue(value, &BLEAccelX_Value);
			ATMO_FreeValue(&BLEAccelX_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelX, written):
		{
			ATMO_Value_t BLEAccelX_Value;
			ATMO_InitValue(&BLEAccelX_Value);
			BLEAccelX_written(value, &BLEAccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelX, written), &BLEAccelX_Value);
			ATMO_FreeValue(&BLEAccelX_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelX, subscibed):
		{
			ATMO_Value_t BLEAccelX_Value;
			ATMO_InitValue(&BLEAccelX_Value);
			BLEAccelX_subscibed(value, &BLEAccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelX, subscibed), &BLEAccelX_Value);
			ATMO_FreeValue(&BLEAccelX_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelX, unsubscribed):
		{
			ATMO_Value_t BLEAccelX_Value;
			ATMO_InitValue(&BLEAccelX_Value);
			BLEAccelX_unsubscribed(value, &BLEAccelX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelX, unsubscribed), &BLEAccelX_Value);
			ATMO_FreeValue(&BLEAccelX_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelY, trigger):
		{
			ATMO_Value_t BLEAccelY_Value;
			ATMO_InitValue(&BLEAccelY_Value);
			BLEAccelY_trigger(value, &BLEAccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelY, triggered), &BLEAccelY_Value);
			ATMO_FreeValue(&BLEAccelY_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelY, setup):
		{
			ATMO_Value_t BLEAccelY_Value;
			ATMO_InitValue(&BLEAccelY_Value);
			BLEAccelY_setup(value, &BLEAccelY_Value);
			ATMO_FreeValue(&BLEAccelY_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelY, setValue):
		{
			ATMO_Value_t BLEAccelY_Value;
			ATMO_InitValue(&BLEAccelY_Value);
			BLEAccelY_setValue(value, &BLEAccelY_Value);
			ATMO_FreeValue(&BLEAccelY_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelY, written):
		{
			ATMO_Value_t BLEAccelY_Value;
			ATMO_InitValue(&BLEAccelY_Value);
			BLEAccelY_written(value, &BLEAccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelY, written), &BLEAccelY_Value);
			ATMO_FreeValue(&BLEAccelY_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelY, subscibed):
		{
			ATMO_Value_t BLEAccelY_Value;
			ATMO_InitValue(&BLEAccelY_Value);
			BLEAccelY_subscibed(value, &BLEAccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelY, subscibed), &BLEAccelY_Value);
			ATMO_FreeValue(&BLEAccelY_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelY, unsubscribed):
		{
			ATMO_Value_t BLEAccelY_Value;
			ATMO_InitValue(&BLEAccelY_Value);
			BLEAccelY_unsubscribed(value, &BLEAccelY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelY, unsubscribed), &BLEAccelY_Value);
			ATMO_FreeValue(&BLEAccelY_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelZ, trigger):
		{
			ATMO_Value_t BLEAccelZ_Value;
			ATMO_InitValue(&BLEAccelZ_Value);
			BLEAccelZ_trigger(value, &BLEAccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelZ, triggered), &BLEAccelZ_Value);
			ATMO_FreeValue(&BLEAccelZ_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelZ, setup):
		{
			ATMO_Value_t BLEAccelZ_Value;
			ATMO_InitValue(&BLEAccelZ_Value);
			BLEAccelZ_setup(value, &BLEAccelZ_Value);
			ATMO_FreeValue(&BLEAccelZ_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelZ, setValue):
		{
			ATMO_Value_t BLEAccelZ_Value;
			ATMO_InitValue(&BLEAccelZ_Value);
			BLEAccelZ_setValue(value, &BLEAccelZ_Value);
			ATMO_FreeValue(&BLEAccelZ_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelZ, written):
		{
			ATMO_Value_t BLEAccelZ_Value;
			ATMO_InitValue(&BLEAccelZ_Value);
			BLEAccelZ_written(value, &BLEAccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelZ, written), &BLEAccelZ_Value);
			ATMO_FreeValue(&BLEAccelZ_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelZ, subscibed):
		{
			ATMO_Value_t BLEAccelZ_Value;
			ATMO_InitValue(&BLEAccelZ_Value);
			BLEAccelZ_subscibed(value, &BLEAccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelZ, subscibed), &BLEAccelZ_Value);
			ATMO_FreeValue(&BLEAccelZ_Value);
			break;
		}
		case ATMO_ABILITY(BLEAccelZ, unsubscribed):
		{
			ATMO_Value_t BLEAccelZ_Value;
			ATMO_InitValue(&BLEAccelZ_Value);
			BLEAccelZ_unsubscribed(value, &BLEAccelZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(BLEAccelZ, unsubscribed), &BLEAccelZ_Value);
			ATMO_FreeValue(&BLEAccelZ_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDeltaVar, trigger):
		{
			ATMO_Value_t AccelYDeltaVar_Value;
			ATMO_InitValue(&AccelYDeltaVar_Value);
			AccelYDeltaVar_trigger(value, &AccelYDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDeltaVar, triggered), &AccelYDeltaVar_Value);
			ATMO_FreeValue(&AccelYDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDeltaVar, setup):
		{
			ATMO_Value_t AccelYDeltaVar_Value;
			ATMO_InitValue(&AccelYDeltaVar_Value);
			AccelYDeltaVar_setup(value, &AccelYDeltaVar_Value);
			ATMO_FreeValue(&AccelYDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDeltaVar, setValue):
		{
			ATMO_Value_t AccelYDeltaVar_Value;
			ATMO_InitValue(&AccelYDeltaVar_Value);
			AccelYDeltaVar_setValue(value, &AccelYDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDeltaVar, valueSet), &AccelYDeltaVar_Value);
			ATMO_FreeValue(&AccelYDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelYDeltaVar, getValue):
		{
			ATMO_Value_t AccelYDeltaVar_Value;
			ATMO_InitValue(&AccelYDeltaVar_Value);
			AccelYDeltaVar_getValue(value, &AccelYDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelYDeltaVar, valueRetrieved), &AccelYDeltaVar_Value);
			ATMO_FreeValue(&AccelYDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDeltaVar, trigger):
		{
			ATMO_Value_t AccelZDeltaVar_Value;
			ATMO_InitValue(&AccelZDeltaVar_Value);
			AccelZDeltaVar_trigger(value, &AccelZDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDeltaVar, triggered), &AccelZDeltaVar_Value);
			ATMO_FreeValue(&AccelZDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDeltaVar, setup):
		{
			ATMO_Value_t AccelZDeltaVar_Value;
			ATMO_InitValue(&AccelZDeltaVar_Value);
			AccelZDeltaVar_setup(value, &AccelZDeltaVar_Value);
			ATMO_FreeValue(&AccelZDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDeltaVar, setValue):
		{
			ATMO_Value_t AccelZDeltaVar_Value;
			ATMO_InitValue(&AccelZDeltaVar_Value);
			AccelZDeltaVar_setValue(value, &AccelZDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDeltaVar, valueSet), &AccelZDeltaVar_Value);
			ATMO_FreeValue(&AccelZDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(AccelZDeltaVar, getValue):
		{
			ATMO_Value_t AccelZDeltaVar_Value;
			ATMO_InitValue(&AccelZDeltaVar_Value);
			AccelZDeltaVar_getValue(value, &AccelZDeltaVar_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(AccelZDeltaVar, valueRetrieved), &AccelZDeltaVar_Value);
			ATMO_FreeValue(&AccelZDeltaVar_Value);
			break;
		}
		case ATMO_ABILITY(SubDeltaX, trigger):
		{
			ATMO_Value_t SubDeltaX_Value;
			ATMO_InitValue(&SubDeltaX_Value);
			SubDeltaX_trigger(value, &SubDeltaX_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(SubDeltaX, triggered), &SubDeltaX_Value);
			ATMO_FreeValue(&SubDeltaX_Value);
			break;
		}
		case ATMO_ABILITY(SubDeltaY, trigger):
		{
			ATMO_Value_t SubDeltaY_Value;
			ATMO_InitValue(&SubDeltaY_Value);
			SubDeltaY_trigger(value, &SubDeltaY_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(SubDeltaY, triggered), &SubDeltaY_Value);
			ATMO_FreeValue(&SubDeltaY_Value);
			break;
		}
		case ATMO_ABILITY(SubDeltaZ, trigger):
		{
			ATMO_Value_t SubDeltaZ_Value;
			ATMO_InitValue(&SubDeltaZ_Value);
			SubDeltaZ_trigger(value, &SubDeltaZ_Value);
			ATMO_TriggerHandler(ATMO_TRIGGER(SubDeltaZ, triggered), &SubDeltaZ_Value);
			ATMO_FreeValue(&SubDeltaZ_Value);
			break;
		}
	}

}

#ifdef __cplusplus
}
#endif
