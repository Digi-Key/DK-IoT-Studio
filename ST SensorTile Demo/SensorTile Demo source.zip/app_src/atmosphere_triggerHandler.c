#include "atmosphere_triggerHandler.h"
#include "atmosphere_abilityHandler.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_TriggerHandler(unsigned int triggerHandleId, ATMO_Value_t *value) {
	switch(triggerHandleId) {
		case ATMO_TRIGGER(AccelX, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, xAccelerationRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(SubDeltaX, trigger), value);
			break;
		}

		case ATMO_TRIGGER(AccelX, yAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, zAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, accelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, rotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, xRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, yRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, zRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelX, temperatureRead):
		{
			break;
		}

		case ATMO_TRIGGER(LPS22HBPressure, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(LPS22HBPressure, pressureRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(PressureChar, setValue), value);
			break;
		}

		case ATMO_TRIGGER(LPS22HBPressure, temperatureRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(TmpChar, setValue), value);
			break;
		}

		case ATMO_TRIGGER(Interval, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(Interval, interval):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(AccelX, xAcceleration), value);
			ATMO_AbilityHandler(ATMO_ABILITY(AccelY, yAcceleration), value);
			ATMO_AbilityHandler(ATMO_ABILITY(AccelZ, zAcceleration), value);
			ATMO_AbilityHandler(ATMO_ABILITY(LPS22HBPressure, readPressure), value);
			ATMO_AbilityHandler(ATMO_ABILITY(LPS22HBPressure, readTemperature), value);
			break;
		}

		case ATMO_TRIGGER(PressureChar, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(PressureChar, written):
		{
			break;
		}

		case ATMO_TRIGGER(PressureChar, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(PressureChar, unsubscribed):
		{
			break;
		}

		case ATMO_TRIGGER(TmpChar, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(TmpChar, written):
		{
			break;
		}

		case ATMO_TRIGGER(TmpChar, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(TmpChar, unsubscribed):
		{
			break;
		}

		case ATMO_TRIGGER(Calibrat, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(Calibrat, written):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(AccelXDelta, xAcceleration), value);
			ATMO_AbilityHandler(ATMO_ABILITY(AccelYDelta, yAcceleration), value);
			ATMO_AbilityHandler(ATMO_ABILITY(AccelZDelta, zAcceleration), value);
			break;
		}

		case ATMO_TRIGGER(Calibrat, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(Calibrat, unsubscribed):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDeltaVar, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDeltaVar, valueSet):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDeltaVar, valueRetrieved):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, xAccelerationRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(AccelXDeltaVar, setValue), value);
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, yAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, zAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, accelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, rotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, xRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, yRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, zRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelXDelta, temperatureRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, xAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, yAccelerationRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(AccelYDeltaVar, setValue), value);
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, zAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, accelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, rotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, xRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, yRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, zRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDelta, temperatureRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, xAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, yAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, zAccelerationRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(AccelZDeltaVar, setValue), value);
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, accelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, rotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, xRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, yRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, zRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDelta, temperatureRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, xAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, yAccelerationRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(SubDeltaY, trigger), value);
			break;
		}

		case ATMO_TRIGGER(AccelY, zAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, accelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, rotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, xRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, yRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, zRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelY, temperatureRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, xAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, yAccelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, zAccelerationRead):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(SubDeltaZ, trigger), value);
			break;
		}

		case ATMO_TRIGGER(AccelZ, accelerationRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, rotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, xRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, yRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, zRotSpeedRead):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZ, temperatureRead):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelX, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelX, written):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelX, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelX, unsubscribed):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelY, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelY, written):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelY, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelY, unsubscribed):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelZ, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelZ, written):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelZ, subscibed):
		{
			break;
		}

		case ATMO_TRIGGER(BLEAccelZ, unsubscribed):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDeltaVar, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDeltaVar, valueSet):
		{
			break;
		}

		case ATMO_TRIGGER(AccelYDeltaVar, valueRetrieved):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDeltaVar, triggered):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDeltaVar, valueSet):
		{
			break;
		}

		case ATMO_TRIGGER(AccelZDeltaVar, valueRetrieved):
		{
			break;
		}

		case ATMO_TRIGGER(SubDeltaX, triggered):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(BLEAccelX, setValue), value);
			break;
		}

		case ATMO_TRIGGER(SubDeltaY, triggered):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(BLEAccelY, setValue), value);
			break;
		}

		case ATMO_TRIGGER(SubDeltaZ, triggered):
		{
			ATMO_AbilityHandler(ATMO_ABILITY(BLEAccelZ, setValue), value);
			break;
		}

	}

}

#ifdef __cplusplus
}
#endif
