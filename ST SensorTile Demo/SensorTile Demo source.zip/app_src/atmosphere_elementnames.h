
#ifndef ATMO_ELEMENT_NAMES_H
#define ATMO_ELEMENT_NAMES_H

#ifdef __cplusplus
	extern "C"{
#endif

#define ATMO_ELEMENT_NAME(ELEMENT) ATMO_ ## ELEMENT ## _NAME

#define ATMO_AccelX_NAME "AccelX"
#define ATMO_LPS22HBPressure_NAME "LPS22HBPressure"
#define ATMO_Interval_NAME "Interval"
#define ATMO_PressureChar_NAME "PressureChar"
#define ATMO_TmpChar_NAME "TmpChar"
#define ATMO_Calibrat_NAME "Calibrat"
#define ATMO_AccelXDeltaVar_NAME "AccelXDeltaVar"
#define ATMO_AccelXDelta_NAME "AccelXDelta"
#define ATMO_AccelYDelta_NAME "AccelYDelta"
#define ATMO_AccelZDelta_NAME "AccelZDelta"
#define ATMO_AccelY_NAME "AccelY"
#define ATMO_AccelZ_NAME "AccelZ"
#define ATMO_BLEAccelX_NAME "BLEAccelX"
#define ATMO_BLEAccelY_NAME "BLEAccelY"
#define ATMO_BLEAccelZ_NAME "BLEAccelZ"
#define ATMO_AccelYDeltaVar_NAME "AccelYDeltaVar"
#define ATMO_AccelZDeltaVar_NAME "AccelZDeltaVar"
#define ATMO_SubDeltaX_NAME "SubDeltaX"
#define ATMO_SubDeltaY_NAME "SubDeltaY"
#define ATMO_SubDeltaZ_NAME "SubDeltaZ"

#ifdef __cplusplus
}
#endif
#endif
