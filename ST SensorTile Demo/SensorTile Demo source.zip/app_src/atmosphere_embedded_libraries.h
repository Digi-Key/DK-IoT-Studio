#ifndef __ATMOSPHERE_EMBEDDED_LIBRARIES_H_
#define __ATMOSPHERE_EMBEDDED_LIBRARIES_H_
#include "../lsm303agr/lsm303agr.h"
#include "../lsm303agr/lsm303agr_reg.h"
#include "../lps22hb/lps22hb.h"
#include "../lps22hb/lps22hb_reg.h"
#include "../lsm6dsm/lsm6dsm.h"
#include "../lsm6dsm/lsm6dsm_reg.h"
#include "../lsm6dsl/lsm6dsl.h"
#include "../lsm6dsl/lsm6dsl_reg.h"
#endif
