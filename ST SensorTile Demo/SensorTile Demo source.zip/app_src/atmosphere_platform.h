#ifndef ATMO_PLATFORM_H
#define ATMO_PLATFORM_H

#include "./atmosphere_typedefs.h"
#include "./atmosphere_globals.h"
#include "./pin_mapping.h"
#include "./atmosphere_peripherals.h"
#include "ble.h"
#include "interval.h"
#include "i2c.h"
#include "spi.h"
#include "gpio.h"
#include "adc.h"
#include "uart.h"
#include "pwm.h"
#include "cloud.h"
#include "cloud_ble.h"
#include "cloud_tcp.h"
#include "wifi.h"
#include "http.h"

void ATMO_PLATFORM_Init();

void ATMO_PLATFORM_PostInit();

void ATMO_PLATFORM_DelayMilliseconds(uint32_t milliseconds);

void *ATMO_Malloc(uint32_t numBytes);

void *ATMO_Calloc(size_t num, size_t size);

void ATMO_Free(void *data);

void ATMO_Lock();

void ATMO_Unlock();

void ATMO_PLATFORM_DebugPrint(char const *format, ...);


#endif
