
#ifndef ATMO_INTERRUPTS_HANDLER_H
#define ATMO_INTERRUPTS_HANDLER_H

#ifdef __cplusplus
	extern "C"{
#endif

#include "../atmo/core.h"
#define ATMO_INTERRUPT(ELEMENT, NAME) ATMO_ ## ELEMENT ## _INTERRUPT_  ## NAME

void ATMO_AccelX_INTERRUPT_trigger(void *data);
void ATMO_AccelX_INTERRUPT_setup(void *data);
void ATMO_AccelX_INTERRUPT_xAcceleration(void *data);
void ATMO_AccelX_INTERRUPT_yAcceleration(void *data);
void ATMO_AccelX_INTERRUPT_zAcceleration(void *data);
void ATMO_AccelX_INTERRUPT_acceleration(void *data);
void ATMO_AccelX_INTERRUPT_rotSpeed(void *data);
void ATMO_AccelX_INTERRUPT_xRotSpeed(void *data);
void ATMO_AccelX_INTERRUPT_yRotSpeed(void *data);
void ATMO_AccelX_INTERRUPT_zRotSpeed(void *data);
void ATMO_AccelX_INTERRUPT_temperature(void *data);

void ATMO_LPS22HBPressure_INTERRUPT_trigger(void *data);
void ATMO_LPS22HBPressure_INTERRUPT_setup(void *data);
void ATMO_LPS22HBPressure_INTERRUPT_readPressure(void *data);
void ATMO_LPS22HBPressure_INTERRUPT_readTemperature(void *data);

void ATMO_Interval_INTERRUPT_trigger(void *data);
void ATMO_Interval_INTERRUPT_setup(void *data);
void ATMO_Interval_INTERRUPT_interval(void *data);

void ATMO_PressureChar_INTERRUPT_trigger(void *data);
void ATMO_PressureChar_INTERRUPT_setup(void *data);
void ATMO_PressureChar_INTERRUPT_setValue(void *data);
void ATMO_PressureChar_INTERRUPT_written(void *data);
void ATMO_PressureChar_INTERRUPT_subscibed(void *data);
void ATMO_PressureChar_INTERRUPT_unsubscribed(void *data);

void ATMO_TmpChar_INTERRUPT_trigger(void *data);
void ATMO_TmpChar_INTERRUPT_setup(void *data);
void ATMO_TmpChar_INTERRUPT_setValue(void *data);
void ATMO_TmpChar_INTERRUPT_written(void *data);
void ATMO_TmpChar_INTERRUPT_subscibed(void *data);
void ATMO_TmpChar_INTERRUPT_unsubscribed(void *data);

void ATMO_Calibrat_INTERRUPT_trigger(void *data);
void ATMO_Calibrat_INTERRUPT_setup(void *data);
void ATMO_Calibrat_INTERRUPT_setValue(void *data);
void ATMO_Calibrat_INTERRUPT_written(void *data);
void ATMO_Calibrat_INTERRUPT_subscibed(void *data);
void ATMO_Calibrat_INTERRUPT_unsubscribed(void *data);

void ATMO_AccelXDeltaVar_INTERRUPT_trigger(void *data);
void ATMO_AccelXDeltaVar_INTERRUPT_setup(void *data);
void ATMO_AccelXDeltaVar_INTERRUPT_setValue(void *data);
void ATMO_AccelXDeltaVar_INTERRUPT_getValue(void *data);

void ATMO_AccelXDelta_INTERRUPT_trigger(void *data);
void ATMO_AccelXDelta_INTERRUPT_setup(void *data);
void ATMO_AccelXDelta_INTERRUPT_xAcceleration(void *data);
void ATMO_AccelXDelta_INTERRUPT_yAcceleration(void *data);
void ATMO_AccelXDelta_INTERRUPT_zAcceleration(void *data);
void ATMO_AccelXDelta_INTERRUPT_acceleration(void *data);
void ATMO_AccelXDelta_INTERRUPT_rotSpeed(void *data);
void ATMO_AccelXDelta_INTERRUPT_xRotSpeed(void *data);
void ATMO_AccelXDelta_INTERRUPT_yRotSpeed(void *data);
void ATMO_AccelXDelta_INTERRUPT_zRotSpeed(void *data);
void ATMO_AccelXDelta_INTERRUPT_temperature(void *data);

void ATMO_AccelYDelta_INTERRUPT_trigger(void *data);
void ATMO_AccelYDelta_INTERRUPT_setup(void *data);
void ATMO_AccelYDelta_INTERRUPT_xAcceleration(void *data);
void ATMO_AccelYDelta_INTERRUPT_yAcceleration(void *data);
void ATMO_AccelYDelta_INTERRUPT_zAcceleration(void *data);
void ATMO_AccelYDelta_INTERRUPT_acceleration(void *data);
void ATMO_AccelYDelta_INTERRUPT_rotSpeed(void *data);
void ATMO_AccelYDelta_INTERRUPT_xRotSpeed(void *data);
void ATMO_AccelYDelta_INTERRUPT_yRotSpeed(void *data);
void ATMO_AccelYDelta_INTERRUPT_zRotSpeed(void *data);
void ATMO_AccelYDelta_INTERRUPT_temperature(void *data);

void ATMO_AccelZDelta_INTERRUPT_trigger(void *data);
void ATMO_AccelZDelta_INTERRUPT_setup(void *data);
void ATMO_AccelZDelta_INTERRUPT_xAcceleration(void *data);
void ATMO_AccelZDelta_INTERRUPT_yAcceleration(void *data);
void ATMO_AccelZDelta_INTERRUPT_zAcceleration(void *data);
void ATMO_AccelZDelta_INTERRUPT_acceleration(void *data);
void ATMO_AccelZDelta_INTERRUPT_rotSpeed(void *data);
void ATMO_AccelZDelta_INTERRUPT_xRotSpeed(void *data);
void ATMO_AccelZDelta_INTERRUPT_yRotSpeed(void *data);
void ATMO_AccelZDelta_INTERRUPT_zRotSpeed(void *data);
void ATMO_AccelZDelta_INTERRUPT_temperature(void *data);

void ATMO_AccelY_INTERRUPT_trigger(void *data);
void ATMO_AccelY_INTERRUPT_setup(void *data);
void ATMO_AccelY_INTERRUPT_xAcceleration(void *data);
void ATMO_AccelY_INTERRUPT_yAcceleration(void *data);
void ATMO_AccelY_INTERRUPT_zAcceleration(void *data);
void ATMO_AccelY_INTERRUPT_acceleration(void *data);
void ATMO_AccelY_INTERRUPT_rotSpeed(void *data);
void ATMO_AccelY_INTERRUPT_xRotSpeed(void *data);
void ATMO_AccelY_INTERRUPT_yRotSpeed(void *data);
void ATMO_AccelY_INTERRUPT_zRotSpeed(void *data);
void ATMO_AccelY_INTERRUPT_temperature(void *data);

void ATMO_AccelZ_INTERRUPT_trigger(void *data);
void ATMO_AccelZ_INTERRUPT_setup(void *data);
void ATMO_AccelZ_INTERRUPT_xAcceleration(void *data);
void ATMO_AccelZ_INTERRUPT_yAcceleration(void *data);
void ATMO_AccelZ_INTERRUPT_zAcceleration(void *data);
void ATMO_AccelZ_INTERRUPT_acceleration(void *data);
void ATMO_AccelZ_INTERRUPT_rotSpeed(void *data);
void ATMO_AccelZ_INTERRUPT_xRotSpeed(void *data);
void ATMO_AccelZ_INTERRUPT_yRotSpeed(void *data);
void ATMO_AccelZ_INTERRUPT_zRotSpeed(void *data);
void ATMO_AccelZ_INTERRUPT_temperature(void *data);

void ATMO_BLEAccelX_INTERRUPT_trigger(void *data);
void ATMO_BLEAccelX_INTERRUPT_setup(void *data);
void ATMO_BLEAccelX_INTERRUPT_setValue(void *data);
void ATMO_BLEAccelX_INTERRUPT_written(void *data);
void ATMO_BLEAccelX_INTERRUPT_subscibed(void *data);
void ATMO_BLEAccelX_INTERRUPT_unsubscribed(void *data);

void ATMO_BLEAccelY_INTERRUPT_trigger(void *data);
void ATMO_BLEAccelY_INTERRUPT_setup(void *data);
void ATMO_BLEAccelY_INTERRUPT_setValue(void *data);
void ATMO_BLEAccelY_INTERRUPT_written(void *data);
void ATMO_BLEAccelY_INTERRUPT_subscibed(void *data);
void ATMO_BLEAccelY_INTERRUPT_unsubscribed(void *data);

void ATMO_BLEAccelZ_INTERRUPT_trigger(void *data);
void ATMO_BLEAccelZ_INTERRUPT_setup(void *data);
void ATMO_BLEAccelZ_INTERRUPT_setValue(void *data);
void ATMO_BLEAccelZ_INTERRUPT_written(void *data);
void ATMO_BLEAccelZ_INTERRUPT_subscibed(void *data);
void ATMO_BLEAccelZ_INTERRUPT_unsubscribed(void *data);

void ATMO_AccelYDeltaVar_INTERRUPT_trigger(void *data);
void ATMO_AccelYDeltaVar_INTERRUPT_setup(void *data);
void ATMO_AccelYDeltaVar_INTERRUPT_setValue(void *data);
void ATMO_AccelYDeltaVar_INTERRUPT_getValue(void *data);

void ATMO_AccelZDeltaVar_INTERRUPT_trigger(void *data);
void ATMO_AccelZDeltaVar_INTERRUPT_setup(void *data);
void ATMO_AccelZDeltaVar_INTERRUPT_setValue(void *data);
void ATMO_AccelZDeltaVar_INTERRUPT_getValue(void *data);

void ATMO_SubDeltaX_INTERRUPT_trigger(void *data);

void ATMO_SubDeltaY_INTERRUPT_trigger(void *data);

void ATMO_SubDeltaZ_INTERRUPT_trigger(void *data);


#ifdef __cplusplus
}
#endif

#endif
