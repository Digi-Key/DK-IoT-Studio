
#ifndef __ATMO_GLOBALS__H
#define __ATMO_GLOBALS__H

#define ATMO_GLOBALS_PROJECTUUID "fec6a6f1-0e3c-4609-9392-fc7a781cdae4"
#define ATMO_GLOBALS_BUILDUUID "3ea2e66a-7efb-4519-ad00-49208ad0b705"
#define ATMO_GLOBALS_ANDROID_APP_RECORD "com.digikey.atmosphere.iot"
#define ATMO_GLOBALS_GIT_HASH "d9ef971c100e360c3cb3eebf880095c214720b66"
#define ATMO_GLOBALS_GIT_BRANCH "production-digikey"

#endif
