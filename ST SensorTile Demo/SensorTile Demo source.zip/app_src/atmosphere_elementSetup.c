#include "atmosphere_elementSetup.h"

#ifdef __cplusplus
	extern "C"{
#endif

void ATMO_ElementSetup() {
	ATMO_Value_t inOutValue;
	ATMO_InitValue(&inOutValue);
	AccelX_setup(&inOutValue, &inOutValue);
	LPS22HBPressure_setup(&inOutValue, &inOutValue);
	Interval_setup(&inOutValue, &inOutValue);
	PressureChar_setup(&inOutValue, &inOutValue);
	TmpChar_setup(&inOutValue, &inOutValue);
	Calibrat_setup(&inOutValue, &inOutValue);
	AccelXDeltaVar_setup(&inOutValue, &inOutValue);
	AccelXDelta_setup(&inOutValue, &inOutValue);
	AccelYDelta_setup(&inOutValue, &inOutValue);
	AccelZDelta_setup(&inOutValue, &inOutValue);
	AccelY_setup(&inOutValue, &inOutValue);
	AccelZ_setup(&inOutValue, &inOutValue);
	BLEAccelX_setup(&inOutValue, &inOutValue);
	BLEAccelY_setup(&inOutValue, &inOutValue);
	BLEAccelZ_setup(&inOutValue, &inOutValue);
	AccelYDeltaVar_setup(&inOutValue, &inOutValue);
	AccelZDeltaVar_setup(&inOutValue, &inOutValue);
}

#ifdef __cplusplus
}
#endif
