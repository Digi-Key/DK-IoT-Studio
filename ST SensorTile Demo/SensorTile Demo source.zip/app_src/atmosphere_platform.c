#include "atmosphere_platform.h"
#include "cmsis_os.h"
#include "../atmo/core.h"
#include <stdarg.h>
#include "../interval/interval_sensortile.h"
#include "../gpio/gpio_sensortile.h"
#include "../ble/ble_sensortile.h"
#include "../cloud/cloud.h"
#include "../cloud/cloud_ble.h"
#include "../block/block_sensortile.h"
#include "../filesystem/filesystem_crastfs.h"
#include "../spi/spi_sensortile.h"
#include "../i2c/i2c_sensortile.h"
#include "SensorTile.h"


static osMutexId abilityMutex;

void ATMO_PLATFORM_Init() {
	osMutexDef_t abilityMutexDef;
	abilityMutex = osMutexCreate(&abilityMutexDef);

	ATMO_DriverInstanceHandle_t instanceHandle = 0;

	ATMO_SENSORTILE_GPIO_AddDriverInstance(&instanceHandle);
	ATMO_GPIO_Init(0);

	ATMO_SENSORTILE_BLE_AddDriverInstance(&instanceHandle);
	ATMO_BLE_PeripheralInit(0);

	ATMO_SENSORTILE_INTERVAL_AddDriverInstance(&instanceHandle);
	ATMO_INTERVAL_Init(instanceHandle);

	ATMO_SENSORTILE_SPI_AddDriverInstance(&instanceHandle, 0);
	ATMO_SPI_Init(1); // Built in sensors

	ATMO_SPI_Peripheral_t spiConf;
	spiConf.deviceConfig.baudRate = 2500000; // 5MHz
	spiConf.deviceConfig.clockContinuous = false;
	spiConf.deviceConfig.clockMode = ATMO_SPI_ClockMode_3;
	spiConf.deviceConfig.msbFirst = true;
	spiConf.deviceConfig.ssActiveLow = true;
	ATMO_SPI_SetConfiguration(1, &spiConf);

	ATMO_SENSORTILE_I2C_AddDriverInstance(&instanceHandle);
	ATMO_I2C_Init(0); // I2C3

	ATMO_I2C_Peripheral_t i2cConfig;
	i2cConfig.baudRate = ATMO_I2C_BaudRate_Standard_Mode;
	i2cConfig.operatingMode = ATMO_I2C_OperatingMode_Master;
	ATMO_I2C_SetConfiguration(0, &i2cConfig);

	ATMO_SENSORTILE_BLOCK_AddDriverInstance(&instanceHandle);
	ATMO_BLOCK_Init(instanceHandle);

	ATMO_CRASTFS_FILESYSTEM_AddDriverInstance(&instanceHandle);
	ATMO_FILESYSTEM_Init(0, 0);

	ATMO_FILESYSTEM_Config_t fsConfig;
	fsConfig.numRetries = 1;
	fsConfig.retryDelayMs = 10;
	ATMO_FILESYSTEM_SetConfiguration(0, &fsConfig);

	ATMO_CLOUD_InitFilesystemData(0);

	Sensor_IO_SPI_CS_Init_All();
}

void ATMO_PLATFORM_PostInit() {
	ATMO_DriverInstanceHandle_t instanceHandle;
	ATMO_CLOUD_BLE_AddDriverInstance(&instanceHandle, 0);
	ATMO_CLOUD_Init(0, true);
}

void ATMO_PLATFORM_DebugPrint(char const *format, ...) {
	va_list argptr;
	va_start(argptr, format);

	// Get length of data
	unsigned int len = vsnprintf(NULL, 0, format, argptr);

	// Allocate str of just the right length
	char *str = ATMO_Malloc(len + 1);
	vsnprintf(str, len + 1, format, argptr);
	va_end(argptr);

	CDC_Fill_Buffer(( uint8_t * )str, len + 1);

	ATMO_Free(str);

}

void ATMO_PLATFORM_DelayMilliseconds(uint32_t milliseconds)
{
	osDelay(milliseconds);
}

void *ATMO_Malloc(uint32_t numBytes)
{
	return pvPortMalloc(numBytes);
}

void *ATMO_Calloc(size_t num, size_t size)
{
	void* ptr = pvPortMalloc(num * size);
	if(ptr != NULL)
	{
		memset(ptr, 0, num * size);
	}
	return ptr;
}

void ATMO_Free(void *data)
{
	return vPortFree(data);
}

void ATMO_Lock()
{
	osMutexWait(abilityMutex, 0);
}

void ATMO_Unlock()
{
	osMutexRelease(abilityMutex);
}


