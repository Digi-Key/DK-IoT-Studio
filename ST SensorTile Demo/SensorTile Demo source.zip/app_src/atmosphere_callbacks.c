#include "atmosphere_callbacks.h"

//HEADER START

//HEADER END

void ATMO_Setup() {

}


ATMO_Status_t AccelX_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelX_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_Config_t config;
    config.i2cInstance = ATMO_PROPERTY(AccelX, i2cInstance);
    config.i2cAddress = ATMO_PROPERTY(AccelX, i2cAddress);
    config.accelOdr = ATMO_PROPERTY(AccelX, accelOdr);
    config.gyroOdr = ATMO_PROPERTY(AccelX, gyroOdr);
    config.accelFullScale = ATMO_PROPERTY(AccelX, accelFullScale);
    config.gyroFullScale = ATMO_PROPERTY(AccelX, gyroFullScale);
    config.driverType.type = ATMO_PROPERTY(AccelX, communicationMode);
    config.csPin = ATMO_PROPERTY(AccelX, csPin);
    config.spi3Wire = ATMO_PROPERTY(AccelX, spi3Wire);
    config.spiInstance = ATMO_PROPERTY(AccelX, spiInstance);
    config.gpioInstance = ATMO_PROPERTY(AccelX, gpioInstance);
    return ATMO_LSM6DSM_Init(&config) == ATMO_LSM6DSM_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;
}


ATMO_Status_t AccelX_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_acceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = accelData.x;
    vec.y = accelData.y;
    vec.z = accelData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = gyroData.x;
    vec.y = gyroData.y;
    vec.z = gyroData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelX_temperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temperature = 0;
    if(ATMO_LSM6DSM_GetTempData(&temperature) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, temperature);
    return ATMO_Status_Success;
}


ATMO_Status_t LPS22HBPressure_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t LPS22HBPressure_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
	ATMO_LPS22HB_Config_t config;
	config.i2cInstance = ATMO_PROPERTY(LPS22HBPressure, i2cInstance);
	config.spiInstance = ATMO_PROPERTY(LPS22HBPressure, spiInstance);
	config.gpioInstance = ATMO_PROPERTY(LPS22HBPressure, gpioInstance);
	config.csPin = ATMO_PROPERTY(LPS22HBPressure, csPin);
	config.i2cAddress = ATMO_PROPERTY(LPS22HBPressure, i2cAddress);
	config.spi3Wire = ATMO_PROPERTY(LPS22HBPressure, spi3Wire);
	config.driverType.type = ATMO_PROPERTY(LPS22HBPressure, communicationMode);
	return ATMO_LPS22HB_Init(&config) == ATMO_LPS22HB_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;


}


ATMO_Status_t LPS22HBPressure_readPressure(ATMO_Value_t *in, ATMO_Value_t *out) {
	float pressure = 0.0;
	if( ATMO_LPS22HB_GetPressure(&pressure) != ATMO_LPS22HB_Status_Success )
	{
		return ATMO_Status_Fail;
	}

	ATMO_CreateValueFloat(out, pressure);
	
	return ATMO_Status_Success;

}


ATMO_Status_t LPS22HBPressure_readTemperature(ATMO_Value_t *in, ATMO_Value_t *out) {
	
	float temperature = 0.0;
	if( ATMO_LPS22HB_GetTempData(&temperature) != ATMO_LPS22HB_Status_Success )
	{
		return ATMO_Status_Fail;
	}

	ATMO_CreateValueFloat(out, temperature);
	
	return ATMO_Status_Success;

}


ATMO_Status_t Interval_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t Interval_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_INTERVAL_Handle_t intervalHandle;
    ATMO_INTERVAL_AddAbilityInterval(
		ATMO_PROPERTY(Interval, instance), 
		ATMO_ABILITY(Interval, interval), 
		ATMO_PROPERTY(Interval, time), 
		&intervalHandle
	);
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t Interval_interval(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t PressureChar_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t PressureChar_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(PressureChar, instance),
		&ATMO_VARIABLE(PressureChar, bleServiceHandle), 
		ATMO_PROPERTY(PressureChar, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(PressureChar, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(PressureChar, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(PressureChar, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(PressureChar, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(PressureChar, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(PressureChar, writeDataType), ATMO_PROPERTY(PressureChar, readDataType), ATMO_PROPERTY(PressureChar, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(PressureChar, instance),
		&ATMO_VARIABLE(PressureChar, bleCharacteristicHandle), 
		ATMO_VARIABLE(PressureChar, bleServiceHandle), 
		ATMO_PROPERTY(PressureChar, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(PressureChar, instance),
		ATMO_VARIABLE(PressureChar, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(PressureChar, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t PressureChar_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(PressureChar, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(PressureChar, instance),
		ATMO_VARIABLE(PressureChar, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t PressureChar_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(PressureChar, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t PressureChar_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t PressureChar_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t TmpChar_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t TmpChar_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(TmpChar, instance),
		&ATMO_VARIABLE(TmpChar, bleServiceHandle), 
		ATMO_PROPERTY(TmpChar, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(TmpChar, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(TmpChar, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(TmpChar, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(TmpChar, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(TmpChar, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(TmpChar, writeDataType), ATMO_PROPERTY(TmpChar, readDataType), ATMO_PROPERTY(TmpChar, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(TmpChar, instance),
		&ATMO_VARIABLE(TmpChar, bleCharacteristicHandle), 
		ATMO_VARIABLE(TmpChar, bleServiceHandle), 
		ATMO_PROPERTY(TmpChar, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(TmpChar, instance),
		ATMO_VARIABLE(TmpChar, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(TmpChar, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t TmpChar_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(TmpChar, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(TmpChar, instance),
		ATMO_VARIABLE(TmpChar, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t TmpChar_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(TmpChar, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t TmpChar_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t TmpChar_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t Calibrat_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t Calibrat_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(Calibrat, instance),
		&ATMO_VARIABLE(Calibrat, bleServiceHandle), 
		ATMO_PROPERTY(Calibrat, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(Calibrat, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(Calibrat, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(Calibrat, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(Calibrat, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(Calibrat, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(Calibrat, writeDataType), ATMO_PROPERTY(Calibrat, readDataType), ATMO_PROPERTY(Calibrat, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(Calibrat, instance),
		&ATMO_VARIABLE(Calibrat, bleCharacteristicHandle), 
		ATMO_VARIABLE(Calibrat, bleServiceHandle), 
		ATMO_PROPERTY(Calibrat, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(Calibrat, instance),
		ATMO_VARIABLE(Calibrat, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(Calibrat, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t Calibrat_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(Calibrat, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(Calibrat, instance),
		ATMO_VARIABLE(Calibrat, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t Calibrat_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(Calibrat, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t Calibrat_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t Calibrat_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelXDeltaVar_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelXDeltaVar_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_InitValue(&ATMO_VARIABLE(AccelXDeltaVar, value));
    if(ATMO_PROPERTY(AccelXDeltaVar, initialValue) != NULL)
    {
        // Create initial value as string
        ATMO_Value_t strValue;
        ATMO_InitValue(&strValue);
        ATMO_CreateValueString(&strValue, ATMO_PROPERTY(AccelXDeltaVar, initialValue));

        // Convert to desired type
        ATMO_CreateValueConverted(&ATMO_VARIABLE(AccelXDeltaVar, value), ATMO_PROPERTY(AccelXDeltaVar, initialDataType), &strValue);
        ATMO_FreeValue(&strValue);
    }
	return ATMO_Status_Success;
	
}


ATMO_Status_t AccelXDeltaVar_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_CreateValueCopy(&ATMO_VARIABLE(AccelXDeltaVar, value), in);
    ATMO_CreateValueCopy(out, in);
    return ATMO_Status_Success;
    
}


ATMO_Status_t AccelXDeltaVar_getValue(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_CreateValueCopy(out, &ATMO_VARIABLE(AccelXDeltaVar, value));
    return ATMO_Status_Success;
    
}


ATMO_Status_t AccelXDelta_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_Config_t config;
    config.i2cInstance = ATMO_PROPERTY(AccelXDelta, i2cInstance);
    config.i2cAddress = ATMO_PROPERTY(AccelXDelta, i2cAddress);
    config.accelOdr = ATMO_PROPERTY(AccelXDelta, accelOdr);
    config.gyroOdr = ATMO_PROPERTY(AccelXDelta, gyroOdr);
    config.accelFullScale = ATMO_PROPERTY(AccelXDelta, accelFullScale);
    config.gyroFullScale = ATMO_PROPERTY(AccelXDelta, gyroFullScale);
    config.driverType.type = ATMO_PROPERTY(AccelXDelta, communicationMode);
    config.csPin = ATMO_PROPERTY(AccelXDelta, csPin);
    config.spi3Wire = ATMO_PROPERTY(AccelXDelta, spi3Wire);
    config.spiInstance = ATMO_PROPERTY(AccelXDelta, spiInstance);
    config.gpioInstance = ATMO_PROPERTY(AccelXDelta, gpioInstance);
    return ATMO_LSM6DSM_Init(&config) == ATMO_LSM6DSM_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;
}


ATMO_Status_t AccelXDelta_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_acceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = accelData.x;
    vec.y = accelData.y;
    vec.z = accelData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = gyroData.x;
    vec.y = gyroData.y;
    vec.z = gyroData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelXDelta_temperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temperature = 0;
    if(ATMO_LSM6DSM_GetTempData(&temperature) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, temperature);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_Config_t config;
    config.i2cInstance = ATMO_PROPERTY(AccelYDelta, i2cInstance);
    config.i2cAddress = ATMO_PROPERTY(AccelYDelta, i2cAddress);
    config.accelOdr = ATMO_PROPERTY(AccelYDelta, accelOdr);
    config.gyroOdr = ATMO_PROPERTY(AccelYDelta, gyroOdr);
    config.accelFullScale = ATMO_PROPERTY(AccelYDelta, accelFullScale);
    config.gyroFullScale = ATMO_PROPERTY(AccelYDelta, gyroFullScale);
    config.driverType.type = ATMO_PROPERTY(AccelYDelta, communicationMode);
    config.csPin = ATMO_PROPERTY(AccelYDelta, csPin);
    config.spi3Wire = ATMO_PROPERTY(AccelYDelta, spi3Wire);
    config.spiInstance = ATMO_PROPERTY(AccelYDelta, spiInstance);
    config.gpioInstance = ATMO_PROPERTY(AccelYDelta, gpioInstance);
    return ATMO_LSM6DSM_Init(&config) == ATMO_LSM6DSM_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;
}


ATMO_Status_t AccelYDelta_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_acceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = accelData.x;
    vec.y = accelData.y;
    vec.z = accelData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = gyroData.x;
    vec.y = gyroData.y;
    vec.z = gyroData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelYDelta_temperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temperature = 0;
    if(ATMO_LSM6DSM_GetTempData(&temperature) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, temperature);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_Config_t config;
    config.i2cInstance = ATMO_PROPERTY(AccelZDelta, i2cInstance);
    config.i2cAddress = ATMO_PROPERTY(AccelZDelta, i2cAddress);
    config.accelOdr = ATMO_PROPERTY(AccelZDelta, accelOdr);
    config.gyroOdr = ATMO_PROPERTY(AccelZDelta, gyroOdr);
    config.accelFullScale = ATMO_PROPERTY(AccelZDelta, accelFullScale);
    config.gyroFullScale = ATMO_PROPERTY(AccelZDelta, gyroFullScale);
    config.driverType.type = ATMO_PROPERTY(AccelZDelta, communicationMode);
    config.csPin = ATMO_PROPERTY(AccelZDelta, csPin);
    config.spi3Wire = ATMO_PROPERTY(AccelZDelta, spi3Wire);
    config.spiInstance = ATMO_PROPERTY(AccelZDelta, spiInstance);
    config.gpioInstance = ATMO_PROPERTY(AccelZDelta, gpioInstance);
    return ATMO_LSM6DSM_Init(&config) == ATMO_LSM6DSM_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;
}


ATMO_Status_t AccelZDelta_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_acceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = accelData.x;
    vec.y = accelData.y;
    vec.z = accelData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = gyroData.x;
    vec.y = gyroData.y;
    vec.z = gyroData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZDelta_temperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temperature = 0;
    if(ATMO_LSM6DSM_GetTempData(&temperature) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, temperature);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelY_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_Config_t config;
    config.i2cInstance = ATMO_PROPERTY(AccelY, i2cInstance);
    config.i2cAddress = ATMO_PROPERTY(AccelY, i2cAddress);
    config.accelOdr = ATMO_PROPERTY(AccelY, accelOdr);
    config.gyroOdr = ATMO_PROPERTY(AccelY, gyroOdr);
    config.accelFullScale = ATMO_PROPERTY(AccelY, accelFullScale);
    config.gyroFullScale = ATMO_PROPERTY(AccelY, gyroFullScale);
    config.driverType.type = ATMO_PROPERTY(AccelY, communicationMode);
    config.csPin = ATMO_PROPERTY(AccelY, csPin);
    config.spi3Wire = ATMO_PROPERTY(AccelY, spi3Wire);
    config.spiInstance = ATMO_PROPERTY(AccelY, spiInstance);
    config.gpioInstance = ATMO_PROPERTY(AccelY, gpioInstance);
    return ATMO_LSM6DSM_Init(&config) == ATMO_LSM6DSM_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;
}


ATMO_Status_t AccelY_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_acceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = accelData.x;
    vec.y = accelData.y;
    vec.z = accelData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = gyroData.x;
    vec.y = gyroData.y;
    vec.z = gyroData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelY_temperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temperature = 0;
    if(ATMO_LSM6DSM_GetTempData(&temperature) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, temperature);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_setup(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_Config_t config;
    config.i2cInstance = ATMO_PROPERTY(AccelZ, i2cInstance);
    config.i2cAddress = ATMO_PROPERTY(AccelZ, i2cAddress);
    config.accelOdr = ATMO_PROPERTY(AccelZ, accelOdr);
    config.gyroOdr = ATMO_PROPERTY(AccelZ, gyroOdr);
    config.accelFullScale = ATMO_PROPERTY(AccelZ, accelFullScale);
    config.gyroFullScale = ATMO_PROPERTY(AccelZ, gyroFullScale);
    config.driverType.type = ATMO_PROPERTY(AccelZ, communicationMode);
    config.csPin = ATMO_PROPERTY(AccelZ, csPin);
    config.spi3Wire = ATMO_PROPERTY(AccelZ, spi3Wire);
    config.spiInstance = ATMO_PROPERTY(AccelZ, spiInstance);
    config.gpioInstance = ATMO_PROPERTY(AccelZ, gpioInstance);
    return ATMO_LSM6DSM_Init(&config) == ATMO_LSM6DSM_Status_Success ? ATMO_Status_Success : ATMO_Status_Fail;
}


ATMO_Status_t AccelZ_xAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_yAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_zAcceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, accelData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_acceleration(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_AccelData_t accelData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetAccelData(&accelData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = accelData.x;
    vec.y = accelData.y;
    vec.z = accelData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_rotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    ATMO_3dFloatVector_t vec;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    vec.x = gyroData.x;
    vec.y = gyroData.y;
    vec.z = gyroData.z;

    ATMO_CreateValue3dVectorFloat(out, &vec);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_xRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.x);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_yRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.y);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_zRotSpeed(ATMO_Value_t *in, ATMO_Value_t *out) {
    ATMO_LSM6DSM_GyroData_t gyroData;
    if(ATMO_LSM6DSM_GetGyroData(&gyroData) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, gyroData.z);
    return ATMO_Status_Success;
}


ATMO_Status_t AccelZ_temperature(ATMO_Value_t *in, ATMO_Value_t *out) {
    float temperature = 0;
    if(ATMO_LSM6DSM_GetTempData(&temperature) != ATMO_LSM6DSM_Status_Success)
    {
        return ATMO_Status_Fail;
    }
    ATMO_CreateValueFloat(out, temperature);
    return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelX_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelX_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(BLEAccelX, instance),
		&ATMO_VARIABLE(BLEAccelX, bleServiceHandle), 
		ATMO_PROPERTY(BLEAccelX, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(BLEAccelX, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(BLEAccelX, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(BLEAccelX, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(BLEAccelX, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(BLEAccelX, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(BLEAccelX, writeDataType), ATMO_PROPERTY(BLEAccelX, readDataType), ATMO_PROPERTY(BLEAccelX, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(BLEAccelX, instance),
		&ATMO_VARIABLE(BLEAccelX, bleCharacteristicHandle), 
		ATMO_VARIABLE(BLEAccelX, bleServiceHandle), 
		ATMO_PROPERTY(BLEAccelX, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(BLEAccelX, instance),
		ATMO_VARIABLE(BLEAccelX, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(BLEAccelX, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelX_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(BLEAccelX, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(BLEAccelX, instance),
		ATMO_VARIABLE(BLEAccelX, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelX_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(BLEAccelX, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelX_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelX_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelY_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelY_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(BLEAccelY, instance),
		&ATMO_VARIABLE(BLEAccelY, bleServiceHandle), 
		ATMO_PROPERTY(BLEAccelY, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(BLEAccelY, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(BLEAccelY, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(BLEAccelY, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(BLEAccelY, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(BLEAccelY, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(BLEAccelY, writeDataType), ATMO_PROPERTY(BLEAccelY, readDataType), ATMO_PROPERTY(BLEAccelY, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(BLEAccelY, instance),
		&ATMO_VARIABLE(BLEAccelY, bleCharacteristicHandle), 
		ATMO_VARIABLE(BLEAccelY, bleServiceHandle), 
		ATMO_PROPERTY(BLEAccelY, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(BLEAccelY, instance),
		ATMO_VARIABLE(BLEAccelY, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(BLEAccelY, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelY_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(BLEAccelY, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(BLEAccelY, instance),
		ATMO_VARIABLE(BLEAccelY, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelY_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(BLEAccelY, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelY_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelY_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelZ_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelZ_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_BLE_GATTSAddService(
		ATMO_PROPERTY(BLEAccelZ, instance),
		&ATMO_VARIABLE(BLEAccelZ, bleServiceHandle), 
		ATMO_PROPERTY(BLEAccelZ, bleServiceUuid));
	
	uint8_t property = 0;
	uint8_t permission = 0;
	
	property |= ATMO_PROPERTY(BLEAccelZ, read) ? ATMO_BLE_Property_Read : 0;
	property |= ATMO_PROPERTY(BLEAccelZ, write) ? ATMO_BLE_Property_Write : 0;
	property |= ATMO_PROPERTY(BLEAccelZ, notify) ? ATMO_BLE_Property_Notify : 0;

	permission |= ATMO_PROPERTY(BLEAccelZ, read) ? ATMO_BLE_Permission_Read : 0;
	permission |= ATMO_PROPERTY(BLEAccelZ, write) ? ATMO_BLE_Permission_Write : 0;

	ATMO_DATATYPE types[3] = {ATMO_PROPERTY(BLEAccelZ, writeDataType), ATMO_PROPERTY(BLEAccelZ, readDataType), ATMO_PROPERTY(BLEAccelZ, notifyDataType)};
	
	ATMO_BLE_GATTSAddCharacteristic(
		ATMO_PROPERTY(BLEAccelZ, instance),
		&ATMO_VARIABLE(BLEAccelZ, bleCharacteristicHandle), 
		ATMO_VARIABLE(BLEAccelZ, bleServiceHandle), 
		ATMO_PROPERTY(BLEAccelZ, bleCharacteristicUuid), 
		property, permission, ATMO_GetMaxValueSize(3, 64, types));
	
	ATMO_BLE_GATTSRegisterCharacteristicAbilityHandle(
		ATMO_PROPERTY(BLEAccelZ, instance),
		ATMO_VARIABLE(BLEAccelZ, bleCharacteristicHandle), 
		ATMO_BLE_Characteristic_Written, 
		ATMO_ABILITY(BLEAccelZ, written));
	
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelZ_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

	
	// Convert to the desired write data type
	ATMO_Value_t convertedValue;
	ATMO_InitValue(&convertedValue);
	ATMO_CreateValueConverted(&convertedValue, ATMO_PROPERTY(BLEAccelZ, readDataType), in);

	ATMO_BLE_GATTSSetCharacteristic(
		ATMO_PROPERTY(BLEAccelZ, instance),
		ATMO_VARIABLE(BLEAccelZ, bleCharacteristicHandle),
		convertedValue.size, 
		(uint8_t *)convertedValue.data,
		NULL);
	
	ATMO_FreeValue(&convertedValue);
		
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelZ_written(ATMO_Value_t *in, ATMO_Value_t *out) {

	ATMO_CreateValueConverted(out, ATMO_PROPERTY(BLEAccelZ, writeDataType), in);
	return ATMO_Status_Success;
	
}


ATMO_Status_t BLEAccelZ_subscibed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t BLEAccelZ_unsubscribed(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelYDeltaVar_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelYDeltaVar_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_InitValue(&ATMO_VARIABLE(AccelYDeltaVar, value));
    if(ATMO_PROPERTY(AccelYDeltaVar, initialValue) != NULL)
    {
        // Create initial value as string
        ATMO_Value_t strValue;
        ATMO_InitValue(&strValue);
        ATMO_CreateValueString(&strValue, ATMO_PROPERTY(AccelYDeltaVar, initialValue));

        // Convert to desired type
        ATMO_CreateValueConverted(&ATMO_VARIABLE(AccelYDeltaVar, value), ATMO_PROPERTY(AccelYDeltaVar, initialDataType), &strValue);
        ATMO_FreeValue(&strValue);
    }
	return ATMO_Status_Success;
	
}


ATMO_Status_t AccelYDeltaVar_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_CreateValueCopy(&ATMO_VARIABLE(AccelYDeltaVar, value), in);
    ATMO_CreateValueCopy(out, in);
    return ATMO_Status_Success;
    
}


ATMO_Status_t AccelYDeltaVar_getValue(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_CreateValueCopy(out, &ATMO_VARIABLE(AccelYDeltaVar, value));
    return ATMO_Status_Success;
    
}


ATMO_Status_t AccelZDeltaVar_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	return ATMO_Status_Success;
}


ATMO_Status_t AccelZDeltaVar_setup(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_InitValue(&ATMO_VARIABLE(AccelZDeltaVar, value));
    if(ATMO_PROPERTY(AccelZDeltaVar, initialValue) != NULL)
    {
        // Create initial value as string
        ATMO_Value_t strValue;
        ATMO_InitValue(&strValue);
        ATMO_CreateValueString(&strValue, ATMO_PROPERTY(AccelZDeltaVar, initialValue));

        // Convert to desired type
        ATMO_CreateValueConverted(&ATMO_VARIABLE(AccelZDeltaVar, value), ATMO_PROPERTY(AccelZDeltaVar, initialDataType), &strValue);
        ATMO_FreeValue(&strValue);
    }
	return ATMO_Status_Success;
	
}


ATMO_Status_t AccelZDeltaVar_setValue(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_CreateValueCopy(&ATMO_VARIABLE(AccelZDeltaVar, value), in);
    ATMO_CreateValueCopy(out, in);
    return ATMO_Status_Success;
    
}


ATMO_Status_t AccelZDeltaVar_getValue(ATMO_Value_t *in, ATMO_Value_t *out) {

    ATMO_CreateValueCopy(out, &ATMO_VARIABLE(AccelZDeltaVar, value));
    return ATMO_Status_Success;
    
}


ATMO_Status_t SubDeltaX_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	float reading = 0;
	ATMO_GetFloat(in, &reading);
	
	float delta = 0;
	ATMO_GetFloat(&ATMO_AccelXDeltaVar_VARIABLE_value, &delta);
	
	ATMO_CreateValueFloat(out, reading - delta);
	return ATMO_Status_Success;
}


ATMO_Status_t SubDeltaY_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	float reading = 0;
	ATMO_GetFloat(in, &reading);
	
	float delta = 0;
	ATMO_GetFloat(&ATMO_AccelYDeltaVar_VARIABLE_value, &delta);
	
	ATMO_CreateValueFloat(out, reading - delta);
	return ATMO_Status_Success;
}


ATMO_Status_t SubDeltaZ_trigger(ATMO_Value_t *in, ATMO_Value_t *out) {
	float reading = 0;
	ATMO_GetFloat(in, &reading);
	
	float delta = 0;
	ATMO_GetFloat(&ATMO_AccelZDeltaVar_VARIABLE_value, &delta);
	
	ATMO_CreateValueFloat(out, reading - delta);
	return ATMO_Status_Success;
}

//FOOTER START

//FOOTER END

