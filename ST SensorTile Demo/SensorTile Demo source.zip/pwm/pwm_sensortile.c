/**
 ******************************************************************************
 * @file    pwm_sensortile.c
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - PWM source file for SENSORTILE
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "pwm_sensortile.h"

/* Imported function prototypes ----------------------------------------------*/

/* Private typedef -----------------------------------------------------------*/

const ATMO_PWM_DriverInstance_t sensortilePwmDriverInstance = {
		ATMO_SENSORTILE_PWM_Init,
		ATMO_SENSORTILE_PWM_DeInit,
		ATMO_SENSORTILE_PWM_SetPinConfiguration,
		ATMO_SENSORTILE_PWM_GetPinConfiguration,
		ATMO_SENSORTILE_PWM_Enable,
		ATMO_SENSORTILE_PWM_Disable,
};

ATMO_Status_t ATMO_SENSORTILE_PWM_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber )
{	
	ATMO_DriverInstanceData_t *driverInstanceData = (ATMO_DriverInstanceData_t *)ATMO_Malloc(sizeof(ATMO_DriverInstanceData_t));
	
	driverInstanceData->name = "SENSORTILE PWM";
	driverInstanceData->initialized = false;
	driverInstanceData->instanceNumber = 0;
	driverInstanceData->argument = NULL;
	
	return ATMO_PWM_AddDriverInstance( &sensortilePwmDriverInstance, driverInstanceData, instanceNumber );
}

ATMO_PWM_Status_t ATMO_SENSORTILE_PWM_Init(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_PWM_Status_NotSupported;
}

ATMO_PWM_Status_t ATMO_SENSORTILE_PWM_DeInit(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_PWM_Status_NotSupported;
}

ATMO_PWM_Status_t ATMO_SENSORTILE_PWM_SetPinConfiguration(ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, ATMO_PWM_Config_t *config)
{
	return ATMO_PWM_Status_NotSupported;
}

ATMO_PWM_Status_t ATMO_SENSORTILE_PWM_GetPinConfiguration(ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, ATMO_PWM_Config_t *config)
{
	return ATMO_PWM_Status_NotSupported;
}

ATMO_PWM_Status_t ATMO_SENSORTILE_PWM_Enable(ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin)
{
	return ATMO_PWM_Status_NotSupported;
}

ATMO_PWM_Status_t ATMO_SENSORTILE_PWM_Disable(ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin)
{
	return ATMO_PWM_Status_NotSupported;
}

