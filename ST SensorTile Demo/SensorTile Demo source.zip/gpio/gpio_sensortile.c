/**
 ******************************************************************************
 * @file    gpio_sensortile.c
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - SENSORTILE GPIO API Implementation
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *      may be used to endorse or promote products derived from this software
 *      without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

#include "gpio_sensortile.h"
#include "stm32l4xx_hal.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"


ATMO_GPIO_DriverInstance_t sensortileGPIODriverInstance = {
	ATMO_SENSORTILE_GPIO_Init,
	ATMO_SENSORTILE_GPIO_DeInit,
	ATMO_SENSORTILE_GPIO_SetPinConfiguration,
	ATMO_SENSORTILE_GPIO_GetPinConfiguration,
	ATMO_SENSORTILE_GPIO_RegisterInterruptAbilityHandle,
	ATMO_SENSORTILE_GPIO_RegisterInterruptCallback,
	ATMO_SENSORTILE_GPIO_SetPinState,
	ATMO_SENSORTILE_GPIO_GetPinState,
	ATMO_SENSORTILE_GPIO_Read,
	ATMO_SENSORTILE_GPIO_Toggle
};

typedef struct {
	ATMO_GPIO_Device_Pin_t pin;
	bool active;
	unsigned int abilityHandle;
	ATMO_Callback_t cb;
	bool isAbilityHandle;
	bool direct;
} ATMO_SENSORTILE_GPIO_IsrConfig_t;

typedef struct {
	uint32_t irqNum;
	ATMO_GPIO_PinState_t pinState;
}ATMO_SENSORTILE_GPIO_Rx_Payload_t;

#define ATMO_SENSORTILE_GPIO_RX_QUEUE_SIZE (75)
static QueueHandle_t rxQueue = NULL;
static TaskHandle_t rxQueueCheckerTaskHandle = NULL;

static ATMO_SENSORTILE_GPIO_IsrConfig_t ATMO_SENSORTILE_GPIO_IsrConfig[16] = {0}; // 16 lines

static GPIO_TypeDef *ATMO_SENSORTILE_GPIO_PortMap[] = {GPIOA, GPIOB, GPIOC, GPIOD, GPIOE, GPIOF, GPIOG, GPIOH};
static unsigned int ATMO_SENSORTILE_GPIO_IrqNumMap[16] = {EXTI0_IRQn, EXTI1_IRQn, EXTI2_IRQn, EXTI3_IRQn, EXTI4_IRQn, EXTI9_5_IRQn,
		EXTI9_5_IRQn, EXTI9_5_IRQn, EXTI9_5_IRQn, EXTI9_5_IRQn, EXTI15_10_IRQn, EXTI15_10_IRQn, EXTI15_10_IRQn, EXTI15_10_IRQn,
		EXTI15_10_IRQn, EXTI15_10_IRQn
};

/**
 * Don't want to be executing callback from the UART RX ISR
 * All received bytes are sent here where they are dispatched
 */
static void ATMO_SENSORTILE_GPIO_RXQueueChecker( void* parameters )
{
	if(rxQueue == NULL)
	{
		return;
	}

	ATMO_SENSORTILE_GPIO_Rx_Payload_t payload;
	while(xQueueReceive(rxQueue, &payload, portMAX_DELAY))
	{
        if(ATMO_SENSORTILE_GPIO_IsrConfig[payload.irqNum].isAbilityHandle == false)
        {
            ATMO_Value_t val;
            ATMO_InitValue(&val);
            ATMO_CreateValueUnsignedInt(&val, payload.pinState);
			if(ATMO_SENSORTILE_GPIO_IsrConfig[payload.irqNum].direct)
			{
				ATMO_SENSORTILE_GPIO_IsrConfig[payload.irqNum].cb(&val);
			}
			else
			{
				ATMO_Lock();
				ATMO_AddCallbackExecute(ATMO_SENSORTILE_GPIO_IsrConfig[payload.irqNum].cb, &val);
				ATMO_Unlock();
			}
			
            ATMO_FreeValue(&val);
        }
        else
        {
            ATMO_Value_t val;
            ATMO_InitValue(&val);
            ATMO_CreateValueUnsignedInt(&val, payload.pinState);
            ATMO_Lock();
            ATMO_AddAbilityExecute( ATMO_SENSORTILE_GPIO_IsrConfig[payload.irqNum].abilityHandle, &val );
            ATMO_Unlock();
            ATMO_FreeValue(&val);
        }
	}
}


static GPIO_TypeDef* ATMO_SENSORTILE_GPIO_GetPort(ATMO_GPIO_Device_Pin_t pin)
{

	uint32_t portNum = (pin >> 8) & 0xFF;
	if(portNum > 7)
	{
		return GPIOA;
	}

	return ATMO_SENSORTILE_GPIO_PortMap[portNum];
}

static inline uint32_t ATMO_SENSORTILE_GPIO_GetPin(ATMO_GPIO_Device_Pin_t pin)
{
	return (1 << (pin & 0xFF));
}

void ATMO_SENSORTILE_GPIO_IrqHandler(unsigned int irqNum)
{
	HAL_GPIO_EXTI_IRQHandler(ATMO_SENSORTILE_GPIO_GetPin(ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].pin));

	// If registered with driver
	if(ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].active)
	{
		// Get pin state and execute
		ATMO_GPIO_PinState_t pinState = ATMO_SENSORTILE_GPIO_Read(NULL, ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].pin);
		ATMO_Value_t pinVal;
		ATMO_InitValue(&pinVal);
		ATMO_CreateValueUnsignedInt(&pinVal, pinState);

		if(ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].isAbilityHandle)
		{
			ATMO_AddAbilityExecute(ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].abilityHandle, &pinVal);
		}
		else
		{
			ATMO_AddCallbackExecute(ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].cb, &pinVal);
		}

		ATMO_FreeValue(&pinVal);
	}
}



/**
 * @brief  EXTI line detection callback.
 * @param  uint16_t GPIO_Pin Specifies the pins connected EXTI line
 * @retval None
 */
void HAL_GPIO_EXTI_Callback( uint16_t GPIO_Pin )
{
	for(unsigned int irqNum = 0; irqNum < 16; irqNum++)
	{
		if((1 << irqNum) & GPIO_Pin)
		{
			// If registered with driver
			if(ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].active)
			{
				// Get pin state and execute
				ATMO_GPIO_PinState_t pinState = ATMO_SENSORTILE_GPIO_Read(NULL, ATMO_SENSORTILE_GPIO_IsrConfig[irqNum].pin);

		    	ATMO_SENSORTILE_GPIO_Rx_Payload_t payload;
		    	payload.irqNum = irqNum;
		    	payload.pinState = pinState;
		    	BaseType_t xHigherPriorityTaskWoken = pdFALSE;
		    	xQueueSendFromISR(rxQueue, &payload, &xHigherPriorityTaskWoken);
			}
		}
	}
}


ATMO_Status_t ATMO_SENSORTILE_GPIO_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber )
{
	ATMO_DriverInstanceData_t *driverInstanceData = (ATMO_DriverInstanceData_t *)malloc(sizeof(ATMO_DriverInstanceData_t));
	
	driverInstanceData->name = "SENSORTILE GPIO";
	driverInstanceData->initialized = false;
	driverInstanceData->instanceNumber = 0;
	driverInstanceData->argument = NULL;
	
	return ATMO_GPIO_AddDriverInstance( &sensortileGPIODriverInstance, driverInstanceData, instanceNumber );
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_Init( ATMO_DriverInstanceData_t *instance )
{
	rxQueue = xQueueCreate(ATMO_SENSORTILE_GPIO_RX_QUEUE_SIZE, sizeof(ATMO_SENSORTILE_GPIO_Rx_Payload_t));

	BaseType_t xReturned = xTaskCreate( ATMO_SENSORTILE_GPIO_RXQueueChecker, "GPIO RX Queue Checker", configMINIMAL_STACK_SIZE * 2, NULL, configMAX_PRIORITIES - 1, &rxQueueCheckerTaskHandle );

	if( xReturned != pdPASS )
	{
		return ATMO_GPIO_Status_Fail;
	}

	__GPIOA_CLK_ENABLE();
	__GPIOB_CLK_ENABLE();
	__GPIOC_CLK_ENABLE();
	__GPIOD_CLK_ENABLE();
	__GPIOE_CLK_ENABLE();
	__GPIOF_CLK_ENABLE();
	__GPIOG_CLK_ENABLE();
	return ATMO_GPIO_Status_Success;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_DeInit( ATMO_DriverInstanceData_t *instance )
{
	return ATMO_GPIO_Status_NotSupported;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_SetPinConfiguration( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, const ATMO_GPIO_Config_t* config )
{
	GPIO_InitTypeDef halGpioConfig;
	halGpioConfig.Pin = ATMO_SENSORTILE_GPIO_GetPin(pin);
	halGpioConfig.Speed = GPIO_SPEED_FREQ_HIGH;

	switch(config->pinMode)
	{
		case ATMO_GPIO_PinMode_Input_HighImpedance:
		{
			halGpioConfig.Mode = GPIO_MODE_INPUT;
			halGpioConfig.Pull = GPIO_NOPULL;
			break;
		}
		case ATMO_GPIO_PinMode_Input_PullUp:
		{
			halGpioConfig.Mode = GPIO_MODE_INPUT;
			halGpioConfig.Pull = GPIO_PULLUP;
			break;
		}
		case ATMO_GPIO_PinMode_Input_PullDown:
		{
			halGpioConfig.Mode = GPIO_MODE_INPUT;
			halGpioConfig.Pull = GPIO_PULLDOWN;
			break;
		}
		case ATMO_GPIO_PinMode_Output_PushPull:
		{
			halGpioConfig.Mode = GPIO_MODE_OUTPUT_PP;
			halGpioConfig.Pull = GPIO_NOPULL;
			break;
		}
		case ATMO_GPIO_PinMode_Output_OpenDrain:
		{
			halGpioConfig.Mode = GPIO_MODE_OUTPUT_OD;
			halGpioConfig.Pull = GPIO_NOPULL;
			break;
		}
		case ATMO_GPIO_PinMode_Output_OpenDrainPullUp:
		{
			halGpioConfig.Mode = GPIO_MODE_OUTPUT_OD;
			halGpioConfig.Pull = GPIO_PULLUP;
			break;
		}
		default:
		{
			halGpioConfig.Mode = GPIO_MODE_INPUT;
			halGpioConfig.Pull = GPIO_NOPULL;
			break;
		}
	}

	HAL_GPIO_Init(ATMO_SENSORTILE_GPIO_GetPort(pin), &halGpioConfig);

	return ATMO_GPIO_Status_Success;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_GetPinConfiguration( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, ATMO_GPIO_Config_t* config )
{
	return ATMO_GPIO_Status_NotSupported;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_RegisterInterruptAbilityHandle( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, uint8_t trigger, unsigned int abilityHandle )
{
	// Line 5 is used by BLE
	if(ATMO_SENSORTILE_GPIO_GetPin(pin) == 5)
	{
		return ATMO_GPIO_Status_Fail;
	}

	// Interrupt already registered on this pin
	if( (trigger != ATMO_GPIO_InterruptTrigger_None) && ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].active)
	{
		return ATMO_GPIO_Status_Fail;
	}

	GPIO_InitTypeDef halGpioConfig;
	halGpioConfig.Pin = ATMO_SENSORTILE_GPIO_GetPin(pin);
	halGpioConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	halGpioConfig.Pull = GPIO_NOPULL;

	switch(trigger)
	{
		case ATMO_GPIO_InterruptTrigger_RisingEdge:
		{
			halGpioConfig.Mode = GPIO_MODE_IT_RISING;
			break;
		}
		case ATMO_GPIO_InterruptTrigger_FallingEdge:
		{
			halGpioConfig.Mode = GPIO_MODE_IT_FALLING;
			break;
		}
		case ATMO_GPIO_InterruptTrigger_BothEdges:
		{
			halGpioConfig.Mode = GPIO_MODE_IT_RISING_FALLING;
			break;
		}
		case ATMO_GPIO_InterruptTrigger_None:
		{
			ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].active = false;
			HAL_NVIC_DisableIRQ(ATMO_SENSORTILE_GPIO_IrqNumMap[pin & 0xFF]);
			break;
		}
		default:
		{
			return ATMO_GPIO_Status_Fail;
		}
	}

	  HAL_GPIO_Init(ATMO_SENSORTILE_GPIO_GetPort(pin), &halGpioConfig);

	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].active = true;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].abilityHandle = abilityHandle;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].pin = pin;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].isAbilityHandle = true;


	  /* Enable and set EXTI Interrupt priority */
	  HAL_NVIC_SetPriority(ATMO_SENSORTILE_GPIO_IrqNumMap[pin & 0xFF], 0x08, 0x00);
	  HAL_NVIC_EnableIRQ(ATMO_SENSORTILE_GPIO_IrqNumMap[pin & 0xFF]);

	return ATMO_GPIO_Status_Success;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_RegisterInterruptCallback( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, uint8_t trigger, ATMO_Callback_t callback )
{
	// Line 5 is used by BLE
	if(ATMO_SENSORTILE_GPIO_GetPin(pin) == 5)
	{
		return ATMO_GPIO_Status_Fail;
	}

	ATMO_GPIO_InterruptTrigger_t unmaskedTrigger = ATMO_GPIO_GetInterruptTrigger(trigger);
	bool direct = ATMO_GPIO_IsDirectInterrupt(trigger);

	// Interrupt already registered on this pin
	if( (unmaskedTrigger != ATMO_GPIO_InterruptTrigger_None) && ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].active)
	{
		return ATMO_GPIO_Status_Fail;
	}

	GPIO_InitTypeDef halGpioConfig;
	halGpioConfig.Pin = ATMO_SENSORTILE_GPIO_GetPin(pin);
	halGpioConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	halGpioConfig.Pull = GPIO_NOPULL;

	switch(unmaskedTrigger)
	{
		case ATMO_GPIO_InterruptTrigger_RisingEdge:
		{
			halGpioConfig.Mode = GPIO_MODE_IT_RISING;
			break;
		}
		case ATMO_GPIO_InterruptTrigger_FallingEdge:
		{
			halGpioConfig.Mode = GPIO_MODE_IT_FALLING;
			break;
		}
		case ATMO_GPIO_InterruptTrigger_BothEdges:
		{
			halGpioConfig.Mode = GPIO_MODE_IT_RISING_FALLING;
			break;
		}
		case ATMO_GPIO_InterruptTrigger_None:
		{
			ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].active = false;
			HAL_NVIC_DisableIRQ(ATMO_SENSORTILE_GPIO_IrqNumMap[pin & 0xFF]);
			break;
		}
		default:
		{
			return ATMO_GPIO_Status_Fail;
		}
	}

	  HAL_GPIO_Init(ATMO_SENSORTILE_GPIO_GetPort(pin), &halGpioConfig);

	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].active = true;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].cb = callback;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].direct = direct;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].pin = pin;
	  ATMO_SENSORTILE_GPIO_IsrConfig[pin & 0xFF].isAbilityHandle = false;


	  /* Enable and set EXTI Interrupt priority */
	  HAL_NVIC_SetPriority(ATMO_SENSORTILE_GPIO_IrqNumMap[pin & 0xFF], 0x08, 0x00);
	  HAL_NVIC_EnableIRQ(ATMO_SENSORTILE_GPIO_IrqNumMap[pin & 0xFF]);

	return ATMO_GPIO_Status_Success;
}


ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_SetPinState( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, ATMO_GPIO_PinState_t state )
{
	HAL_GPIO_WritePin(ATMO_SENSORTILE_GPIO_GetPort(pin), ATMO_SENSORTILE_GPIO_GetPin(pin), (state == ATMO_GPIO_PinState_Low) ? GPIO_PIN_RESET : GPIO_PIN_SET);
	return ATMO_GPIO_Status_Success;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_GetPinState( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin, ATMO_GPIO_PinState_t* state )
{
	GPIO_PinState pinState = HAL_GPIO_ReadPin(ATMO_SENSORTILE_GPIO_GetPort(pin), ATMO_SENSORTILE_GPIO_GetPin(pin));
	*state = (pinState == GPIO_PIN_SET) ? ATMO_GPIO_PinState_High : ATMO_GPIO_PinState_Low;
	return ATMO_GPIO_Status_Success;
}

ATMO_GPIO_PinState_t ATMO_SENSORTILE_GPIO_Read( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin )
{
	ATMO_GPIO_PinState_t pinState;
	ATMO_SENSORTILE_GPIO_GetPinState(NULL, pin, &pinState);
	return pinState;
}

ATMO_GPIO_Status_t ATMO_SENSORTILE_GPIO_Toggle( ATMO_DriverInstanceData_t *instance, ATMO_GPIO_Device_Pin_t pin )
{
	HAL_GPIO_TogglePin(ATMO_SENSORTILE_GPIO_GetPort(pin), ATMO_SENSORTILE_GPIO_GetPin(pin));
	return ATMO_GPIO_Status_Success;
}
