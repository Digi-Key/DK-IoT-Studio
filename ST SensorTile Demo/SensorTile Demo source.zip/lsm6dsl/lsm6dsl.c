#include "lsm6dsl.h"
#include "lsm6dsl_reg.h"

static ATMO_LSM6DSL_Config_t _LSM6DSL_PrivConfig;
static lsm6dsl_ctx_t _LSM6DSL_AccelCtx;

static int32_t _ATMO_LSM6DSL_PlatformWrite(void *handle, uint8_t Reg, uint8_t *Bufp,
                              uint16_t len)
{
    uint8_t i2cAddress = *((uint8_t*)handle);
    ATMO_I2C_Status_t status = ATMO_I2C_MasterWrite(_LSM6DSL_PrivConfig.i2cInstance, i2cAddress,
    &Reg, 1, Bufp, len, 1000);
  
    return (status == ATMO_I2C_Status_Success) ? 0 : 1;
}

static int32_t _ATMO_LSM6DSL_PlatformRead(void *handle, uint8_t Reg, uint8_t *Bufp,
                             uint16_t len)
{
    uint8_t i2cAddress = *((uint8_t*)handle);
    ATMO_I2C_Status_t status = ATMO_I2C_Status_Success;
    uint8_t currentReg = Reg;

    // Need to do discrete reads or block update doesn't work
    for(unsigned int i = 0; (i < len) && (status == ATMO_I2C_Status_Success); i++)
    {
        status = ATMO_I2C_MasterRead(_LSM6DSL_PrivConfig.i2cInstance, i2cAddress,
            &currentReg, 1, &Bufp[i], 1, 1000);
        currentReg++;
    }

    return (status == ATMO_I2C_Status_Success) ? 0 : 1;
}

ATMO_LSM6DSL_Status_t ATMO_LSM6DSL_Init(ATMO_LSM6DSL_Config_t *config)
{
    if(config == NULL)
    {
        return ATMO_LSM6DSL_Status_Fail;
    }

    memcpy(&_LSM6DSL_PrivConfig, config, sizeof(_LSM6DSL_PrivConfig));

    _LSM6DSL_AccelCtx.write_reg = _ATMO_LSM6DSL_PlatformWrite;
    _LSM6DSL_AccelCtx.read_reg = _ATMO_LSM6DSL_PlatformRead;
    _LSM6DSL_AccelCtx.handle = (void*)&_LSM6DSL_PrivConfig.i2cAddress;  
    
    /*
   *  Check device ID
   */
    uint8_t whoamI = 0;
    lsm6dsl_device_id_get(&_LSM6DSL_AccelCtx, &whoamI);
    if ( whoamI != LSM6DSL_ID )
    {
        ATMO_PLATFORM_DebugPrint("LSM6DSL: Bad WhoAmI Rcv %02X Expect %02X\r\n", whoamI, LSM6DSL_ID);
        return ATMO_LSM6DSL_Status_Fail;
    }

    /*
    *  Restore default configuration
    */
   uint8_t rst = 0;
    lsm6dsl_reset_set(&_LSM6DSL_AccelCtx, PROPERTY_ENABLE);
    do {
        lsm6dsl_reset_get(&_LSM6DSL_AccelCtx, &rst);
    } while (rst);


    // Enable block data update
    lsm6dsl_block_data_update_set(&_LSM6DSL_AccelCtx, PROPERTY_ENABLE);
    /*
    * Set Output Data Rate
    */
    lsm6dsl_xl_data_rate_set(&_LSM6DSL_AccelCtx, config->accelOdr);
    lsm6dsl_gy_data_rate_set(&_LSM6DSL_AccelCtx, config->gyroOdr);
    /*
    * Set full scale
    */  
    lsm6dsl_xl_full_scale_set(&_LSM6DSL_AccelCtx, config->accelFullScale);
    lsm6dsl_gy_full_scale_set(&_LSM6DSL_AccelCtx, config->gyroFullScale);

    /*
    * Configure filtering chain(No aux interface)
    */  
    /* Accelerometer - analog filter */
    lsm6dsl_xl_filter_analog_set(&_LSM6DSL_AccelCtx, LSM6DSL_XL_ANA_BW_400Hz);

    /* Accelerometer - LPF1 path ( LPF2 not used )*/
    //lsm6dsl_xl_lp1_bandwidth_set(&dev_ctx, LSM6DSL_XL_LP1_ODR_DIV_4);

    /* Accelerometer - LPF1 + LPF2 path */   
    lsm6dsl_xl_lp2_bandwidth_set(&_LSM6DSL_AccelCtx, LSM6DSL_XL_LOW_NOISE_LP_ODR_DIV_100);

    /* Accelerometer - High Pass / Slope path */
    //lsm6dsl_xl_reference_mode_set(&dev_ctx, PROPERTY_DISABLE);
    //lsm6dsl_xl_hp_bandwidth_set(&dev_ctx, LSM6DSL_XL_HP_ODR_DIV_100);

    /* Gyroscope - filtering chain */
    lsm6dsl_gy_band_pass_set(&_LSM6DSL_AccelCtx, LSM6DSL_HP_260mHz_LP1_STRONG);

    return ATMO_LSM6DSL_Status_Success;
}

/**
 * @brief Get acceleration data. Each axis is in mg
 * 
 * @param data 
 * @return ATMO_LSM6DSL_Status_t 
 */
ATMO_LSM6DSL_Status_t ATMO_LSM6DSL_GetAccelData(ATMO_LSM6DSL_AccelData_t *data)
{
    uint8_t rawData[6] = {0};
    lsm6dsl_acceleration_raw_get(&_LSM6DSL_AccelCtx, rawData);

    int16_t rawDataInt[3] = {0};
    rawDataInt[0] = (rawData[1] << 8) | rawData[0];
    rawDataInt[1] = (rawData[3] << 8) | rawData[2];
    rawDataInt[2] = (rawData[5] << 8) | rawData[4];

    switch(_LSM6DSL_PrivConfig.accelFullScale)
    {
        case LSM6DSL_2g:
        {
            data->x = LSM6DSL_FROM_FS_2g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSL_FROM_FS_2g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSL_FROM_FS_2g_TO_mg( rawDataInt[2] );
            break;
        }
        case LSM6DSL_4g:
        {
            data->x = LSM6DSL_FROM_FS_4g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSL_FROM_FS_4g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSL_FROM_FS_4g_TO_mg( rawDataInt[2] );
            break;
        }
        case LSM6DSL_8g:
        {
            data->x = LSM6DSL_FROM_FS_8g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSL_FROM_FS_8g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSL_FROM_FS_8g_TO_mg( rawDataInt[2] );
            break;
        }
        case LSM6DSL_16g:
        {
            data->x = LSM6DSL_FROM_FS_16g_TO_mg( rawDataInt[0] );
            data->y = LSM6DSL_FROM_FS_16g_TO_mg( rawDataInt[1] );
            data->z = LSM6DSL_FROM_FS_16g_TO_mg( rawDataInt[2] );
            break;
        }
        default:
        {
            memset(data, 0, sizeof(ATMO_LSM6DSL_AccelData_t));
            return ATMO_LSM6DSL_Status_Fail;
            break;
        }

    }

    return ATMO_LSM6DSL_Status_Success;
}

/**
 * @brief Get magnetometer data. Each axis is in mdps
 * 
 * @param data 
 * @return ATMO_LSM6DSL_Status_t 
 */
ATMO_LSM6DSL_Status_t ATMO_LSM6DSL_GetGyroData(ATMO_LSM6DSL_GyroData_t *data)
{
    uint8_t rawData[6] = {0};
    lsm6dsl_angular_rate_raw_get(&_LSM6DSL_AccelCtx, rawData);

    int16_t rawDataInt[3] = {0};
    rawDataInt[0] = (rawData[1] << 8) | rawData[0];
    rawDataInt[1] = (rawData[3] << 8) | rawData[2];
    rawDataInt[2] = (rawData[5] << 8) | rawData[4];

    switch(_LSM6DSL_PrivConfig.gyroFullScale)
    {
        case LSM6DSL_250dps:
        {
            data->x = LSM6DSL_FROM_FS_250dps_TO_mdps(rawData[0]);
            data->y = LSM6DSL_FROM_FS_250dps_TO_mdps(rawData[1]);
            data->z = LSM6DSL_FROM_FS_250dps_TO_mdps(rawData[2]);
            break;
        }
        case LSM6DSL_125dps:
        {
            data->x = LSM6DSL_FROM_FS_125dps_TO_mdps(rawData[0]);
            data->y = LSM6DSL_FROM_FS_125dps_TO_mdps(rawData[1]);
            data->z = LSM6DSL_FROM_FS_125dps_TO_mdps(rawData[2]);
            break;
        }
        case LSM6DSL_500dps:
        {
            data->x = LSM6DSL_FROM_FS_500dps_TO_mdps(rawData[0]);
            data->y = LSM6DSL_FROM_FS_500dps_TO_mdps(rawData[1]);
            data->z = LSM6DSL_FROM_FS_500dps_TO_mdps(rawData[2]);
            break;
        }
        case LSM6DSL_1000dps:
        {
            data->x = LSM6DSL_FROM_FS_1000dps_TO_mdps(rawData[0]);
            data->y = LSM6DSL_FROM_FS_1000dps_TO_mdps(rawData[1]);
            data->z = LSM6DSL_FROM_FS_1000dps_TO_mdps(rawData[2]);
            break;
        }
        case LSM6DSL_2000dps:
        {
            data->x = LSM6DSL_FROM_FS_2000dps_TO_mdps(rawData[0]);
            data->y = LSM6DSL_FROM_FS_2000dps_TO_mdps(rawData[1]);
            data->z = LSM6DSL_FROM_FS_2000dps_TO_mdps(rawData[2]);
            break;
        }
        default:
        {
            data->x = 0;
            data->y = 0;
            data->z = 0;
            return ATMO_LSM6DSL_Status_Fail;
        }
    }

    return ATMO_LSM6DSL_Status_Success;
}

/**
 * @brief Get temperature data in degrees C
 * 
 * @param data 
 * @return ATMO_LSM6DSL_Status_t 
 */
ATMO_LSM6DSL_Status_t ATMO_LSM6DSL_GetTempData(float *tempC)
{
    uint8_t rawData[2] = {0};
    lsm6dsl_temperature_raw_get(&_LSM6DSL_AccelCtx, rawData);

    int16_t tempDataInt = (rawData[1] << 8) | rawData[0];
    *tempC = LSM6DSL_FROM_LSB_TO_degC( tempDataInt );
    return ATMO_LSM6DSL_Status_Success;
}