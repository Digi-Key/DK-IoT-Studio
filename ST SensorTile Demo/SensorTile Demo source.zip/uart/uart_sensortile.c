#include "uart_sensortile.h"

const ATMO_UART_DriverInstance_t sensortileUARTDriverInstance = {
	ATMO_SENSORTILE_UART_Init,
	ATMO_SENSORTILE_UART_DeInit,
	ATMO_SENSORTILE_UART_SetConfiguration,
	ATMO_SENSORTILE_UART_GetConfiguration,
	ATMO_SENSORTILE_UART_WriteBlocking,
	ATMO_SENSORTILE_UART_ReadBlocking,
	ATMO_SENSORTILE_UART_NumRxBytesAvailable,
	ATMO_SENSORTILE_UART_FlushRx,
	ATMO_SENSORTILE_UART_FlushTx,
	ATMO_SENSORTILE_UART_RegisterRxAbilityHandle,
	ATMO_SENSORTILE_UART_RegisterRxCbFunc,
};

ATMO_Status_t ATMO_SENSORTILE_UART_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber )
{
	ATMO_Status_t status = ATMO_Status_Success;
	ATMO_DriverInstanceData_t *driverData = ATMO_Malloc(sizeof(ATMO_DriverInstanceData_t));
    driverData->name = "SENSORTILE UART";
    driverData->initialized = false;
    driverData->instanceNumber = *instanceNumber;
    driverData->argument = NULL;

	status = ATMO_UART_AddDriverInstance( &sensortileUARTDriverInstance, driverData, instanceNumber );
	
	return status;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_Init(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_DeInit(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_SetConfiguration(ATMO_DriverInstanceData_t *instance, const ATMO_UART_Peripheral_t *config)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_GetConfiguration(ATMO_DriverInstanceData_t *instance, ATMO_UART_Peripheral_t *config)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_WriteBlocking(ATMO_DriverInstanceData_t *instance, const char *buffer, uint32_t length, uint32_t *numBytesSent, uint16_t timeoutMs)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_ReadBlocking(ATMO_DriverInstanceData_t *instance, char *buffer, uint32_t length, uint32_t *numBytesReceived, uint16_t timeoutMs)
{
    return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_NumRxBytesAvailable(ATMO_DriverInstanceData_t *instance, unsigned int *numBytesAvailable)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_FlushTx(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_FlushRx(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_RegisterRxAbilityHandle(ATMO_DriverInstanceData_t *instance, unsigned int abilityHandle)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_RegisterRxCbFunc(ATMO_DriverInstanceData_t *instance, ATMO_Callback_t cbFunc)
{
	return ATMO_UART_Status_NotSupported;
}

ATMO_UART_Status_t ATMO_SENSORTILE_UART_SetPins(ATMO_DriverInstanceHandle_t handle, unsigned int txPin, unsigned int rxPin)
{
	return ATMO_UART_Status_NotSupported;
}

