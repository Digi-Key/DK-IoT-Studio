#include "block_sensortile.h"
#include "stm32l4xx_hal.h"
#include "eeprom_emul.h"
#include "eeprom_emul_conf.h"

/* Virtual address Tab defined by the user: 0x0000 and 0xFFFF values are prohibited */
static uint16_t ATMO_SENSORTILE_BLOCK_FlashVars[NB_OF_VARIABLES] = {0};

#define ATMO_SENSORTILE_BLOCK_SIZE (NB_OF_VARIABLES/2)

ATMO_BLOCK_DriverInstance_t sensortileBlockDriverInstance = {
	ATMO_SENSORTILE_BLOCK_Init,
	ATMO_SENSORTILE_BLOCK_Read,
	ATMO_SENSORTILE_BLOCK_Program,
	ATMO_SENSORTILE_BLOCK_Erase,
	ATMO_SENSORTILE_BLOCK_Sync,
	ATMO_SENSORTILE_BLOCK_GetDeviceInfo
};

ATMO_Status_t ATMO_SENSORTILE_BLOCK_AddDriverInstance(ATMO_DriverInstanceHandle_t *instanceNumber)
{
	
	ATMO_DriverInstanceData_t *sensortileBlockDriver = ATMO_Malloc(sizeof(ATMO_DriverInstanceData_t));
	sensortileBlockDriver->name = "SENSORTILE Internal Block";
	sensortileBlockDriver->initialized = false;
	sensortileBlockDriver->instanceNumber = *instanceNumber;
	sensortileBlockDriver->argument = NULL;
	
	return ATMO_BLOCK_AddDriverInstance(&sensortileBlockDriverInstance, sensortileBlockDriver, instanceNumber);
}

ATMO_BLOCK_Status_t ATMO_SENSORTILE_BLOCK_Init(ATMO_DriverInstanceData_t *instance)
{
	  /* Set user List of Virtual Address variables: 0x0000 and 0xFFFF values are prohibited */
	  for (uint16_t VarValue = 0; VarValue < NB_OF_VARIABLES; VarValue++)
	  {
		  ATMO_SENSORTILE_BLOCK_FlashVars[VarValue] = (uint16_t)(10*VarValue + 1);
	  }

	  HAL_FLASH_Unlock();
	  EE_Status eeStatus = EE_Init(ATMO_SENSORTILE_BLOCK_FlashVars, EE_FORCED_ERASE);

	  for(unsigned int i = 0; (i < NB_OF_VARIABLES) && (eeStatus == EE_OK); i++)
	  {
		  eeStatus = EE_WriteVariable8bits(ATMO_SENSORTILE_BLOCK_FlashVars[i], 0x0);
		  if ((eeStatus & EE_STATUSMASK_CLEANUP) == EE_STATUSMASK_CLEANUP) {eeStatus = EE_CleanUp();}
	  }

	  HAL_FLASH_Lock();

	  if(eeStatus != EE_OK)
	  {
		  return ATMO_BLOCK_Status_Fail;
	  }

	return ATMO_BLOCK_Status_Success;
}

ATMO_BLOCK_Status_t ATMO_SENSORTILE_BLOCK_Read(ATMO_DriverInstanceData_t *instance, uint32_t block, uint32_t offset, void *buffer, uint32_t size)
{
	EE_Status eeStatus = EE_OK;

	HAL_FLASH_Unlock();
	for(unsigned int i = 0; (i < size) && (eeStatus == EE_OK); i++)
	{
		eeStatus = EE_ReadVariable8bits(ATMO_SENSORTILE_BLOCK_FlashVars[(block * ATMO_SENSORTILE_BLOCK_SIZE) + offset + i], &((uint8_t *)buffer)[i]);
		if ((eeStatus & EE_STATUSMASK_CLEANUP) == EE_STATUSMASK_CLEANUP) {eeStatus|= EE_CleanUp();}
	}
	HAL_FLASH_Lock();

	if(eeStatus != EE_OK)
	{
		ATMO_PLATFORM_DebugPrint("Bad Read!\r\n");
	}

	return (eeStatus == EE_OK) ? ATMO_BLOCK_Status_Success : ATMO_BLOCK_Status_Fail;
}

ATMO_BLOCK_Status_t ATMO_SENSORTILE_BLOCK_Program(ATMO_DriverInstanceData_t *instance, uint32_t block, uint32_t offset, void *buffer, uint32_t size)
{
	EE_Status eeStatus = EE_OK;

	HAL_FLASH_Unlock();
	for(unsigned int i = 0; (i < size) && (eeStatus == EE_OK); i++)
	{
		uint8_t tempByte = 0;
		eeStatus = EE_ReadVariable8bits(ATMO_SENSORTILE_BLOCK_FlashVars[(block * ATMO_SENSORTILE_BLOCK_SIZE) + offset + i], &tempByte);

		if( eeStatus != EE_OK )
		{
			return ATMO_BLOCK_Status_Fail;
		}

		if( tempByte != ((uint8_t *)buffer)[i])
		{
			eeStatus = EE_WriteVariable8bits(ATMO_SENSORTILE_BLOCK_FlashVars[(block * ATMO_SENSORTILE_BLOCK_SIZE) + offset + i], ((uint8_t *)buffer)[i]);
			if ((eeStatus & EE_STATUSMASK_CLEANUP) == EE_STATUSMASK_CLEANUP) {eeStatus= EE_CleanUp();}
		}
	}
	HAL_FLASH_Lock();

	return eeStatus == EE_OK ? ATMO_BLOCK_Status_Success : ATMO_BLOCK_Status_Fail;
}

ATMO_BLOCK_Status_t ATMO_SENSORTILE_BLOCK_Erase(ATMO_DriverInstanceData_t *instance, uint32_t block)
{
	EE_Status eeStatus = EE_OK;

	HAL_FLASH_Unlock();
	EE_Format(EE_FORCED_ERASE);
	for(unsigned int i = 0; i < ATMO_SENSORTILE_BLOCK_SIZE; i++)
	{
		eeStatus = EE_WriteVariable8bits(ATMO_SENSORTILE_BLOCK_FlashVars[i], 0x0);
		if ((eeStatus & EE_STATUSMASK_CLEANUP) == EE_STATUSMASK_CLEANUP) {eeStatus= EE_CleanUp();}
	}
	HAL_FLASH_Lock();
	
	return eeStatus == EE_OK ? ATMO_BLOCK_Status_Success : ATMO_BLOCK_Status_Fail;
}

ATMO_BLOCK_Status_t ATMO_SENSORTILE_BLOCK_Sync(ATMO_DriverInstanceData_t *instance)
{
	return ATMO_BLOCK_Status_Success;
}

ATMO_BLOCK_Status_t ATMO_SENSORTILE_BLOCK_GetDeviceInfo(ATMO_DriverInstanceData_t *instance, ATMO_BLOCK_DeviceInfo_t *info)
{
	info->blockCount = 1;
	info->blockSize = ATMO_SENSORTILE_BLOCK_SIZE;
	info->progSize = 1;
	info->readSize = 1;
	return ATMO_BLOCK_Status_Success;
}
