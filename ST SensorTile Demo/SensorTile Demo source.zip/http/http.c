/**
 ******************************************************************************
 * @file    http.c
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - Core HTTP Driver
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

#include "http.h"
#include "picohttpparser.h"
#include "../atmo/core.h"
#include "../app_src/atmosphere_platform.h"
#include "../tcpclient/tcpclient.h"

static ATMO_DriverInstanceHandle_t _ATMO_HTTP_TcpClientInstance = 0;

#define ATMO_HTTP_POST_TEMPLATE "POST %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\nContent-Type: %s\r\nContent-Length: %d\r\n"
#define ATMO_HTTP_GET_TEMPLATE "GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n"

static bool _ATMO_HTTP_RxDataAvailable = false;

#ifndef ATMO_HTTP_PACKETBUF_SIZE
#define ATMO_HTTP_PACKETBUF_SIZE (256)
#endif
static char _ATMO_HTTP_PacketBuf[ATMO_HTTP_PACKETBUF_SIZE];
static char *_ATMO_HTTP_LastRespData = NULL;
static unsigned int _ATMO_HTTP_LastRespDataLen = 0;


static void _ATMO_HTTP_TcpRxCb( void *rawData )
{
	_ATMO_HTTP_RxDataAvailable = true;
}

ATMO_HTTP_Status_t ATMO_HTTP_Init( ATMO_DriverInstanceHandle_t tcpClientDriverInstance )
{
	_ATMO_HTTP_TcpClientInstance = tcpClientDriverInstance;
	ATMO_TCP_CLIENT_SetReceiveCallback( _ATMO_HTTP_TcpClientInstance, _ATMO_HTTP_TcpRxCb );
	return ATMO_HTTP_Status_Success;
}

ATMO_HTTP_Status_t ATMO_HTTP_DeInit()
{
	return ATMO_HTTP_Status_Success;
}


ATMO_HTTP_Status_t ATMO_HTTP_SetConfiguration( const ATMO_HTTP_Config_t *config )
{
	return ATMO_HTTP_Status_Success;
}

static void _ATMO_HTTP_ParseUrl( const char *url, bool *isHttps, unsigned int *port, char **host, unsigned int *hostLen, char **path, unsigned int *pathLen )
{
	*port = 80;

	// Find the protocol
	if ( strstr( url, "https" ) == url )
	{
		*isHttps = true;
		*port = 443;
	}

	*host = strstr( url, "://" );

	if ( ( *host ) != NULL )
	{
		( *host ) += strlen( "://" );
	}
	else
	{
		( *host ) = url;
	}


	// Check if the user supplied a port
	char *portStrStart = strstr( *host, ":" );
		
	if ( portStrStart != NULL )
	{
		*port = (unsigned int)strtol( portStrStart + 1, NULL, 0 );
	}
		
	char *pathStart = strstr( *host, "/" );

	// No path
	if ( pathStart == NULL )
	{
		*path = NULL;
		*pathLen = 0;
	}
	else
	{
		*hostLen = pathStart - ( *host );
		*pathLen = strlen(pathStart);
		*path = pathStart;
	}
	
	return;
}

/**
 * @brief Build an HTTP request string
 *
 * @param transaction
 * @param isHttps
 * @param port
 * @param host - The host string, NULL terminated. This MUST BE FREED by the caller.
 * @return char* - The entire request string. NULL terminated. This MUST BE FREED by the caller.
 */
static char *_ATMO_HTTP_BuildRequest( ATMO_HTTP_Transaction_t *transaction, bool *isHttps, unsigned int *port, char **host, unsigned int *hostLen )
{
	char *path = NULL;
	unsigned int pathLen = 0;

	_ATMO_HTTP_ParseUrl( transaction->url, isHttps, port, host, hostLen, &path, &pathLen );

	// Save the host in its own string
	char hostStr[*hostLen + 1];
	memset( hostStr, 0, ( *hostLen ) + 1 );
	strncpy( hostStr, *host, *hostLen );

	char pathStr[pathLen + 1];
	memset( pathStr, 0, pathLen + 1 );
	strncpy( pathStr, path, pathLen );

	// Could do this one of two ways:
	// Allocate a bigger buffer than we'll ever need OR
	// Precalculate the size beforehand and allocate a buffer of the perfect size
	// Allocating a nice big buffer is faster and simpler
	// Still need to make sure that the buffer doesn't get overrun
	unsigned int currentSize = 0;

	if ( transaction->method == ATMO_HTTP_POST )
	{
		currentSize += sprintf( _ATMO_HTTP_PacketBuf, ATMO_HTTP_POST_TEMPLATE, pathStr, hostStr, transaction->contentType == NULL ? "application/json" : transaction->contentType,
		                        transaction->dataLen );
	}
	else
	{
		currentSize += sprintf( _ATMO_HTTP_PacketBuf, ATMO_HTTP_GET_TEMPLATE, pathStr, hostStr );
	}

	// Add additional headers
	for ( unsigned int i = 0; i < transaction->headerOverlayLen; i++ )
	{
		int headerSize = snprintf( NULL, 0, "%s: %s\r\n", transaction->headerOverlay[i].headerKey, transaction->headerOverlay[i].headerValue );

		if ( currentSize + headerSize >= ATMO_HTTP_PACKETBUF_SIZE )
		{
			return NULL;
		}

		currentSize += sprintf( &_ATMO_HTTP_PacketBuf[currentSize], "%s: %s\r\n", transaction->headerOverlay[i].headerKey, transaction->headerOverlay[i].headerValue );
	}

	// Add additonal \r\n before data (or end)
	if ( currentSize + 2 >= ATMO_HTTP_PACKETBUF_SIZE )
	{
		return NULL;
	}

	currentSize += sprintf( &_ATMO_HTTP_PacketBuf[currentSize], "\r\n" );

	if ( transaction->method == ATMO_HTTP_POST )
	{
		int size = transaction->dataLen + 4; // Data length and \r\n\r\n

		if ( currentSize + size >= ATMO_HTTP_PACKETBUF_SIZE )
		{
			return NULL;
		}

		sprintf( &_ATMO_HTTP_PacketBuf[currentSize], "%s\r\n\r\n", transaction->data );
	}

	return _ATMO_HTTP_PacketBuf;
}

static bool _ATMO_HTTP_ParseResponse(uint8_t *dataPtr, unsigned int *respCode, unsigned int *respDataLen)
{
	int minor_version;
	int status;
	const char *msg;
	size_t msg_len;
	struct phr_header headers[20];
	size_t num_headers;

	int nBytes = phr_parse_response( ( char * )dataPtr, strlen( ( char * )dataPtr ), &minor_version, &status, &msg, &msg_len, headers, &num_headers, 0 );

	*respCode = status;
	_ATMO_HTTP_LastRespDataLen = strlen( ( char * )&dataPtr[nBytes] ) + 1;
	_ATMO_HTTP_LastRespData = ( char * )&dataPtr[nBytes];
	*respDataLen = _ATMO_HTTP_LastRespDataLen;

	return true;
}

ATMO_HTTP_Status_t ATMO_HTTP_Perform(ATMO_HTTP_Transaction_t *transaction, unsigned int *respCode, unsigned int *respDataLen, unsigned int timeoutMs)
{
	unsigned int port = 80;
	bool isHttps = false;
	char *host = NULL;
	unsigned int hostLen = 0;
	_ATMO_HTTP_LastRespDataLen = 0;

	// Build request string
	char *reqString = _ATMO_HTTP_BuildRequest( transaction, &isHttps, &port, &host, &hostLen );

	char hostStr[hostLen + 1];
	memset(hostStr, 0, hostLen + 1);
	memcpy(hostStr, host, hostLen);

	// If the host string has a port in it
	char *portStart = strchr(hostStr, ':');

	if(portStart != NULL)
	{
		*portStart = 0;
	}
	
//#ifndef ATMO_SLIM_STACK
//	ATMO_PLATFORM_DebugPrint("Req: %s\r\n", reqString);
//#endif
	
	ATMO_TCP_CLIENT_Status_t tcpStatus = ATMO_TCP_CLIENT_Connect( _ATMO_HTTP_TcpClientInstance, hostStr, port, isHttps );

	if ( tcpStatus != ATMO_TCP_CLIENT_Status_Success )
	{
		return ATMO_HTTP_Status_Fail;
	}

	// Send data
	// Wait for response
	_ATMO_HTTP_RxDataAvailable = false;
	tcpStatus = ATMO_TCP_CLIENT_WriteBytes(_ATMO_HTTP_TcpClientInstance, ( uint8_t * )reqString, strlen( reqString ) );

	if ( tcpStatus != ATMO_TCP_CLIENT_Status_Success )
	{
//#ifndef ATMO_SLIM_STACK
		ATMO_PLATFORM_DebugPrint( "[ATMO HTTP] Error sending TCP Data\r\n" );
//#endif
		ATMO_TCP_CLIENT_Disconnect( _ATMO_HTTP_TcpClientInstance );
		return ATMO_HTTP_Status_Fail;
	}

	unsigned int currentMs = 0;

	while ( currentMs < timeoutMs )
	{
		if ( _ATMO_HTTP_RxDataAvailable )
		{
			uint32_t numBytes = 0;
			uint8_t *dataPtr = NULL;
			ATMO_TCP_CLIENT_GetNumAvailableBytes(_ATMO_HTTP_TcpClientInstance, &numBytes, &dataPtr);
			dataPtr[numBytes] = 0;
			_ATMO_HTTP_ParseResponse( dataPtr, respCode, respDataLen );
			break;
		}

		ATMO_PLATFORM_DelayMilliseconds( 1 );
		ATMO_Tick();
		currentMs++;
	}

	// No matter what, disconnect here
	ATMO_TCP_CLIENT_Disconnect( _ATMO_HTTP_TcpClientInstance );

	if ( currentMs >= timeoutMs )
	{
		return ATMO_HTTP_Status_Fail;
	}

	return ATMO_HTTP_Status_Success;
}

ATMO_HTTP_Status_t ATMO_HTTP_GetRespData(uint8_t *buf, unsigned int bufLen)
{
	if(_ATMO_HTTP_LastRespDataLen > bufLen || _ATMO_HTTP_LastRespDataLen == 0)
	{
		return ATMO_HTTP_Status_Fail;
	}
	memset(buf, 0, bufLen);
	memcpy(buf, _ATMO_HTTP_LastRespData, _ATMO_HTTP_LastRespDataLen);
	_ATMO_HTTP_LastRespDataLen = 0;
	return ATMO_HTTP_Status_Success;
}


