/**
 ******************************************************************************
 * @file    i2c.c
 * @author
 * @version
 * @date
 * @brief   Atmosphere API - SENSORTILE I2C API Implementation
 ******************************************************************************
 * @attention
 *
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */

#include "i2c_sensortile.h"
#include "SensorTile.h"
#include "stm32l4xx_hal.h"

const ATMO_I2C_DriverInstance_t sensortileI2CDriverInstance = {
	ATMO_SENSORTILE_I2C_Init,
	ATMO_SENSORTILE_I2C_DeInit,
	ATMO_SENSORTILE_I2C_SetConfiguration,
	ATMO_SENSORTILE_I2C_MasterWrite,
	ATMO_SENSORTILE_I2C_MasterRead
};

static I2C_HandleTypeDef _ATMO_SENSORTILE_I2C_Handle;

/**
 * @brief I2C MSP Initialization
 * @param None
 * @retval None
 */
static void _ATMO_SENSORTILE_I2C_MspInit( void )
{
  GPIO_InitTypeDef  GPIO_InitStruct;

  RCC_PeriphCLKInitTypeDef  RCC_PeriphCLKInitStruct;

  /*##-1- Configure the I2C clock source. The clock is derived from the SYSCLK #*/
  RCC_PeriphCLKInitStruct.PeriphClockSelection = SENSORTILE_I2C_ONBOARD_SENSORS_RCC_PERIPHCLK;
  RCC_PeriphCLKInitStruct.I2c3ClockSelection = SENSORTILE_I2C_ONBOARD_SENSORS_I2CCLKSOURCE;
  HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphCLKInitStruct);

  /* Enable I2C GPIO clocks */
  SENSORTILE_I2C_ONBOARD_SENSORS_SCL_SDA_GPIO_CLK_ENABLE();

  /* I2C_SENSORTILE SCL and SDA pins configuration -------------------------------------*/
  GPIO_InitStruct.Pin        = SENSORTILE_I2C_ONBOARD_SENSORS_SCL_PIN | SENSORTILE_I2C_ONBOARD_SENSORS_SDA_PIN;
  GPIO_InitStruct.Mode       = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Speed      = GPIO_SPEED_FAST;
  GPIO_InitStruct.Pull       = GPIO_PULLUP;
  GPIO_InitStruct.Alternate  = SENSORTILE_I2C_ONBOARD_SENSORS_SCL_SDA_AF;

  HAL_GPIO_Init( SENSORTILE_I2C_ONBOARD_SENSORS_SCL_SDA_GPIO_PORT, &GPIO_InitStruct );

  /* Enable the I2C_SENSORTILE peripheral clock */
  SENSORTILE_I2C_ONBOARD_SENSORS_CLK_ENABLE();

  /* Force the I2C peripheral clock reset */
  SENSORTILE_I2C_ONBOARD_SENSORS_FORCE_RESET();

  /* Release the I2C peripheral clock reset */
  SENSORTILE_I2C_ONBOARD_SENSORS_RELEASE_RESET();

  /* Enable and set I2C_SENSORTILE Interrupt to the highest priority */
  HAL_NVIC_SetPriority(SENSORTILE_I2C_ONBOARD_SENSORS_EV_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(SENSORTILE_I2C_ONBOARD_SENSORS_EV_IRQn);

  /* Enable and set I2C_SENSORTILE Interrupt to the highest priority */
  HAL_NVIC_SetPriority(SENSORTILE_I2C_ONBOARD_SENSORS_ER_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(SENSORTILE_I2C_ONBOARD_SENSORS_ER_IRQn);
}


ATMO_Status_t ATMO_SENSORTILE_I2C_AddDriverInstance( ATMO_DriverInstanceHandle_t* instanceNumber)
{
	ATMO_DriverInstanceData_t *driverInstanceData = (ATMO_DriverInstanceData_t *)malloc(sizeof(ATMO_DriverInstanceData_t));
	
	driverInstanceData->name = "SENSORTILE I2C";
	driverInstanceData->initialized = false;
	driverInstanceData->instanceNumber = 0;
	driverInstanceData->argument = NULL;

	return ATMO_I2C_AddDriverInstance( &sensortileI2CDriverInstance, driverInstanceData, instanceNumber );
}

ATMO_I2C_Status_t ATMO_SENSORTILE_I2C_Init( ATMO_DriverInstanceData_t *instance )
{
	return ATMO_I2C_Status_Success;
}

ATMO_I2C_Status_t ATMO_SENSORTILE_I2C_DeInit( ATMO_DriverInstanceData_t *instance )
{
	return ATMO_I2C_Status_Success;
}

ATMO_I2C_Status_t ATMO_SENSORTILE_I2C_SetConfiguration( ATMO_DriverInstanceData_t *instance, const ATMO_I2C_Peripheral_t* config )
{

	memset(&_ATMO_SENSORTILE_I2C_Handle, 0, sizeof(_ATMO_SENSORTILE_I2C_Handle));

	_ATMO_SENSORTILE_I2C_Handle.Instance = I2C3;

	switch(config->baudRate)
	{
		case ATMO_I2C_BaudRate_Standard_Mode:
		case ATMO_I2C_BaudRate_100kHz:
		{
			_ATMO_SENSORTILE_I2C_Handle.Init.Timing = 0x10909CEC;
			break;
		}
		case ATMO_I2C_BaudRate_Fast_Mode:
		case ATMO_I2C_BaudRate_400kHz:
		{
			_ATMO_SENSORTILE_I2C_Handle.Init.Timing = 0x10801541;
			break;
		}
		case ATMO_I2C_BaudRate_Fast_Mode_Plus:
		case ATMO_I2C_BaudRate_1000kHz:
		{
			_ATMO_SENSORTILE_I2C_Handle.Init.Timing = 0x00D00E28;
			break;
		}
		default:
		{
			_ATMO_SENSORTILE_I2C_Handle.Init.Timing = 0x10909CEC;
			break;
		}
	}

	_ATMO_SENSORTILE_I2C_Handle.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	_ATMO_SENSORTILE_I2C_Handle.Init.OwnAddress1 = 0x33;
	_ATMO_SENSORTILE_I2C_MspInit();
    HAL_I2C_Init( &_ATMO_SENSORTILE_I2C_Handle );

	return ATMO_I2C_Status_Success;
}

ATMO_I2C_Status_t ATMO_SENSORTILE_I2C_MasterWrite( ATMO_DriverInstanceData_t *instance, uint16_t slaveAddress, const uint8_t* cmdBytes, uint16_t numCmdBytes, const uint8_t* writeBytes, uint16_t numWriteBytes, uint16_t timeout_ms )
{
	HAL_StatusTypeDef status = HAL_OK;

	if(numCmdBytes > 0)
	{
		switch(numCmdBytes)
		{
			case 1:
			{
				status = HAL_I2C_Mem_Write(&_ATMO_SENSORTILE_I2C_Handle, (slaveAddress << 1), cmdBytes[0], I2C_MEMADD_SIZE_8BIT, writeBytes, numWriteBytes, timeout_ms);
				break;
			}
			case 2:
			{
				status = HAL_I2C_Mem_Write(&_ATMO_SENSORTILE_I2C_Handle, (slaveAddress << 1), cmdBytes[0] | (cmdBytes[1] << 8), I2C_MEMADD_SIZE_16BIT, writeBytes, numWriteBytes, timeout_ms);
				break;
			}
			default:
			{
				status = HAL_I2C_Master_Transmit(&_ATMO_SENSORTILE_I2C_Handle, slaveAddress << 1, cmdBytes, numCmdBytes, timeout_ms);

				if(status == HAL_OK)
				{
					status = HAL_I2C_Master_Transmit(&_ATMO_SENSORTILE_I2C_Handle, slaveAddress << 1, writeBytes, numWriteBytes, timeout_ms);
				}
			}
		}
	}
	else
	{
		status = HAL_I2C_Master_Transmit(&_ATMO_SENSORTILE_I2C_Handle, slaveAddress << 1, writeBytes, numWriteBytes, timeout_ms);
	}

	return (status == HAL_OK) ? ATMO_I2C_Status_Success : ATMO_I2C_Status_Fail;
}

ATMO_I2C_Status_t ATMO_SENSORTILE_I2C_MasterRead( ATMO_DriverInstanceData_t *instance, uint16_t slaveAddress, const uint8_t* cmdBytes, uint16_t numCmdBytes, uint8_t* readBytes, uint16_t numReadBytes, uint16_t timeout_ms )
{
	HAL_StatusTypeDef status = HAL_OK;

	if(numCmdBytes > 0)
	{
		switch(numCmdBytes)
		{
			case 1:
			{
				status = HAL_I2C_Mem_Read(&_ATMO_SENSORTILE_I2C_Handle, (slaveAddress << 1), cmdBytes[0], I2C_MEMADD_SIZE_8BIT, readBytes, numReadBytes, timeout_ms);
				break;
			}
			case 2:
			{
				status = HAL_I2C_Mem_Read(&_ATMO_SENSORTILE_I2C_Handle, (slaveAddress << 1), cmdBytes[0] | (cmdBytes[1] << 8), I2C_MEMADD_SIZE_16BIT, readBytes, numReadBytes, timeout_ms);
				break;
			}
			default:
			{
				status = HAL_I2C_Master_Transmit(&_ATMO_SENSORTILE_I2C_Handle, slaveAddress << 1, cmdBytes, numCmdBytes, timeout_ms);

				if(status == HAL_OK)
				{
					status = HAL_I2C_Master_Receive(&_ATMO_SENSORTILE_I2C_Handle, slaveAddress << 1, readBytes, numReadBytes, timeout_ms);
				}
			}
		}

	}
	else
	{
		status = HAL_I2C_Master_Receive(&_ATMO_SENSORTILE_I2C_Handle, slaveAddress << 1, readBytes, numReadBytes, timeout_ms);
	}

	return (status == HAL_OK) ? ATMO_I2C_Status_Success : ATMO_I2C_Status_Fail;
}
